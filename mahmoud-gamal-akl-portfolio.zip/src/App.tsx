import React, { useState, useEffect, lazy, Suspense } from "react";
import GlobalLayout from "./app/layout";
import { useLanguage } from "./components/LanguageContext";
import { useTheme } from "./components/ThemeContext";
import { portfolioData } from "./data/portfolio";
import { ErrorBoundary } from "./components/ErrorPage";
import LoadingPage from "./components/LoadingPage";

const AboutView = lazy(() => import("./components/AboutView"));
const ServicesView = lazy(() => import("./components/ServicesView"));
const ExperienceView = lazy(() => import("./components/ExperienceView"));
const ProjectsView = lazy(() => import("./components/ProjectsView"));
const SkillsView = lazy(() => import("./components/SkillsView"));
const ContactView = lazy(() => import("./components/ContactView"));
const InsightsView = lazy(() => import("./components/InsightsView"));
const NotFoundView = lazy(() => import("./components/NotFoundView"));
import { 
  ArrowUpRight, 
  TrendingUp, 
  Target, 
  Cpu, 
  CheckCircle2, 
  Layers, 
  ShieldCheck, 
  Award, 
  Send,
  Building,
  Check,
  ChevronRight,
  Activity,
  Sparkles,
  Zap
} from "lucide-react";
import { motion, useScroll, useTransform } from "motion/react";

function HeroSection() {
  const { t, locale } = useLanguage();
  const { scrollY } = useScroll();

  // Fine-tuned parallax scroll transforms for an ultra-premium deep multi-layered aesthetic
  const yBg1 = useTransform(scrollY, [0, 800], [0, 120]);
  const yBg2 = useTransform(scrollY, [0, 800], [0, -60]);
  const opacityBg = useTransform(scrollY, [0, 600], [1, 0.15]);
  const rotateBg = useTransform(scrollY, [0, 1000], [0, 25]);
  
  const stats = [
    { value: "$12M+", label: locale === "ar" ? "ميزانيات إعلانية مدارة" : "Managed Ad Budgets" },
    { value: "4.2x", label: locale === "ar" ? "متوسط عائد الاستثمار ROAS" : "Average ROI/ROAS" },
    { value: "94%", label: locale === "ar" ? "معدل استبقاء العملاء" : "Client Retention Rate" }
  ];

  return (
    <section 
      id="hero" 
      className="relative min-h-[90vh] flex flex-col justify-center py-20 border-b border-onyx-200/40 dark:border-white/5 overflow-hidden"
    >
      {/* Parallax Background Elements */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        {/* Luxury Geometric Ring */}
        <motion.div
          style={{ y: yBg1, rotate: rotateBg, opacity: opacityBg }}
          className="absolute -right-24 -top-24 w-96 sm:w-[500px] h-96 sm:h-[500px] rounded-full border border-brand-orange/15 dark:border-brand-orange/10 pointer-events-none"
        >
          {/* Inner concentric ring */}
          <div className="absolute inset-8 rounded-full border border-onyx-200/20 dark:border-white/[0.03]"></div>
          <div className="absolute inset-24 rounded-full border border-brand-orange/5 dark:border-brand-orange/[0.02]"></div>
          {/* Elegant accent coordinate marker */}
          <div className="absolute top-0 left-1/2 -translate-x-1/2 w-1.5 h-1.5 bg-brand-orange rounded-full"></div>
        </motion.div>

        {/* Serif Monogram watermark "M" */}
        <motion.div
          style={{ y: yBg2, opacity: opacityBg }}
          className="absolute right-12 bottom-12 font-serif text-[18vw] leading-none text-onyx-200/10 dark:text-white/[0.015] select-none pointer-events-none font-light uppercase tracking-tighter"
        >
          MG
        </motion.div>

        {/* Faint luxury blur glow */}
        <motion.div
          style={{ y: yBg1 }}
          className="absolute right-[10%] top-[20%] w-72 h-72 bg-brand-orange/5 dark:bg-brand-orange/[0.03] rounded-full blur-[100px] pointer-events-none"
        />
      </div>
      <div className="space-y-8 max-w-4xl relative z-10">
        {/* Luxury Tags */}
        <motion.div 
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="flex flex-wrap items-center gap-3"
        >
          <span className="px-3.5 py-1 rounded-full text-[10px] font-mono uppercase tracking-wider border border-brand-orange/40 text-brand-orange bg-brand-orange/5">
            {t("hero.badge")}
          </span>
          <span className="px-3.5 py-1 rounded-full text-[10px] font-mono uppercase tracking-wider border border-onyx-200 dark:border-white/10 text-onyx-500 dark:text-white/40 bg-onyx-100/50 dark:bg-white/5">
            {t("hero.subbadge")}
          </span>
        </motion.div>

        {/* Title / Name */}
        <div className="space-y-4">
          <motion.h1 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.1 }}
            className="font-serif text-5xl sm:text-7xl md:text-[84px] leading-[0.95] md:leading-[0.85] font-light tracking-tighter text-onyx-950 dark:text-white"
          >
            {portfolioData.personal.name.split(" ")[0]}{" "}
            <br className="hidden sm:inline" />
            <span className="text-onyx-400 dark:text-white/40">
              {portfolioData.personal.name.split(" ").slice(1).join(" ")}
            </span>
          </motion.h1>

          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="text-xl sm:text-2xl md:text-3xl font-light text-onyx-800 dark:text-white/80 leading-snug tracking-tight max-w-3xl"
          >
            {locale === "ar" ? portfolioData.personal.headline.ar : portfolioData.personal.headline.en}
          </motion.p>
        </div>

        {/* Editorial Method Border Callout */}
        <motion.p 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.3 }}
          className="text-sm sm:text-base text-onyx-500 dark:text-white/50 leading-relaxed max-w-2xl border-l-2 border-brand-orange pl-6 rtl:border-l-0 rtl:border-r-2 rtl:pl-0 rtl:pr-6"
        >
          {locale === "ar" ? portfolioData.personal.biography.ar : portfolioData.personal.biography.en}
        </motion.p>

        {/* CTA Actions */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.4 }}
          className="flex flex-wrap items-center gap-4 pt-4"
        >
          <a
            href="#projects"
            id="hero-cta-view"
            className="px-6 py-3 rounded-full bg-onyx-950 text-white dark:bg-white dark:text-onyx-950 text-xs font-mono uppercase tracking-wider font-semibold hover:bg-brand-orange dark:hover:bg-brand-orange hover:text-white dark:hover:text-white transition-all duration-300 shadow-lg hover:shadow-brand-orange/10 flex items-center gap-2"
          >
            <span>{t("hero.ctaView")}</span>
            <ChevronRight className="w-4 h-4 rtl:rotate-180" />
          </a>
          
          <a
            href="#/contact"
            id="hero-cta-book"
            className="px-6 py-3 rounded-full border border-onyx-200 dark:border-white/10 hover:border-brand-orange dark:hover:border-brand-orange text-onyx-700 dark:text-white hover:text-brand-orange dark:hover:text-brand-orange text-xs font-mono uppercase tracking-wider font-semibold transition-all duration-300 flex items-center gap-2"
          >
            <span>{t("hero.ctaBook")}</span>
            <ArrowUpRight className="w-4 h-4 text-brand-orange" />
          </a>
        </motion.div>

        {/* Executive Real-time Stats Grid */}
        <motion.div 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.8, delay: 0.5 }}
          className="grid grid-cols-1 sm:grid-cols-3 gap-6 pt-12 border-t border-onyx-200/40 dark:border-white/5"
        >
          {stats.map((st, idx) => (
            <div key={idx} className="space-y-1">
              <span className="font-mono text-[10px] uppercase tracking-widest text-onyx-400 dark:text-onyx-600 block">
                {st.label}
              </span>
              <span className="font-serif text-3xl sm:text-4xl font-light text-brand-orange">
                {st.value}
              </span>
            </div>
          ))}
        </motion.div>
      </div>

      {/* Decorative Gradient Line */}
      <div className="absolute right-0 bottom-0 left-0 h-[1px] bg-gradient-to-r from-transparent via-brand-orange/25 to-transparent"></div>
    </section>
  );
}

function AboutPreviewSection() {
  const { t, locale } = useLanguage();

  const methodologies = [
    { icon: Target, title: locale === "ar" ? "الاستهداف الدقيق" : "Absolute Targeting", desc: locale === "ar" ? "مواءمة الحملات مع المشترين الفعليين ذوي النية العالية." : "Aligning campaigns purely with high-intent qualified buyers." },
    { icon: TrendingUp, title: locale === "ar" ? "تحسين اقتصاديات الوحدة" : "Unit Economics", desc: locale === "ar" ? "تحقيق التوازن الرياضي بين كلفة الاستحواذ والقيمة الدائمة." : "Perfect mathematical balance between CAC and Lifetime Value." },
    { icon: Cpu, title: locale === "ar" ? "البنية التحتية والتحليلات" : "Data Infrastructure", desc: locale === "ar" ? "استخدام خوادم القياس والتحويل لضمان دقة نسب الإسناد." : "Leveraging Conversion APIs and precise attribution tracking models." }
  ];

  const containerVariants = {
    hidden: {},
    visible: {
      transition: {
        staggerChildren: 0.15,
      },
    },
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 30 },
    visible: {
      opacity: 1,
      y: 0,
      transition: {
        duration: 0.8,
        ease: [0.16, 1, 0.3, 1] as const,
      },
    },
  };

  return (
    <motion.section 
      id="about" 
      className="py-24 border-b border-onyx-200/40 dark:border-white/5 scroll-mt-16 relative"
      initial="hidden"
      whileInView="visible"
      viewport={{ once: true, amount: 0.15 }}
      variants={containerVariants}
    >
      {/* Subtle Persistent Left Margin Numbering */}
      <div className="hidden xl:flex absolute left-[-96px] top-24 flex-col items-center gap-3 select-none pointer-events-none">
        <span className="font-mono text-[10px] tracking-[0.3em] text-brand-orange font-bold">01</span>
        <div className="w-[1px] h-12 bg-brand-orange/30 dark:bg-brand-orange/20"></div>
      </div>
      <div className="grid grid-cols-1 lg:grid-cols-5 gap-16 items-start">
        {/* Left column: Editorial Label */}
        <motion.div variants={itemVariants} className="lg:col-span-2 space-y-6">
          <span className="font-mono text-[10px] uppercase tracking-[0.3em] text-brand-orange block font-bold">
            01 / PARADIGM
          </span>
          <h2 className="font-serif text-3xl sm:text-4xl lg:text-5xl font-light tracking-tight text-onyx-950 dark:text-white leading-tight">
            {t("about.title")}
          </h2>
          <p className="font-mono text-xs text-onyx-400 dark:text-onyx-600 tracking-widest uppercase">
            {t("about.subtitle")}
          </p>
          
          <div className="w-12 h-[1px] bg-brand-orange/40"></div>
        </motion.div>

        {/* Right column: Methodology Content */}
        <div className="lg:col-span-3 space-y-8">
          <motion.div variants={itemVariants} className="space-y-6 text-base sm:text-lg text-onyx-600 dark:text-white/70 font-light leading-relaxed">
            <p>{t("about.p1")}</p>
            <p>{t("about.p2")}</p>
          </motion.div>

          <motion.div variants={itemVariants} className="grid grid-cols-1 sm:grid-cols-3 gap-6 pt-8 border-t border-onyx-100 dark:border-white/5">
            {methodologies.map((m, idx) => {
              const Icon = m.icon;
              return (
                <div key={idx} className="space-y-2 p-4 rounded-xl hover:bg-onyx-100/30 dark:hover:bg-white/5 transition-all duration-300">
                  <div className="w-8 h-8 rounded-full bg-brand-orange/10 flex items-center justify-center text-brand-orange">
                    <Icon className="w-4 h-4" />
                  </div>
                  <h4 className="font-serif text-sm font-medium text-onyx-900 dark:text-white">
                    {m.title}
                  </h4>
                  <p className="text-xs text-onyx-400 dark:text-onyx-500 leading-normal">
                    {m.desc}
                  </p>
                </div>
              );
            })}
          </motion.div>
        </div>
      </div>
    </motion.section>
  );
}

function ServicesSection() {
  const { t, locale } = useLanguage();

  const containerVariants = {
    hidden: {},
    visible: {
      transition: {
        staggerChildren: 0.15,
      },
    },
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 30 },
    visible: {
      opacity: 1,
      y: 0,
      transition: {
        duration: 0.8,
        ease: [0.16, 1, 0.3, 1] as const,
      },
    },
  };

  return (
    <motion.section 
      id="services" 
      className="py-24 border-b border-onyx-200/40 dark:border-white/5 scroll-mt-16 relative"
      initial="hidden"
      whileInView="visible"
      viewport={{ once: true, amount: 0.15 }}
      variants={containerVariants}
    >
      {/* Subtle Persistent Left Margin Numbering */}
      <div className="hidden xl:flex absolute left-[-96px] top-24 flex-col items-center gap-3 select-none pointer-events-none">
        <span className="font-mono text-[10px] tracking-[0.3em] text-brand-orange font-bold">02</span>
        <div className="w-[1px] h-12 bg-brand-orange/30 dark:bg-brand-orange/20"></div>
      </div>
      <div className="space-y-12">
        {/* Header */}
        <motion.div variants={itemVariants} className="space-y-4 max-w-xl">
          <span className="font-mono text-[10px] uppercase tracking-[0.3em] text-brand-orange block font-bold">
            02 / SERVICES
          </span>
          <h2 className="font-serif text-3xl sm:text-4xl lg:text-5xl font-light tracking-tight text-onyx-950 dark:text-white">
            {t("services.title")}
          </h2>
          <p className="text-sm text-onyx-400 dark:text-onyx-500 font-mono">
            {t("services.subtitle")}
          </p>
        </motion.div>

        {/* Bento Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {portfolioData.services.map((svc) => (
            <motion.div 
              key={svc.id}
              variants={itemVariants}
              className="group p-8 rounded-2xl border border-onyx-200/40 bg-white/50 dark:border-white/5 dark:bg-[#0c0c0c]/40 luxury-blur flex flex-col justify-between hover:border-brand-orange/40 transition-all duration-400 h-full"
            >
              <div className="space-y-6">
                {/* Visual Accent */}
                <div className="flex justify-between items-center">
                  <div className="w-10 h-10 rounded-full border border-onyx-100 dark:border-white/10 flex items-center justify-center text-brand-orange group-hover:bg-brand-orange group-hover:text-white transition-all duration-300">
                    <Layers className="w-4 h-4" />
                  </div>
                  <span className="font-mono text-[9px] uppercase tracking-widest text-onyx-300 dark:text-onyx-700">
                    Svc // {svc.id.toUpperCase()}
                  </span>
                </div>

                <div className="space-y-3">
                  <h3 className="font-serif text-xl font-medium tracking-tight text-onyx-900 dark:text-white">
                    {locale === "ar" ? svc.title.ar : svc.title.en}
                  </h3>
                  <p className="text-xs sm:text-sm text-onyx-500 dark:text-white/50 leading-relaxed">
                    {locale === "ar" ? svc.description.ar : svc.description.en}
                  </p>
                </div>

                {/* Features Checkbox Grid */}
                <ul className="space-y-2 pt-4 border-t border-onyx-100 dark:border-white/5">
                  {(locale === "ar" ? svc.features.ar : svc.features.en).map((feat, fIdx) => (
                    <li key={fIdx} className="flex items-start gap-2 text-xs text-onyx-600 dark:text-white/60">
                      <Check className="w-3.5 h-3.5 text-brand-orange shrink-0 mt-0.5" />
                      <span>{feat}</span>
                    </li>
                  ))}
                </ul>
              </div>

              <div className="pt-8">
                <a 
                  href="#/contact"
                  className="inline-flex items-center gap-1 text-[11px] font-mono uppercase tracking-wider text-onyx-400 hover:text-brand-orange group-hover:translate-x-1 transition-all duration-300"
                >
                  <span>{t("services.ctaInquire")}</span>
                  <ArrowUpRight className="w-3.5 h-3.5" />
                </a>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </motion.section>
  );
}

function ProjectsSection() {
  const { t, locale } = useLanguage();

  const containerVariants = {
    hidden: {},
    visible: {
      transition: {
        staggerChildren: 0.15,
      },
    },
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 30 },
    visible: {
      opacity: 1,
      y: 0,
      transition: {
        duration: 0.8,
        ease: [0.16, 1, 0.3, 1] as const,
      },
    },
  };

  return (
    <motion.section 
      id="projects" 
      className="py-24 border-b border-onyx-200/40 dark:border-white/5 scroll-mt-16 relative"
      initial="hidden"
      whileInView="visible"
      viewport={{ once: true, amount: 0.15 }}
      variants={containerVariants}
    >
      {/* Subtle Persistent Left Margin Numbering */}
      <div className="hidden xl:flex absolute left-[-96px] top-24 flex-col items-center gap-3 select-none pointer-events-none">
        <span className="font-mono text-[10px] tracking-[0.3em] text-brand-orange font-bold">03</span>
        <div className="w-[1px] h-12 bg-brand-orange/30 dark:bg-brand-orange/20"></div>
      </div>
      <div className="space-y-16">
        {/* Header */}
        <motion.div variants={itemVariants} className="flex flex-col md:flex-row md:items-end justify-between gap-6">
          <div className="space-y-4">
            <span className="font-mono text-[10px] uppercase tracking-[0.3em] text-brand-orange block font-bold">
              03 / IMPACT PROOFS
            </span>
            <h2 className="font-serif text-3xl sm:text-4xl lg:text-5xl font-light tracking-tight text-onyx-950 dark:text-white">
              {t("projects.title")}
            </h2>
            <p className="text-sm text-onyx-400 dark:text-onyx-500 font-mono">
              {t("projects.subtitle")}
            </p>
          </div>
          <span className="px-3 py-1 rounded-full border border-onyx-200 dark:border-white/10 text-[10px] font-mono uppercase tracking-widest text-onyx-400 dark:text-white/40 bg-onyx-100/50 dark:bg-white/5 h-fit shrink-0">
            {t("projects.badge")}
          </span>
        </motion.div>

        {/* Case Studies Display Grid */}
        <div className="space-y-12">
          {portfolioData.projects.map((proj, idx) => (
            <motion.div 
              key={proj.id}
              variants={itemVariants}
              className="p-8 md:p-12 rounded-2xl border border-onyx-200/40 bg-white/50 dark:border-white/5 dark:bg-[#0c0c0c]/40 luxury-blur grid grid-cols-1 lg:grid-cols-12 gap-8 items-center relative overflow-hidden group hover:border-brand-orange/20 transition-all duration-400"
            >
              {/* Giant Metric Display (McKinsey Style) */}
              <div className="lg:col-span-4 space-y-2 border-r border-onyx-100 dark:border-white/5 pr-6 rtl:border-r-0 rtl:border-l rtl:pr-0 rtl:pl-6 text-left">
                <span className="font-mono text-[10px] uppercase tracking-widest text-onyx-400 dark:text-onyx-600 block">
                  {locale === "ar" ? proj.category.ar : proj.category.en}
                </span>
                <div className="font-serif text-6xl md:text-7xl lg:text-8xl font-light text-brand-orange tracking-tighter">
                  {proj.metric}
                </div>
                <span className="font-mono text-xs text-onyx-700 dark:text-white/60 block font-medium">
                  {locale === "ar" ? proj.metricLabel.ar : proj.metricLabel.en}
                </span>
              </div>

              {/* Case details */}
              <div className="lg:col-span-8 space-y-6">
                <div className="space-y-3">
                  <h3 className="font-serif text-2xl font-light text-onyx-950 dark:text-white">
                    {locale === "ar" ? proj.title.ar : proj.title.en}
                  </h3>
                  <p className="text-sm sm:text-base text-onyx-500 dark:text-white/50 leading-relaxed">
                    {locale === "ar" ? proj.description.ar : proj.description.en}
                  </p>
                </div>

                <div className="space-y-3">
                  <span className="font-mono text-[9px] uppercase tracking-widest text-onyx-400 dark:text-onyx-600 block">
                    {t("projects.deliverables")}
                  </span>
                  <div className="flex flex-wrap gap-2">
                    {(locale === "ar" ? proj.deliverables.ar : proj.deliverables.en).map((del, dIdx) => (
                      <span 
                        key={dIdx}
                        className="px-2.5 py-1 rounded bg-onyx-100/50 dark:bg-white/5 text-[10px] font-mono text-onyx-600 dark:text-white/50 border border-onyx-200/40 dark:border-white/5"
                      >
                        {del}
                      </span>
                    ))}
                  </div>
                </div>
              </div>

              {/* Minimal Accent line */}
              <div className="absolute top-0 right-0 w-[4px] h-full bg-brand-orange opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
            </motion.div>
          ))}
        </div>
      </div>
    </motion.section>
  );
}

function ExperienceSection() {
  const { t, locale } = useLanguage();

  const containerVariants = {
    hidden: {},
    visible: {
      transition: {
        staggerChildren: 0.15,
      },
    },
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 30 },
    visible: {
      opacity: 1,
      y: 0,
      transition: {
        duration: 0.8,
        ease: [0.16, 1, 0.3, 1] as const,
      },
    },
  };

  return (
    <motion.section 
      id="experience" 
      className="py-24 border-b border-onyx-200/40 dark:border-white/5 scroll-mt-16 relative"
      initial="hidden"
      whileInView="visible"
      viewport={{ once: true, amount: 0.15 }}
      variants={containerVariants}
    >
      {/* Subtle Persistent Left Margin Numbering */}
      <div className="hidden xl:flex absolute left-[-96px] top-24 flex-col items-center gap-3 select-none pointer-events-none">
        <span className="font-mono text-[10px] tracking-[0.3em] text-brand-orange font-bold">04</span>
        <div className="w-[1px] h-12 bg-brand-orange/30 dark:bg-brand-orange/20"></div>
      </div>
      <div className="grid grid-cols-1 lg:grid-cols-5 gap-16 items-start">
        {/* Left column: Badge & Title */}
        <motion.div variants={itemVariants} className="lg:col-span-2 space-y-6">
          <span className="font-mono text-[10px] uppercase tracking-[0.3em] text-brand-orange block font-bold">
            04 / CAREER LEDGER
          </span>
          <h2 className="font-serif text-3xl sm:text-4xl lg:text-5xl font-light tracking-tight text-onyx-950 dark:text-white leading-tight">
            {t("experience.title")}
          </h2>
          <p className="font-mono text-xs text-onyx-400 dark:text-onyx-600 tracking-widest uppercase">
            {t("experience.subtitle")}
          </p>

          <div className="w-12 h-[1px] bg-brand-orange/40"></div>
        </motion.div>

        {/* Right column: Experience Chronology */}
        <div className="lg:col-span-3 space-y-12">
          {portfolioData.experience.map((exp) => (
            <motion.div 
              key={exp.id}
              variants={itemVariants}
              className="space-y-4 border-b border-onyx-100 dark:border-white/5 pb-8 last:border-b-0 last:pb-0"
            >
              {/* Role Header */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                <div className="space-y-1">
                  <h3 className="font-serif text-xl font-medium text-onyx-950 dark:text-white">
                    {locale === "ar" ? exp.role.ar : exp.role.en}
                  </h3>
                  <p className="text-xs text-brand-orange font-mono font-medium">
                    {locale === "ar" ? exp.company.ar : exp.company.en}
                  </p>
                </div>
                <span className="font-mono text-xs text-onyx-400 dark:text-onyx-500 bg-onyx-100/50 dark:bg-white/5 px-3 py-1 rounded-full border border-onyx-200/40 dark:border-white/5 w-fit">
                  {exp.period}
                </span>
              </div>

              {/* Role Summary */}
              <p className="text-xs sm:text-sm text-onyx-500 dark:text-white/50 leading-relaxed font-light">
                {locale === "ar" ? exp.description.ar : exp.description.en}
              </p>

              {/* Bullets */}
              <ul className="space-y-2 pt-2">
                {(locale === "ar" ? exp.highlights.ar : exp.highlights.en).map((hl, hlIdx) => (
                  <li key={hlIdx} className="flex items-start gap-2 text-xs text-onyx-600 dark:text-white/60">
                    <CheckCircle2 className="w-4 h-4 text-brand-orange shrink-0 mt-0.5" />
                    <span>{hl}</span>
                  </li>
                ))}
              </ul>
            </motion.div>
          ))}
        </div>
      </div>
    </motion.section>
  );
}

function IndustriesSection() {
  const { t, locale } = useLanguage();

  const containerVariants = {
    hidden: {},
    visible: {
      transition: {
        staggerChildren: 0.15,
      },
    },
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 30 },
    visible: {
      opacity: 1,
      y: 0,
      transition: {
        duration: 0.8,
        ease: [0.16, 1, 0.3, 1] as const,
      },
    },
  };

  return (
    <motion.section 
      id="industries" 
      className="py-24 border-b border-onyx-200/40 dark:border-white/5 scroll-mt-16 relative"
      initial="hidden"
      whileInView="visible"
      viewport={{ once: true, amount: 0.15 }}
      variants={containerVariants}
    >
      {/* Subtle Persistent Left Margin Numbering */}
      <div className="hidden xl:flex absolute left-[-96px] top-24 flex-col items-center gap-3 select-none pointer-events-none">
        <span className="font-mono text-[10px] tracking-[0.3em] text-brand-orange font-bold">05</span>
        <div className="w-[1px] h-12 bg-brand-orange/30 dark:bg-brand-orange/20"></div>
      </div>
      <div className="space-y-12">
        {/* Header */}
        <motion.div variants={itemVariants} className="space-y-4 max-w-xl">
          <span className="font-mono text-[10px] uppercase tracking-[0.3em] text-brand-orange block font-bold">
            05 / SECTORS & INDUSTRIES
          </span>
          <h2 className="font-serif text-3xl sm:text-4xl lg:text-5xl font-light tracking-tight text-onyx-950 dark:text-white">
            {t("industries.title")}
          </h2>
          <p className="text-xs text-onyx-400 dark:text-onyx-500 font-mono">
            {t("industries.subtitle")}
          </p>
        </motion.div>

        {/* Content & Progress Columns */}
        <div className="grid grid-cols-1 lg:grid-cols-5 gap-12 items-center">
          <motion.div variants={itemVariants} className="lg:col-span-2 space-y-6">
            <p className="text-xs sm:text-sm text-onyx-500 dark:text-white/50 leading-relaxed font-light">
              {t("industries.description")}
            </p>
            <div className="p-4 rounded-xl border border-onyx-100 dark:border-white/5 bg-onyx-50/50 dark:bg-white/5 flex items-center gap-3">
              <Zap className="w-5 h-5 text-brand-orange" />
              <span className="text-[11px] font-mono uppercase tracking-wider text-onyx-600 dark:text-white/40">
                100% Data Protection Compliant Architecture
              </span>
            </div>
          </motion.div>

          <motion.div variants={itemVariants} className="lg:col-span-3 space-y-6">
            {portfolioData.industries.map((ind) => (
              <div key={ind.id} className="space-y-2 p-4 rounded-xl border border-onyx-100 dark:border-white/5 hover:border-brand-orange/20 transition-all duration-300">
                <div className="flex justify-between items-center text-xs font-mono">
                  <span className="text-onyx-800 dark:text-white/80 font-medium">
                    {locale === "ar" ? ind.name.ar : ind.name.en}
                  </span>
                  <span className="text-brand-orange font-bold">
                    {ind.percentage}
                  </span>
                </div>
                {/* Custom styled progress gauge bar */}
                <div className="w-full h-1.5 bg-onyx-100 dark:bg-white/5 rounded-full overflow-hidden">
                  <motion.div 
                    className="h-full bg-brand-orange rounded-full" 
                    initial={{ width: 0 }}
                    whileInView={{ width: ind.percentage }}
                    viewport={{ once: true }}
                    transition={{ duration: 1.2, ease: [0.16, 1, 0.3, 1], delay: 0.1 }}
                  />
                </div>
                <p className="text-[11px] text-onyx-400 dark:text-onyx-500">
                  {locale === "ar" ? ind.description.ar : ind.description.en}
                </p>
              </div>
            ))}
          </motion.div>
        </div>
      </div>
    </motion.section>
  );
}

function ContactSection() {
  const { t } = useLanguage();
  const [formState, setFormState] = useState({ name: "", company: "", email: "", message: "" });
  const [status, setStatus] = useState<"idle" | "sending" | "success" | "error">("idle");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formState.name || !formState.email || !formState.message) {
      setStatus("error");
      return;
    }

    setStatus("sending");
    
    // Simulate luxury API response transmission
    setTimeout(() => {
      setStatus("success");
      setFormState({ name: "", company: "", email: "", message: "" });
    }, 1500);
  };

  const containerVariants = {
    hidden: {},
    visible: {
      transition: {
        staggerChildren: 0.15,
      },
    },
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 30 },
    visible: {
      opacity: 1,
      y: 0,
      transition: {
        duration: 0.8,
        ease: [0.16, 1, 0.3, 1] as const,
      },
    },
  };

  return (
    <motion.section 
      id="contact" 
      className="py-24 scroll-mt-16 relative"
      initial="hidden"
      whileInView="visible"
      viewport={{ once: true, amount: 0.15 }}
      variants={containerVariants}
    >
      {/* Subtle Persistent Left Margin Numbering */}
      <div className="hidden xl:flex absolute left-[-96px] top-24 flex-col items-center gap-3 select-none pointer-events-none">
        <span className="font-mono text-[10px] tracking-[0.3em] text-brand-orange font-bold">06</span>
        <div className="w-[1px] h-12 bg-brand-orange/30 dark:bg-brand-orange/20"></div>
      </div>
      <div className="grid grid-cols-1 lg:grid-cols-5 gap-16 items-start">
        {/* Call of inquiry */}
        <motion.div variants={itemVariants} className="lg:col-span-2 space-y-6">
          <span className="font-mono text-[10px] uppercase tracking-[0.3em] text-brand-orange block font-bold">
            06 / CONTACT & AUDIT
          </span>
          <h2 className="font-serif text-3xl sm:text-4xl lg:text-5xl font-light tracking-tight text-onyx-950 dark:text-white leading-tight">
            {t("cta.title")}
          </h2>
          <p className="text-sm text-onyx-500 dark:text-white/50 leading-relaxed font-light">
            {t("cta.subtitle")}
          </p>
          
          <div className="pt-6 border-t border-onyx-200/40 dark:border-white/5 space-y-2">
            <span className="font-mono text-[9px] uppercase tracking-widest text-onyx-400 dark:text-onyx-600 block">Office Hours</span>
            <span className="text-xs text-onyx-600 dark:text-white/70 block">Sunday – Thursday (09:00 – 18:00 EET)</span>
            <span className="text-xs text-brand-orange block font-mono">Response Protocol: &lt; 24 Hours</span>
          </div>
        </motion.div>

        {/* Dynamic Secure Transmission Form */}
        <motion.div variants={itemVariants} className="lg:col-span-3 p-8 rounded-2xl border border-onyx-200/40 bg-white/50 dark:border-white/5 dark:bg-[#0c0c0c]/40 luxury-blur">
          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="space-y-2">
              <label className="font-mono text-[10px] uppercase tracking-widest text-onyx-500 dark:text-onyx-400 block">
                {t("cta.name")} *
              </label>
              <input 
                type="text" 
                required
                value={formState.name}
                onChange={(e) => setFormState({ ...formState, name: e.target.value })}
                className="w-full px-4 py-3 rounded-xl border border-onyx-200/60 dark:border-white/10 bg-white/30 dark:bg-white/5 text-onyx-900 dark:text-white focus:outline-none focus:border-brand-orange dark:focus:border-brand-orange text-sm font-sans transition-colors"
                placeholder="Mahmoud Gamal Akl"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
              <div className="space-y-2">
                <label className="font-mono text-[10px] uppercase tracking-widest text-onyx-500 dark:text-onyx-400 block">
                  {t("cta.company")}
                </label>
                <input 
                  type="text" 
                  value={formState.company}
                  onChange={(e) => setFormState({ ...formState, company: e.target.value })}
                  className="w-full px-4 py-3 rounded-xl border border-onyx-200/60 dark:border-white/10 bg-white/30 dark:bg-white/5 text-onyx-900 dark:text-white focus:outline-none focus:border-brand-orange dark:focus:border-brand-orange text-sm font-sans transition-colors"
                  placeholder="Enterprise Inc."
                />
              </div>

              <div className="space-y-2">
                <label className="font-mono text-[10px] uppercase tracking-widest text-onyx-500 dark:text-onyx-400 block">
                  {t("cta.email")} *
                </label>
                <input 
                  type="email" 
                  required
                  value={formState.email}
                  onChange={(e) => setFormState({ ...formState, email: e.target.value })}
                  className="w-full px-4 py-3 rounded-xl border border-onyx-200/60 dark:border-white/10 bg-white/30 dark:bg-white/5 text-onyx-900 dark:text-white focus:outline-none focus:border-brand-orange dark:focus:border-brand-orange text-sm font-sans transition-colors"
                  placeholder="name@company.com"
                />
              </div>
            </div>

            <div className="space-y-2">
              <label className="font-mono text-[10px] uppercase tracking-widest text-onyx-500 dark:text-onyx-400 block">
                {t("cta.message")} *
              </label>
              <textarea 
                rows={4}
                required
                value={formState.message}
                onChange={(e) => setFormState({ ...formState, message: e.target.value })}
                className="w-full px-4 py-3 rounded-xl border border-onyx-200/60 dark:border-white/10 bg-white/30 dark:bg-white/5 text-onyx-900 dark:text-white focus:outline-none focus:border-brand-orange dark:focus:border-brand-orange text-sm font-sans transition-colors resize-none"
                placeholder="Briefly define your current pipeline status & performance bottlenecks..."
              />
            </div>

            <button
              type="submit"
              disabled={status === "sending"}
              className="w-full py-3.5 rounded-xl bg-onyx-950 text-white dark:bg-white dark:text-onyx-950 hover:bg-brand-orange dark:hover:bg-brand-orange hover:text-white dark:hover:text-white font-mono uppercase tracking-widest text-xs font-semibold transition-all duration-300 disabled:opacity-50 flex items-center justify-center gap-2 cursor-pointer"
            >
              {status === "sending" ? (
                <>
                  <span className="w-3.5 h-3.5 border-2 border-current border-t-transparent rounded-full animate-spin"></span>
                  <span>{t("cta.sending")}</span>
                </>
              ) : (
                <>
                  <Send className="w-3.5 h-3.5" />
                  <span>{t("cta.button")}</span>
                </>
              )}
            </button>

            {status === "success" && (
              <div className="p-4 rounded-xl bg-green-500/10 border border-green-500/20 text-green-600 dark:text-green-400 text-xs font-mono">
                {t("cta.success")}
              </div>
            )}

            {status === "error" && (
              <div className="p-4 rounded-xl bg-red-500/10 border border-red-500/20 text-red-600 dark:text-red-400 text-xs font-mono">
                {t("cta.error")}
              </div>
            )}
          </form>
        </motion.div>
      </div>
    </motion.section>
  );
}

function MainLandingPage() {
  return (
    <div className="max-w-7xl mx-auto px-6 space-y-12">
      <HeroSection />
      <AboutPreviewSection />
      <ServicesSection />
      <ProjectsSection />
      <ExperienceSection />
      <IndustriesSection />
      <ContactSection />
    </div>
  );
}

export default function App() {
  const [hash, setHash] = useState(window.location.hash);
  const [isInitialLoading, setIsInitialLoading] = useState(true);

  useEffect(() => {
    // Elegant intro load sequencer for premium UX and CLS performance
    const timer = setTimeout(() => {
      setIsInitialLoading(false);
    }, 850);
    return () => clearTimeout(timer);
  }, []);

  useEffect(() => {
    const handleHashChange = () => {
      setHash(window.location.hash);
      
      // Handle page scroll transitions
      if (!window.location.hash.startsWith('#/about') && !window.location.hash.startsWith('#/services') && !window.location.hash.startsWith('#/experience') && !window.location.hash.startsWith('#/projects') && !window.location.hash.startsWith('#/skills') && !window.location.hash.startsWith('#/contact') && !window.location.hash.startsWith('#/insights')) {
        const targetId = window.location.hash.replace('#', '');
        if (targetId && targetId !== '/' && targetId !== 'main-content-canvas') {
          setTimeout(() => {
            const element = document.getElementById(targetId);
            if (element) {
              element.scrollIntoView({ behavior: 'smooth' });
            }
          }, 100);
        }
      } else {
        window.scrollTo({ top: 0, behavior: 'instant' });
      }
    };

    window.addEventListener('hashchange', handleHashChange);
    handleHashChange();

    return () => window.removeEventListener('hashchange', handleHashChange);
  }, []);

  if (isInitialLoading) {
    return <LoadingPage fullScreen={true} />;
  }

  const isAboutView = hash.startsWith('#/about');
  const isServicesView = hash.startsWith('#/services');
  const isExperienceView = hash.startsWith('#/experience');
  const isProjectsView = hash.startsWith('#/projects');
  const isSkillsView = hash.startsWith('#/skills');
  const isContactView = hash.startsWith('#/contact');
  const isInsightsView = hash.startsWith('#/insights');

  const isValidHashRoute = 
    hash === "" || 
    hash === "#" || 
    hash === "#/" || 
    isAboutView || 
    isServicesView || 
    isExperienceView || 
    isProjectsView || 
    isSkillsView || 
    isContactView || 
    isInsightsView || 
    (!hash.startsWith("#/"));

  return (
    <ErrorBoundary>
      <GlobalLayout>
        <Suspense fallback={<LoadingPage fullScreen={false} />}>
          {!isValidHashRoute ? (
            <NotFoundView />
          ) : isAboutView ? (
            <AboutView />
          ) : isServicesView ? (
            <ServicesView />
          ) : isExperienceView ? (
            <ExperienceView />
          ) : isProjectsView ? (
            <ProjectsView />
          ) : isSkillsView ? (
            <SkillsView />
          ) : isContactView ? (
            <ContactView />
          ) : isInsightsView ? (
            <InsightsView />
          ) : (
            <MainLandingPage />
          )}
        </Suspense>
      </GlobalLayout>
    </ErrorBoundary>
  );
}
