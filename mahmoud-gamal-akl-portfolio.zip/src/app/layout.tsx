import React, { useEffect } from "react";
import { ThemeProvider } from "../components/ThemeContext";
import { LanguageProvider, useLanguage } from "../components/LanguageContext";
import Navigation from "../components/Navigation";
import Footer from "../components/Footer";
import JsonLd from "../components/JsonLd";
import ScrollProgress from "../components/ScrollProgress";
import BackToTop from "../components/BackToTop";
import { updateDocumentMetadata } from "../lib/metadata";

/**
 * Inner layout wrapper to access LanguageContext.
 * This ensures we can update document meta heads dynamically on language toggle.
 */
function LayoutContent({ children }: { children: React.ReactNode }) {
  const { locale, dir } = useLanguage();

  useEffect(() => {
    // Inject and update SEO meta tags and open graph tags on change
    updateDocumentMetadata(locale);
  }, [locale]);

  return (
    <div 
      id="app-root-layout"
      dir={dir} 
      className="min-h-screen flex flex-col transition-colors duration-500 bg-onyx-50 dark:bg-[#050505]"
    >
      {/* Structural Border Layout Frame (Hidden on small screens, fixed on xl screens for crisp editorial alignment) */}
      <div className="hidden xl:block fixed inset-0 border-[16px] border-[#0F0F0F] pointer-events-none z-50"></div>

      {/* Elegant scroll progress bar indicator */}
      <ScrollProgress />

      {/* Floating back to top button */}
      <BackToTop />

      {/* Dynamic Premium Decorative Background Glow */}
      <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-[#F27D26]/5 dark:bg-[#F27D26]/5 rounded-full blur-[120px] translate-x-1/4 -translate-y-1/4 pointer-events-none"></div>

      {/* Dynamic SEO JSON-LD Person Schema */}
      <JsonLd />
      
      {/* Sticky Premium Navigation */}
      <Navigation />

      {/* Primary Page Canvas */}
      <main id="main-content-canvas" className="flex-grow w-full relative">
        {children}
      </main>

      {/* Elite Corporate Footer */}
      <Footer />
    </div>
  );
}

/**
 * Global Layout mirroring Next.js 15 layout structures.
 * Wraps the app in luxury styling variables, theme controls, and translation frameworks.
 */
export default function GlobalLayout({ children }: { children: React.ReactNode }) {
  return (
    <LanguageProvider>
      <ThemeProvider>
        <LayoutContent>{children}</LayoutContent>
      </ThemeProvider>
    </LanguageProvider>
  );
}
