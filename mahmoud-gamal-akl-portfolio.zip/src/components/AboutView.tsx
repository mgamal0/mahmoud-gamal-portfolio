import React from "react";
import { useLanguage } from "./LanguageContext";
import { portfolioData } from "../data/portfolio";
import { 
  ShieldCheck, 
  Award, 
  Cpu, 
  Compass, 
  Target, 
  Briefcase, 
  Calendar,
  Globe2,
  Bookmark,
  CheckCircle2,
  ChevronLeft,
  ArrowRight
} from "lucide-react";
import { motion } from "motion/react";

export default function AboutView() {
  const { t, locale, dir } = useLanguage();

  // Summary translation
  const executiveSummary = {
    en: "I help businesses build scalable marketing systems through performance marketing, positioning, customer acquisition and business strategy.",
    ar: "أساعد الشركات والمؤسسات على بناء أنظمة تسويقية قابلة للتوسع والقياس عبر هندسة تسويق الأداء، وتحديد التموضع الإستراتيجي الفعّال، واستراتيجيات جذب العملاء، ونمو الأعمال."
  };

  // Approach points
  const approachPoints = [
    {
      id: "app-1",
      title: {
        en: "Mathematical Rigor",
        ar: "الصرامة الرياضية والتحليلية"
      },
      desc: {
        en: "We discard aesthetic metrics in favor of unit economic equations. Every campaign is calculated against lifetime value and customer acquisition costs.",
        ar: "نتجاوز مقاييس المشاهدات والظهور السطحية لصالح معادلات اقتصادية الوحدة. تُحسب كل حملة بدقة متناهية مقارنة بالقيمة الدائمة للعميل وتكلفة الاستحواذ."
      }
    },
    {
      id: "app-2",
      title: {
        en: "Engineered Funnels",
        ar: "هندسة مسارات المبيعات والتحويل"
      },
      desc: {
        en: "Designing end-to-end customer acquisition architectures that minimize friction, automate engagement, and seamlessly hand off high-value opportunities to sales teams.",
        ar: "تصميم قنوات ومسارات جذب العملاء المتكاملة لتقليل حواجز التحويل، وأتمتة التفاعل المخصص، وتسليم الفرص عالية القيمة بسلاسة لفرق المبيعات."
      }
    },
    {
      id: "app-3",
      title: {
        en: "Deep Brand Psychology",
        ar: "علم نفس العلامات التجارية المتقدم"
      },
      desc: {
        en: "Marrying high-performance computational media buying with elegant corporate positioning to capture dominant mental shelf space inside high-net-worth target demographics.",
        ar: "الجمع بين شراء المساحات الإعلانية الحسابية عالية الأداء والتموضع المؤسسي الأنيق والراقي للاستحواذ على وعي العملاء المستهدفين الأكثر ملاءمة."
      }
    }
  ];

  // Philosophy statement
  const philosophyData = {
    title: {
      en: "Working Philosophy",
      ar: "فلسفة العمل والمنهجية"
    },
    quote: {
      en: "Marketing is not a department of creative experiments; it is a critical capital allocation engine. Treat it with the same engineering precision as a software architecture or financial model.",
      ar: "التسويق ليس مجرد قسم للتجارب الإبداعية الفوضوية؛ بل هو محرك حيوي لتخصيص رأس المال. يجب معاملته بنفس الدقة الهندسية المتبعة في تصميم البرمجيات والأنظمة المالية المعقدة."
    },
    p1: {
      en: "I believe that the best marketing infrastructure is built in-house. Traditional agencies are fundamentally misaligned with client goals, relying on billable hours and opaque media margins. My operational paradigm is to design, implement, and transition premium marketing engines directly to client teams, leaving behind robust compounding systems.",
      ar: "أؤمن جازماً بأن أفضل بنية تحتية تسويقية هي تلك التي يتم بناؤها وتطويرها داخلياً. تتبنى الوكالات التقليدية أهدافاً لا تتوافق مع مصلحة العميل الحقيقية، إذ تعتمد على ساعات العمل القابلة للفوترة وهامش المبيعات غير الواضح. تتمثل منهجيتي التشغيلية في تصميم الأنظمة الرفيعة وتنفيذها ونقل ملكيتها الإدارية الكاملة لفرق العميل."
    }
  };

  // Values
  const executiveValues = [
    {
      icon: ShieldCheck,
      title: { en: "Absolute Truth & Data Authenticity", ar: "الشفافية المطلقة وصدقية البيانات" },
      desc: { en: "No vanity reporting. We build pixel-perfect attribution pipelines linking ad spend directly to bank transactions.", ar: "لا تقارير مظهرية أو مزيفة. نبني قنوات تتبع بالغة الدقة تربط الإنفاق الإعلاني مباشرة بالتدفقات المالية والعمليات المحققة." }
    },
    {
      icon: Award,
      title: { en: "Compounding Brand Value", ar: "بناء القيمة التراكمية للعلامة" },
      desc: { en: "Every campaign must generate immediate revenue while strengthening premium positioning and pricing power.", ar: "يجب أن تحقق كل حملة إيرادات فورية سريعة مع تعزيز التموضع الاستراتيجي وقوة التسعير الخاصة بالمؤسسة على المدى الطويل." }
    },
    {
      icon: Cpu,
      title: { en: "Self-Sustaining Infrastructure", ar: "البنية التشغيلية ذاتية الاستدامة" },
      desc: { en: "I build to exit. The goal is to empower client teams with the capability, standard playbooks, and systems to execute autonomously.", ar: "أبني الأنظمة لتستمر بشكل مستقل. الهدف هو تزويد فرق العميل بالقدرة التشغيلية، وكتيبات العمل المعيارية لإدارتها ذاتياً بامتياز." }
    }
  ];

  // Languages data
  const languagesList = [
    { code: "ar", name: { en: "Arabic", ar: "العربية" }, level: { en: "Native (Mother Tongue)", ar: "اللغة الأم (بطلاقة مطلقة)" }, percentage: "100%" },
    { code: "en", name: { en: "English", ar: "الإنجليزية" }, level: { en: "Professional Fluent", ar: "تحدث وكتابة مهنية بطلاقة" }, percentage: "95%" }
  ];

  return (
    <div id="about-profile-container" className="min-h-screen py-16 px-6 max-w-7xl mx-auto space-y-24 relative z-10">
      
      {/* Editorial Navigation breadcrumb / Back Button */}
      <div className="flex justify-between items-center pb-4 border-b border-onyx-200/40 dark:border-white/5">
        <a 
          href="#/" 
          className="inline-flex items-center gap-2 text-xs font-mono uppercase tracking-widest text-onyx-400 hover:text-brand-orange transition-colors group"
        >
          <ChevronLeft className="w-4 h-4 group-hover:-translate-x-1 transition-transform rtl:rotate-180" />
          <span>{locale === "ar" ? "العودة للرئيسية" : "Return to Systems Overview"}</span>
        </a>
        <span className="font-mono text-[9px] uppercase tracking-widest text-onyx-300 dark:text-white/20">
          Executive Portfolio // Document Ref-1994
        </span>
      </div>

      {/* Title / Header Block: Grand Executive Profile */}
      <section className="space-y-8 max-w-5xl">
        <div className="space-y-4">
          <div className="flex items-center gap-3">
            <span className="w-1.5 h-1.5 bg-brand-orange rounded-full animate-ping"></span>
            <span className="font-mono text-[10px] uppercase tracking-[0.35em] text-brand-orange font-bold">
              {locale === "ar" ? "ملف استشاري تنفيذي" : "EXECUTIVE STRATEGIST PROFILE"}
            </span>
          </div>

          <h1 className="font-serif text-5xl sm:text-7xl md:text-[96px] leading-[0.9] font-light tracking-tighter text-onyx-950 dark:text-white">
            {portfolioData.personal.name.split(" ")[0]}{" "}
            <span className="text-onyx-400 dark:text-white/30">
              {portfolioData.personal.name.split(" ").slice(1).join(" ")}
            </span>
          </h1>
          
          <p className="font-mono text-xs sm:text-sm text-brand-orange uppercase tracking-[0.25em] font-medium">
            {locale === "ar" ? "خبير ومستشار تسويق الأداء وجذب العملاء" : "Principal Consultant — Performance Marketing & Funnel Systems"}
          </p>
        </div>

        {/* Master Statement Quote / Core Value Proposition */}
        <div className="p-8 md:p-12 rounded-3xl border border-brand-orange/20 bg-brand-orange/5 dark:bg-[#F27D26]/5 relative overflow-hidden">
          <div className="absolute top-0 right-0 p-8 text-brand-orange/10 pointer-events-none select-none text-9xl font-serif leading-none font-bold">
            “
          </div>
          <p className="font-serif text-2xl sm:text-3xl md:text-4xl lg:text-[40px] leading-tight font-light text-onyx-900 dark:text-white max-w-4xl relative z-10 border-l-4 border-brand-orange pl-6 md:pl-8 rtl:border-l-0 rtl:border-r-4 rtl:pl-0 rtl:pr-8">
            {locale === "ar" ? executiveSummary.ar : executiveSummary.en}
          </p>
        </div>
      </section>

      {/* Professional Biography Grid */}
      <section className="grid grid-cols-1 lg:grid-cols-5 gap-16 items-start">
        <div className="lg:col-span-2 space-y-6">
          <span className="font-mono text-[10px] uppercase tracking-[0.3em] text-brand-orange block font-bold">
            BIOGRAPHY
          </span>
          <h2 className="font-serif text-3xl sm:text-4xl font-light tracking-tight text-onyx-950 dark:text-white">
            {locale === "ar" ? "السيرة والمسيرة المهنية" : "The Architectural Mindset"}
          </h2>
          <div className="space-y-4 font-mono text-xs text-onyx-400 dark:text-onyx-500">
            <p>Based: Cairo & Dubai</p>
            <p>Focus: Enterprise SaaS & Luxury E-commerce</p>
            <p>Client Engagements: 50+ Globally</p>
          </div>
        </div>

        <div className="lg:col-span-3 space-y-8 text-base sm:text-lg text-onyx-600 dark:text-white/75 font-light leading-relaxed">
          <p>
            {locale === "ar" ? portfolioData.personal.biography.ar : portfolioData.personal.biography.en}
          </p>
          <p>
            {locale === "ar" 
              ? "من خلال الربط الحسابي بين خوارزميات الذكاء الاصطناعي الإعلانية وتحليلات مجموعات العملاء الدقيقة، قمت بتوجيه عمليات تحسين كبرى حققت عوائد استثمارية استثنائية لشركات في دول مجلس التعاون الخليجي والشرق الأوسط وأوروبا. أتبع فلسفة واضحة: إلغاء التعاقدات الخارجية المشتتة وتجهيز فرق العميل الداخلية لتشغيل الآلة التسويقية بكفاءة وتدفق مستمر."
              : "By establishing mathematically models directly linked to business accounting platforms, Mahmoud eliminates the structural fog inherent in traditional marketing reportings. His campaigns are run like algorithmic assets, designed to buy, filter, and optimize user actions until maximum efficiency is unlocked for enterprise B2B SaaS and consumer retail networks."
            }
          </p>
        </div>
      </section>

      {/* Working Philosophy Section */}
      <section className="py-12 border-y border-onyx-200/40 dark:border-white/5">
        <div className="grid grid-cols-1 lg:grid-cols-5 gap-16 items-center">
          <div className="lg:col-span-3 space-y-6">
            <span className="font-mono text-[10px] uppercase tracking-[0.3em] text-brand-orange block font-bold">
              OPERATIONAL PHILOSOPHY
            </span>
            <h2 className="font-serif text-3xl sm:text-4xl font-light tracking-tight text-onyx-950 dark:text-white">
              {locale === "ar" ? philosophyData.title.ar : philosophyData.title.en}
            </h2>
            <blockquote className="font-serif text-lg italic text-onyx-800 dark:text-white/90 border-l-2 border-brand-orange pl-4 rtl:border-l-0 rtl:border-r-2 rtl:pl-0 rtl:pr-4">
              "{locale === "ar" ? philosophyData.quote.ar : philosophyData.quote.en}"
            </blockquote>
            <p className="text-sm sm:text-base text-onyx-500 dark:text-white/60 leading-relaxed font-light">
              {locale === "ar" ? philosophyData.p1.ar : philosophyData.p1.en}
            </p>
          </div>
          
          {/* Values Grid */}
          <div className="lg:col-span-2 space-y-6">
            {executiveValues.map((val, idx) => {
              const Icon = val.icon;
              return (
                <div key={idx} className="p-5 rounded-2xl border border-onyx-200/40 bg-white/50 dark:border-white/5 dark:bg-[#0c0c0c]/40 luxury-blur space-y-2">
                  <div className="flex items-center gap-2 text-brand-orange">
                    <Icon className="w-4 h-4" />
                    <h3 className="font-serif text-sm font-semibold text-onyx-950 dark:text-white">
                      {locale === "ar" ? val.title.ar : val.title.en}
                    </h3>
                  </div>
                  <p className="text-xs text-onyx-500 dark:text-white/50 leading-relaxed">
                    {locale === "ar" ? val.desc.ar : val.desc.en}
                  </p>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Approach Steps */}
      <section className="space-y-12">
        <div className="space-y-4">
          <span className="font-mono text-[10px] uppercase tracking-[0.3em] text-brand-orange block font-bold">
            THE METHODOLOGY
          </span>
          <h2 className="font-serif text-3xl sm:text-4xl font-light tracking-tight text-onyx-950 dark:text-white">
            {locale === "ar" ? "خطوات الأسلوب الإستراتيجي" : "The Core Tactical Approach"}
          </h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {approachPoints.map((pt, idx) => (
            <div 
              key={pt.id}
              className="p-8 rounded-2xl border border-onyx-200/40 bg-white/30 dark:border-white/5 dark:bg-white/5 relative group hover:border-brand-orange/30 transition-all duration-300"
            >
              <span className="absolute top-6 right-6 font-mono text-[10px] text-brand-orange font-bold opacity-60">
                0{idx + 1} // METHOD
              </span>
              <div className="space-y-4">
                <h3 className="font-serif text-xl font-medium text-onyx-950 dark:text-white">
                  {locale === "ar" ? pt.title.ar : pt.title.en}
                </h3>
                <p className="text-xs sm:text-sm text-onyx-500 dark:text-white/60 leading-relaxed">
                  {locale === "ar" ? pt.desc.ar : pt.desc.en}
                </p>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Languages Visualization */}
      <section className="grid grid-cols-1 lg:grid-cols-5 gap-16 items-center">
        <div className="lg:col-span-2 space-y-4">
          <span className="font-mono text-[10px] uppercase tracking-[0.3em] text-brand-orange block font-bold">
            LANGUAGES
          </span>
          <h2 className="font-serif text-3xl font-light tracking-tight text-onyx-950 dark:text-white">
            {locale === "ar" ? "ألسنة التداول والخطاب" : "Global Communication"}
          </h2>
          <p className="text-xs text-onyx-400 dark:text-onyx-500 leading-relaxed">
            {locale === "ar" 
              ? "مواءمة ممارسات التواصل وإدارة الميزانيات والتفاوض عبر الثقافات اللغوية الإقليمية والدولية بطلاقة تامة." 
              : "Managing multi-million dollar regional allocations and board relations across cultures in native languages."}
          </p>
        </div>

        <div className="lg:col-span-3 grid grid-cols-1 sm:grid-cols-2 gap-6">
          {languagesList.map((lang) => (
            <div 
              key={lang.code}
              className="p-6 rounded-2xl border border-onyx-200/40 bg-white/50 dark:border-white/5 dark:bg-[#0c0c0c]/40 luxury-blur space-y-4"
            >
              <div className="flex justify-between items-center font-mono">
                <div className="flex items-center gap-2">
                  <Globe2 className="w-4 h-4 text-brand-orange" />
                  <span className="text-xs font-semibold text-onyx-950 dark:text-white">
                    {locale === "ar" ? lang.name.ar : lang.name.en}
                  </span>
                </div>
                <span className="text-[10px] text-brand-orange font-bold uppercase">{lang.percentage}</span>
              </div>
              
              <div className="w-full h-1 bg-onyx-100 dark:bg-white/5 rounded-full overflow-hidden">
                <div 
                  className="h-full bg-brand-orange" 
                  style={{ width: lang.percentage }}
                />
              </div>

              <p className="text-xs text-onyx-400 dark:text-onyx-500 font-medium">
                {locale === "ar" ? lang.level.ar : lang.level.en}
              </p>
            </div>
          ))}
        </div>
      </section>

      {/* Timeline LEDGER */}
      <section className="space-y-12">
        <div className="space-y-4">
          <span className="font-mono text-[10px] uppercase tracking-[0.3em] text-brand-orange block font-bold">
            CHRONOLOGY
          </span>
          <h2 className="font-serif text-3xl sm:text-4xl font-light tracking-tight text-onyx-950 dark:text-white">
            {locale === "ar" ? "السجل التاريخي والمسيرة" : "The Chronological Milestone Ledger"}
          </h2>
        </div>

        <div className="relative border-l border-onyx-200 dark:border-white/10 ml-4 rtl:border-l-0 rtl:border-r rtl:ml-0 rtl:mr-4 pl-8 rtl:pl-0 rtl:pr-8 space-y-12">
          {portfolioData.experience.map((exp, idx) => (
            <div key={exp.id} className="relative space-y-4">
              {/* Timeline Bullet node */}
              <div className="absolute -left-[37px] rtl:-right-[37px] top-1.5 w-4.5 h-4.5 rounded-full border border-brand-orange bg-onyx-50 dark:bg-[#050505] flex items-center justify-center">
                <div className="w-1.5 h-1.5 bg-brand-orange rounded-full"></div>
              </div>

              <div className="space-y-1">
                <span className="font-mono text-xs text-brand-orange font-bold block">
                  {exp.period}
                </span>
                <h3 className="font-serif text-xl font-light text-onyx-950 dark:text-white">
                  {locale === "ar" ? exp.role.ar : exp.role.en}
                </h3>
                <p className="text-xs text-onyx-400 dark:text-onyx-600 font-mono">
                  {locale === "ar" ? exp.company.ar : exp.company.en}
                </p>
              </div>

              <p className="text-sm text-onyx-500 dark:text-white/60 leading-relaxed font-light max-w-4xl">
                {locale === "ar" ? exp.description.ar : exp.description.en}
              </p>

              <div className="flex flex-wrap gap-2 pt-2">
                {(locale === "ar" ? exp.highlights.ar : exp.highlights.en).map((hl, hlIdx) => (
                  <span 
                    key={hlIdx}
                    className="px-3 py-1 rounded-full border border-onyx-100 dark:border-white/5 bg-onyx-100/30 dark:bg-white/5 text-xs text-onyx-600 dark:text-white/50"
                  >
                    {hl}
                  </span>
                ))}
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Call of action bottom block */}
      <section className="pt-16 border-t border-onyx-200/40 dark:border-white/5 text-center space-y-8">
        <div className="max-w-2xl mx-auto space-y-4">
          <h2 className="font-serif text-2xl sm:text-3xl font-light text-onyx-950 dark:text-white">
            {locale === "ar" ? "هل أنت مستعد لتأسيس بنية نمو صلبة؟" : "Align Your Growth System Now"}
          </h2>
          <p className="text-xs sm:text-sm text-onyx-500 dark:text-white/50 leading-relaxed font-mono">
            {locale === "ar" 
              ? "باشر بتنسيق استعلام تنفيذي للحصول على تدقيق شامل لحساباتك الإعلانية ومحركات التحويل الحالية."
              : "Initiate an executive inquiry to thoroughly evaluate your active media performance models."}
          </p>
        </div>

        <a 
          href="#/contact"
          className="inline-flex items-center gap-2 px-6 py-3.5 rounded-full bg-onyx-950 text-white dark:bg-white dark:text-onyx-950 hover:bg-brand-orange dark:hover:bg-brand-orange hover:text-white dark:hover:text-white text-xs font-mono uppercase tracking-wider font-semibold transition-all duration-300"
        >
          <span>{locale === "ar" ? "حجز موعد استشاري" : "Initiate Corporate Advisory"}</span>
          <ArrowRight className="w-4 h-4 rtl:rotate-180 animate-pulse" />
        </a>
      </section>

    </div>
  );
}
