import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { ArrowUp } from "lucide-react";
import { useLanguage } from "./LanguageContext";

export default function BackToTop() {
  const { t } = useLanguage();
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const toggleVisibility = () => {
      if (window.scrollY > 400) {
        setIsVisible(true);
      } else {
        setIsVisible(false);
      }
    };

    window.addEventListener("scroll", toggleVisibility);
    return () => window.removeEventListener("scroll", toggleVisibility);
  }, []);

  const scrollToTop = () => {
    window.scrollTo({
      top: 0,
      behavior: "smooth",
    });
  };

  return (
    <AnimatePresence>
      {isVisible && (
        <motion.button
          id="back-to-top-button"
          onClick={scrollToTop}
          initial={{ opacity: 0, scale: 0.8, y: 10 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.8, y: 10 }}
          transition={{ duration: 0.4, ease: [0.16, 1, 0.3, 1] }}
          className="fixed bottom-6 xl:bottom-[32px] right-6 xl:right-[32px] z-45 p-3 rounded-full border border-onyx-200/60 bg-onyx-50/80 hover:bg-brand-orange hover:border-brand-orange hover:text-white dark:border-white/10 dark:bg-[#0A0A0A]/80 dark:text-white dark:hover:bg-brand-orange dark:hover:border-brand-orange transition-all duration-300 shadow-sm backdrop-blur-md group cursor-pointer"
          aria-label={t ? t("accessibility.backToTop") || "Scroll to top" : "Scroll to top"}
        >
          <ArrowUp className="w-4 h-4 text-onyx-800 dark:text-onyx-200 group-hover:text-white transition-colors duration-300 animate-pulse-subtle" />
        </motion.button>
      )}
    </AnimatePresence>
  );
}
