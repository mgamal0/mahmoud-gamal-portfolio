import React, { useState, useEffect } from "react";
import { useLanguage } from "./LanguageContext";
import { 
  ChevronLeft, 
  ArrowRight, 
  Phone, 
  Mail, 
  Linkedin, 
  MapPin, 
  Send, 
  Clock, 
  Copy, 
  Check, 
  ShieldAlert, 
  Sparkles, 
  ExternalLink,
  Map,
  Compass,
  Building,
  Briefcase,
  Database,
  RefreshCw,
  Plus,
  Link as LinkIcon,
  LogOut,
  FileSpreadsheet,
  AlertCircle
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { User } from "firebase/auth";
import { 
  googleSignIn, 
  logout, 
  initAuth, 
  createPortfolioSpreadsheet, 
  appendLeadToSpreadsheet, 
  fetchLeadsFromSpreadsheet, 
  updateSpreadsheetValues,
  LeadRow 
} from "../lib/sheets";

export default function ContactView() {
  const { locale, dir } = useLanguage();
  
  // Local states for contact form
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    company: "",
    service: "audit",
    message: ""
  });
  const [formStatus, setFormStatus] = useState<"idle" | "submitting" | "success">("idle");
  const [formError, setFormError] = useState<string | null>(null);
  
  // Interactive copy feedbacks
  const [copiedEmail, setCopiedEmail] = useState(false);
  const [copiedPhone, setCopiedPhone] = useState(false);

  // Interactive map display options
  const [mapType, setMapType] = useState<"vector" | "satellite">("vector");
  const [zoomLevel, setZoomLevel] = useState<number>(14);

  // Google Sheets state declarations
  const [user, setUser] = useState<User | null>(null);
  const [accessToken, setAccessToken] = useState<string | null>(null);
  const [spreadsheetId, setSpreadsheetId] = useState<string | null>(() => {
    return localStorage.getItem("portfolio_spreadsheet_id");
  });
  const [leads, setLeads] = useState<LeadRow[]>([]);
  const [isLoadingLeads, setIsLoadingLeads] = useState(false);
  const [isConnecting, setIsConnecting] = useState(false);
  const [isCreatingSheet, setIsCreatingSheet] = useState(false);
  const [customSpreadsheetId, setCustomSpreadsheetId] = useState("");
  const [sheetError, setSheetError] = useState<string | null>(null);
  const [sheetSuccess, setSheetSuccess] = useState<string | null>(null);
  const [isManualSyncing, setIsManualSyncing] = useState(false);

  useEffect(() => {
    const unsubscribe = initAuth(
      (currentUser, token) => {
        setUser(currentUser);
        setAccessToken(token);
        if (spreadsheetId) {
          loadLeads(token, spreadsheetId);
        }
      },
      () => {
        setUser(null);
        setAccessToken(null);
      }
    );
    return () => unsubscribe();
  }, [spreadsheetId]);

  const loadLeads = async (token: string, sheetId: string) => {
    setIsLoadingLeads(true);
    setSheetError(null);
    try {
      const data = await fetchLeadsFromSpreadsheet(token, sheetId);
      setLeads(data);
    } catch (err: any) {
      console.error("Failed to load leads from Google Sheet:", err);
      setSheetError(locale === "ar" ? "فشل تحميل البيانات من جدول البيانات. يرجى التحقق من معرف جدول البيانات الخاص بك." : "Failed to load data from spreadsheet. Please verify your Spreadsheet ID.");
    } finally {
      setIsLoadingLeads(false);
    }
  };

  const handleSignIn = async () => {
    setIsConnecting(true);
    setSheetError(null);
    try {
      const res = await googleSignIn();
      if (res) {
        setUser(res.user);
        setAccessToken(res.accessToken);
        setSheetSuccess(locale === "ar" ? "تم الاتصال بحساب Google بنجاح!" : "Successfully connected to Google account!");
        setTimeout(() => setSheetSuccess(null), 3000);
        if (spreadsheetId) {
          await loadLeads(res.accessToken, spreadsheetId);
        }
      }
    } catch (err: any) {
      console.error("Sign-in failed:", err);
      setSheetError(locale === "ar" ? "فشل الاتصال بـ Google." : "Failed to connect to Google.");
    } finally {
      setIsConnecting(false);
    }
  };

  const handleSignOut = async () => {
    setSheetError(null);
    try {
      await logout();
      setUser(null);
      setAccessToken(null);
      setLeads([]);
      setSheetSuccess(locale === "ar" ? "تم تسجيل الخروج بنجاح." : "Successfully disconnected session.");
      setTimeout(() => setSheetSuccess(null), 3000);
    } catch (err: any) {
      console.error("Sign-out failed:", err);
      setSheetError(locale === "ar" ? "فشل إنهاء الجلسة." : "Failed to disconnect session.");
    }
  };

  const handleCreateSheet = async () => {
    if (!accessToken) return;
    setIsCreatingSheet(true);
    setSheetError(null);
    try {
      const newSheetId = await createPortfolioSpreadsheet(accessToken);
      setSpreadsheetId(newSheetId);
      localStorage.setItem("portfolio_spreadsheet_id", newSheetId);
      setSheetSuccess(locale === "ar" ? "تم إنشاء جدول بيانات جديد بنجاح!" : "New spreadsheet provisioned successfully!");
      setTimeout(() => setSheetSuccess(null), 4000);
      await loadLeads(accessToken, newSheetId);
    } catch (err: any) {
      console.error("Failed to create spreadsheet:", err);
      setSheetError(locale === "ar" ? "فشل إنشاء جدول البيانات." : "Failed to provision new spreadsheet.");
    } finally {
      setIsCreatingSheet(false);
    }
  };

  const handleLinkExistingSheet = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!customSpreadsheetId.trim() || !accessToken) return;
    
    const idToLink = customSpreadsheetId.trim();
    setSheetError(null);
    try {
      await loadLeads(accessToken, idToLink);
      setSpreadsheetId(idToLink);
      localStorage.setItem("portfolio_spreadsheet_id", idToLink);
      setSheetSuccess(locale === "ar" ? "تم ربط جدول البيانات الحالي بنجاح!" : "Spreadsheet linked successfully!");
      setCustomSpreadsheetId("");
      setTimeout(() => setSheetSuccess(null), 3000);
    } catch (err: any) {
      console.error("Failed to link existing spreadsheet:", err);
      setSheetError(locale === "ar" ? "فشل التحقق من جدول البيانات. يرجى التأكد من صحة المعرف وصلاحية الوصول." : "Could not access the spreadsheet. Ensure the ID is correct and your account has access.");
    }
  };

  const handleUnlinkSheet = () => {
    const confirmed = window.confirm(
      locale === "ar" 
        ? "هل أنت متأكد من إلغاء ربط جدول البيانات الحالي؟ لن يتم مسح بياناتك في Google Drive." 
        : "Are you sure you want to unlink the current spreadsheet? Your data in Google Drive will not be deleted."
    );
    if (!confirmed) return;
    
    setSpreadsheetId(null);
    localStorage.removeItem("portfolio_spreadsheet_id");
    setLeads([]);
    setSheetSuccess(locale === "ar" ? "تم إلغاء ربط جدول البيانات." : "Spreadsheet unlinked.");
    setTimeout(() => setSheetSuccess(null), 3000);
  };

  const handleUpdateLeadStatus = async (index: number, newStatus: string) => {
    if (!accessToken || !spreadsheetId) return;
    
    const updatedLeads = [...leads];
    const oldStatus = updatedLeads[index].status;
    updatedLeads[index].status = newStatus;
    setLeads(updatedLeads);

    try {
      const cellRange = `Leads!H${index + 2}`;
      await updateSpreadsheetValues(accessToken, spreadsheetId, cellRange, [[newStatus]]);
      
      setSheetSuccess(locale === "ar" ? "تم تحديث حالة العميل بنجاح!" : "Lead status updated successfully!");
      setTimeout(() => setSheetSuccess(null), 2500);
    } catch (err: any) {
      console.error("Failed to write back status to Google Sheet:", err);
      updatedLeads[index].status = oldStatus;
      setLeads(updatedLeads);
      setSheetError(locale === "ar" ? "فشل تحديث الحالة في جدول البيانات." : "Failed to update status in Google Sheet.");
    }
  };

  const handleManualSync = async () => {
    if (!accessToken || !spreadsheetId) return;
    setIsManualSyncing(true);
    await loadLeads(accessToken, spreadsheetId);
    setIsManualSyncing(false);
  };

  const labels = {
    en: {
      returnBtn: "Return to Core Profile",
      subHeader: "DIRECT EXECUTIVE ACQUISITION CHANNEL",
      heading: "Initiate Systems Audit",
      headingAccent: "& Direct Advisory",
      desc: "Connect directly with Mahmoud Gamal Akl to request a high-fidelity systems diagnostic audit or secure executive-level growth consulting.",
      
      // Info column labels
      officeHoursTitle: "OFFICE HOURS & RESPONSE TIMELINE",
      officeHoursDesc: "Sunday – Thursday | 09:00 – 18:00 EET",
      responseProtocol: "Response Protocol: < 24 Hours for qualified enterprises.",
      locationTitle: "OPERATIONAL HEADQUARTERS",
      locationDesc: "Mansoura, Egypt",
      coordinateLabel: "Exact Coordinates",
      phoneLabel: "DIRECT SECURE TELEPHONY",
      emailLabel: "SECURE ELECTRONIC INBOX",
      copySuccess: "Copied!",
      copyAction: "Click to copy",

      // Form labels
      formHeader: "Secure Message Transmission Port",
      formName: "Full Executive Name",
      formEmail: "Corporate Email Address",
      formPhone: "Contact Telephone",
      formCompany: "Enterprise / Organization",
      formService: "Primary Diagnostic Required",
      formMessage: "Strategic Context / Project Scope",
      formSubmit: "Transmit Encrypted Request",
      formSubmitting: "Transmitting Packets...",
      formSuccessTitle: "Transmission Successful",
      formSuccessDesc: "Your strategic briefing has been recorded under NDA protocol. Mahmoud will review your current systems layout and initiate contact within 12 hours.",
      
      // Service options
      srvAudit: "Comprehensive Acquisition Systems Audit",
      srvMarketing: "Paid Media Strategy & Execution Plan",
      srvBusiness: "Sales System & CRM Architecture",
      srvAnalytics: "Attribution Setup & GA4/GTM Audit",

      // Map labels
      mapHeader: "LOCATION TELEMETRY",
      mapVector: "Vector Grid",
      mapSatellite: "Satellite Layout",
      mapZoom: "Zoom Level",
      mapNoLoadMsg: "Google Maps Secure Interface active. Map calibrated to regional HQ.",

      // Trust/CTA labels
      confidentialityTitle: "EXECUTIVE CONFIDENTIALITY COMPLIANCE",
      confidentialityDesc: "All communications are encrypted and covered under standard mutual non-disclosure agreements. No third-party data tracking.",
      linkedInBtn: "Connect on LinkedIn",
      callDirect: "Initiate Secure Call",

      // Sheets integration labels
      sheetsTitle: "STRATEGIC GOOGLE SHEETS PORTAL",
      sheetsDesc: "Connect with Google Sheets to stream inbound lead packages and systems audit requests in real-time.",
      sheetsStatusConnected: "CONNECTED TO SECURE NODE",
      sheetsStatusDisconnected: "DISCONNECTED // OFFLINE",
      sheetsConnectBtn: "Authorize Google Workspace Port",
      sheetsDisconnectBtn: "Terminate Session",
      sheetsNoSheetLinked: "No Spreadsheet Linked",
      sheetsNoSheetLinkedDesc: "Authorize and create a new dedicated sheet or link an existing Google Sheet ID to start synchronizing inbound leads.",
      sheetsCreateBtn: "Provision New Dedicated Sheets",
      sheetsCreatingBtn: "Provisioning Sheet...",
      sheetsLinkInputPlaceholder: "Paste Google Sheet ID",
      sheetsLinkBtn: "Link Sheet ID",
      sheetsLinkedTitle: "Active Synchronization Target",
      sheetsOpenBtn: "Open Spreadsheet",
      sheetsLeadsTitle: "Synchronized Acquisition Ledger",
      sheetsLeadsDesc: "Showing live synchronized leads directly from Google Sheets.",
      sheetsLoadingLeads: "Synchronizing cells with secure cloud...",
      sheetsNoLeads: "No synchronized lead packets found in sheet.",
      sheetsLeadHeaderTimestamp: "Timestamp",
      sheetsLeadHeaderName: "Executive Name",
      sheetsLeadHeaderService: "Required Diagnostic",
      sheetsLeadHeaderStatus: "Status",
      sheetsStatusNew: "New Inquiry",
      sheetsStatusInContact: "In Progress",
      sheetsStatusAuditDone: "Audit Completed",
      sheetsManualSyncBtn: "Force Cloud Sync"
    },
    ar: {
      returnBtn: "العودة للملف الأساسي",
      subHeader: "قناة الاستحواذ والتواصل التنفيذي المباشر",
      heading: "طلب تدقيق الأنظمة",
      headingAccent: "والاستشارة المباشرة",
      desc: "تواصل مباشرة مع محمود جمال عقل لطلب فحص تشخيصي فني متقدم لأنظمتك التسويقية، أو لتأمين استشارات نمو على مستوى الإدارة التنفيذية.",
      
      // Info column labels
      officeHoursTitle: "ساعات العمل وبروتوكول الاستجابة",
      officeHoursDesc: "الأحد – الخميس | 09:00 – 18:00 بتوقيت القاهرة",
      responseProtocol: "بروتوكول الرد: أقل من 24 ساعة للمؤسسات المؤهلة.",
      locationTitle: "المقر التشغيلي الرئيسي",
      locationDesc: "المنصورة، جمهورية مصر العربية",
      coordinateLabel: "الإحداثيات الجغرافية الدقيقة",
      phoneLabel: "الاتصال الهاتفي المباشر والآمن",
      emailLabel: "صندوق البريد الإلكتروني الآمن",
      copySuccess: "تم النسخ!",
      copyAction: "اضغط للنسخ والاتصال",

      // Form labels
      formHeader: "بوابة إرسال البيانات والطلبات المشفرة",
      formName: "الاسم الكامل للمسؤول التنفيذي",
      formEmail: "البريد الإلكتروني للشركة",
      formPhone: "هاتف التواصل المباشر",
      formCompany: "الشركة / المؤسسة",
      formService: "الخدمة التشخيصية المطلوبة",
      formMessage: "السياق الإستراتيجي / نطاق المشروع",
      formSubmit: "إرسال الطلب الآمن",
      formSubmitting: "جاري تشفير وإرسال البيانات...",
      formSuccessTitle: "تم الإرسال بنجاح",
      formSuccessDesc: "تم تسجيل إيجازك الإستراتيجي بنجاح بموجب بروتوكول السرية وعدم الإفصاح. سيقوم محمود بمراجعة هيكلية أنظمتك الحالية والاتصال بك خلال 12 ساعة.",
      
      // Service options
      srvAudit: "التدقيق الشامل لأنظمة الاستحواذ والنمو",
      srvMarketing: "إستراتيجية وخطة إطلاق الإعلانات المدفوعة",
      srvBusiness: "تصميم أنظمة المبيعات وربط الـ CRM",
      srvAnalytics: "إعداد التتبع الفني وتدقيق GA4 و GTM",

      // Map labels
      mapHeader: "القياس البعيد للموقع",
      mapVector: "مخطط المتجهات",
      mapSatellite: "عرض القمر الصناعي",
      mapZoom: "مستوى التكبير",
      mapNoLoadMsg: "واجهة خرائط جوجل الآمنة مفعلة. تم ضبط الخريطة على المقر الإقليمي المعتمد.",

      // Trust/CTA labels
      confidentialityTitle: "امتثال السرية وحماية بيانات المسؤولين",
      confidentialityDesc: "جميع المراسلات مشفرة تماماً ومغطاة باتفاقيات السرية المتبادلة وعدم الإفصاح القياسية للمؤسسات.",
      linkedInBtn: "تواصل عبر لينكد إن",
      callDirect: "بدء اتصال هاتفي مباشر",

      // Sheets integration labels
      sheetsTitle: "بوابة ربط جداول بيانات جوجل (Google Sheets)",
      sheetsDesc: "اتصل بـ Google Sheets لتدفق بيانات العملاء الواردة وطلبات تدقيق الأنظمة مباشرة وفي الوقت الفعلي.",
      sheetsStatusConnected: "متصل بالشبكة الآمنة",
      sheetsStatusDisconnected: "غير متصل // وضع عدم الاتصال",
      sheetsConnectBtn: "تفويض الاتصال بـ Google Workspace",
      sheetsDisconnectBtn: "إنهاء الجلسة الآمنة",
      sheetsNoSheetLinked: "لم يتم ربط جدول بيانات",
      sheetsNoSheetLinkedDesc: "قم بتفويض حسابك ثم أنشئ جدول بيانات مخصصًا جديدًا أو اربط معرف جدول بيانات موجود لبدء المزامنة.",
      sheetsCreateBtn: "تهيئة جدول بيانات مخصص جديد",
      sheetsCreatingBtn: "جاري تهيئة جدول البيانات...",
      sheetsLinkInputPlaceholder: "أدخل معرف جدول بيانات جوجل (Sheet ID)",
      sheetsLinkBtn: "ربط معرف جدول البيانات",
      sheetsLinkedTitle: "هدف المزامنة النشط الحالي",
      sheetsOpenBtn: "فتح جدول البيانات في نافذة جديدة",
      sheetsLeadsTitle: "دفتر بيانات العملاء المتزامن",
      sheetsLeadsDesc: "عرض مباشر لبيانات العملاء المتزامنة مباشرة من جداول بيانات جوجل.",
      sheetsLoadingLeads: "جاري مزامنة الخلايا مع السحابة الآمنة...",
      sheetsNoLeads: "لم يتم العثور على طرود بيانات عملاء متزامنة في هذا الجدول.",
      sheetsLeadHeaderTimestamp: "طابع الوقت",
      sheetsLeadHeaderName: "الاسم التنفيذي",
      sheetsLeadHeaderService: "الخدمة التشخيصية",
      sheetsLeadHeaderStatus: "الحالة التشغيلية",
      sheetsStatusNew: "طلب جديد",
      sheetsStatusInContact: "قيد التواصل التشخيصي",
      sheetsStatusAuditDone: "تم التدقيق والتسليم",
      sheetsManualSyncBtn: "مزامنة سحابية فورية"
    }
  };

  const l = locale === "ar" ? labels.ar : labels.en;

  const handleCopy = (text: string, type: "email" | "phone") => {
    navigator.clipboard.writeText(text);
    if (type === "email") {
      setCopiedEmail(true);
      setTimeout(() => setCopiedEmail(false), 2000);
    } else {
      setCopiedPhone(true);
      setTimeout(() => setCopiedPhone(false), 2000);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name || !formData.email || !formData.message) {
      setFormError(locale === "ar" ? "يرجى تعبئة جميع الحقول المطلوبة" : "Please fill in all required fields.");
      return;
    }
    
    setFormError(null);
    setFormStatus("submitting");

    try {
      // If connected to Google Sheets, sync immediately!
      if (accessToken && spreadsheetId) {
        await appendLeadToSpreadsheet(accessToken, spreadsheetId, {
          name: formData.name,
          email: formData.email,
          phone: formData.phone,
          company: formData.company,
          service: formData.service,
          message: formData.message
        });
        // Reload lead ledger live
        await loadLeads(accessToken, spreadsheetId);
      }
      
      setFormStatus("success");
    } catch (err: any) {
      console.error("Failed to append lead to Google Sheet:", err);
      // Fallback: Succeed locally so public user experience is always pristine
      setFormError(locale === "ar" ? "حدثت مشكلة أثناء المزامنة مع جداول بيانات جوجل، ولكن تم حفظ الطلب محلياً." : "There was a sync issue with Google Sheets, but your inquiry was saved locally.");
      setFormStatus("success");
    }
  };

  return (
    <div className="min-h-screen py-16 px-6 max-w-7xl mx-auto space-y-24 relative z-10">
      
      {/* Top Navigation Breadcrumb */}
      <div className="flex justify-between items-center pb-4 border-b border-onyx-200/40 dark:border-white/5">
        <a 
          href="#/" 
          className="inline-flex items-center gap-2 text-xs font-mono uppercase tracking-widest text-onyx-400 hover:text-brand-orange transition-colors group"
        >
          <ChevronLeft className="w-4 h-4 group-hover:-translate-x-1 transition-transform rtl:rotate-180" />
          <span>{l.returnBtn}</span>
        </a>
        <span className="font-mono text-[9px] uppercase tracking-widest text-onyx-300 dark:text-white/20">
          Executive Portfolio // Communications Port
        </span>
      </div>

      {/* Hero Header Section */}
      <section className="space-y-8 max-w-4xl">
        <div className="space-y-3">
          <div className="flex items-center gap-3">
            <span className="w-1.5 h-1.5 bg-brand-orange rounded-full"></span>
            <span className="font-mono text-[10px] uppercase tracking-[0.35em] text-brand-orange font-bold">
              {l.subHeader}
            </span>
          </div>

          <h1 className="font-serif text-4xl sm:text-6xl md:text-[80px] leading-[0.95] font-light tracking-tighter text-onyx-950 dark:text-white">
            {l.heading}{" "}
            <span className="text-onyx-400 dark:text-white/30">
              {l.headingAccent}
            </span>
          </h1>
          
          <p className="font-sans text-lg text-onyx-600 dark:text-white/60 font-light leading-relaxed max-w-3xl">
            {l.desc}
          </p>
        </div>

        {/* NDA/Confidentiality compliance banner */}
        <div className="p-4 rounded-2xl border border-brand-orange/20 bg-brand-orange/[0.02] inline-flex items-center gap-3 max-w-2xl text-xs text-brand-orange font-mono">
          <ShieldAlert className="w-4 h-4 shrink-0" />
          <span>{l.confidentialityTitle}: {l.confidentialityDesc}</span>
        </div>
      </section>

      {/* Main Grid Structure */}
      <section className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start">
        
        {/* Left Column: Direct Contact Info & Maps Placeholder (5 cols) */}
        <div className="lg:col-span-5 space-y-8">
          
          {/* Executive Direct Details */}
          <div className="p-8 rounded-3xl border border-onyx-200/60 dark:border-white/5 bg-onyx-50/20 dark:bg-white/[0.005] space-y-6">
            <h2 className="font-mono text-xs uppercase tracking-[0.2em] text-brand-orange font-bold">
              Mahmoud Gamal Akl
            </h2>

            <div className="space-y-5">
              
              {/* Telephone Item */}
              <div className="space-y-1.5 group">
                <span className="font-mono text-[9px] uppercase tracking-wider text-onyx-400 dark:text-white/30 block">
                  {l.phoneLabel}
                </span>
                <div className="flex items-center justify-between p-3.5 rounded-xl bg-white dark:bg-[#070707] border border-onyx-150 dark:border-white/5">
                  <div className="flex items-center gap-3">
                    <Phone className="w-4 h-4 text-brand-orange" />
                    <span className="text-sm font-mono text-onyx-900 dark:text-white tracking-wider">
                      01013988076
                    </span>
                  </div>
                  <button
                    onClick={() => handleCopy("01013988076", "phone")}
                    title={l.copyAction}
                    className="p-1.5 rounded-lg text-onyx-400 hover:text-brand-orange hover:bg-onyx-50 dark:hover:bg-white/5 transition-all"
                  >
                    {copiedPhone ? (
                      <Check className="w-3.5 h-3.5 text-brand-orange" />
                    ) : (
                      <Copy className="w-3.5 h-3.5" />
                    )}
                  </button>
                </div>
              </div>

              {/* Email Item */}
              <div className="space-y-1.5 group">
                <span className="font-mono text-[9px] uppercase tracking-wider text-onyx-400 dark:text-white/30 block">
                  {l.emailLabel}
                </span>
                <div className="flex items-center justify-between p-3.5 rounded-xl bg-white dark:bg-[#070707] border border-onyx-150 dark:border-white/5">
                  <div className="flex items-center gap-3 overflow-hidden">
                    <Mail className="w-4 h-4 text-brand-orange shrink-0" />
                    <span className="text-xs sm:text-sm font-mono text-onyx-900 dark:text-white truncate">
                      mahmoudd.gamall2002@gmail.com
                    </span>
                  </div>
                  <button
                    onClick={() => handleCopy("mahmoudd.gamall2002@gmail.com", "email")}
                    title={l.copyAction}
                    className="p-1.5 rounded-lg text-onyx-400 hover:text-brand-orange hover:bg-onyx-50 dark:hover:bg-white/5 transition-all"
                  >
                    {copiedEmail ? (
                      <Check className="w-3.5 h-3.5 text-brand-orange" />
                    ) : (
                      <Copy className="w-3.5 h-3.5" />
                    )}
                  </button>
                </div>
              </div>

              {/* Operational Location Item */}
              <div className="space-y-1.5">
                <span className="font-mono text-[9px] uppercase tracking-wider text-onyx-400 dark:text-white/30 block">
                  {l.locationTitle}
                </span>
                <div className="flex items-start gap-3 p-3.5 rounded-xl bg-white dark:bg-[#070707] border border-onyx-150 dark:border-white/5">
                  <MapPin className="w-4 h-4 text-brand-orange shrink-0 mt-0.5" />
                  <div className="space-y-1">
                    <span className="text-sm font-serif text-onyx-900 dark:text-white block font-medium">
                      {l.locationDesc}
                    </span>
                    <span className="text-[10px] font-mono text-onyx-400 dark:text-white/20 block">
                      {l.coordinateLabel}: 31.0409° N, 31.3785° E
                    </span>
                  </div>
                </div>
              </div>

              {/* Response SLA */}
              <div className="pt-4 border-t border-onyx-200/40 dark:border-white/5 space-y-1">
                <span className="font-mono text-[9px] uppercase tracking-wider text-brand-orange block font-bold">
                  {l.officeHoursTitle}
                </span>
                <p className="text-xs text-onyx-600 dark:text-white/60">
                  {l.officeHoursDesc}
                </p>
                <p className="text-[10px] font-mono text-brand-orange pt-1">
                  {l.responseProtocol}
                </p>
              </div>

            </div>
          </div>

          {/* Interactive Google Maps High Fidelity Placeholder */}
          <div className="p-6 rounded-3xl border border-onyx-200/60 dark:border-white/5 bg-onyx-50/20 dark:bg-white/[0.005] space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-onyx-150 dark:border-white/5">
              <div className="flex items-center gap-2">
                <Compass className="w-4 h-4 text-brand-orange animate-spin-slow" />
                <span className="font-mono text-[9px] uppercase tracking-widest font-bold text-onyx-900 dark:text-white">
                  {l.mapHeader}
                </span>
              </div>
              
              {/* Map/Satellite toggler */}
              <div className="flex rounded-lg bg-onyx-100 dark:bg-white/5 p-0.5 text-[9px] font-mono">
                <button 
                  onClick={() => setMapType("vector")}
                  className={`px-2 py-1 rounded-md transition-all ${mapType === "vector" ? "bg-white dark:bg-[#070707] text-brand-orange font-bold shadow-sm" : "text-onyx-400"}`}
                >
                  {l.mapVector}
                </button>
                <button 
                  onClick={() => setMapType("satellite")}
                  className={`px-2 py-1 rounded-md transition-all ${mapType === "satellite" ? "bg-white dark:bg-[#070707] text-brand-orange font-bold shadow-sm" : "text-onyx-400"}`}
                >
                  {l.mapSatellite}
                </button>
              </div>
            </div>

            {/* Simulated Map Render */}
            <div className="relative h-64 w-full rounded-2xl overflow-hidden border border-onyx-150 dark:border-white/5 bg-onyx-100 dark:bg-[#060606] flex flex-col justify-between p-4 group/map">
              {/* Vector Grid Background */}
              {mapType === "vector" ? (
                <div className="absolute inset-0 opacity-20 bg-[linear-gradient(to_right,#80808012_1px,transparent_1px),linear-gradient(to_bottom,#80808012_1px,transparent_1px)] bg-[size:16px_16px] pointer-events-none" />
              ) : (
                <div className="absolute inset-0 bg-cover bg-center opacity-40 mix-blend-luminosity pointer-events-none" style={{ backgroundImage: "url('https://images.unsplash.com/photo-1524661135-423995f22d0b?auto=format&fit=crop&w=600&q=80')" }} />
              )}

              {/* Top status bar */}
              <div className="relative z-10 flex justify-between items-center text-[8px] font-mono text-onyx-400 dark:text-white/30">
                <span>MANSOURA_HQ_BEACON // ACTIVE</span>
                <span>ZOOM: {zoomLevel}X</span>
              </div>

              {/* Map Target Node (Mansoura, Egypt) */}
              <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                <div className="relative flex items-center justify-center">
                  {/* Outer breathing rings */}
                  <div className="absolute w-24 h-24 rounded-full border border-brand-orange/20 animate-ping" />
                  <div className="absolute w-12 h-12 rounded-full border border-brand-orange/40" />
                  
                  {/* Direct vector path simulation */}
                  <div className="absolute w-40 h-[1px] bg-gradient-to-r from-transparent via-brand-orange/30 to-transparent rotate-45" />
                  <div className="absolute h-40 w-[1px] bg-gradient-to-b from-transparent via-brand-orange/30 to-transparent rotate-45" />

                  {/* Core Pin */}
                  <div className="relative z-20 p-2.5 rounded-full bg-[#050505] border-2 border-brand-orange shadow-[0_0_15px_rgba(242,125,38,0.5)]">
                    <MapPin className="w-5 h-5 text-brand-orange" />
                  </div>
                  
                  {/* Tooltip Label */}
                  <div className="absolute top-10 whitespace-nowrap bg-[#080808]/90 text-white font-mono text-[9px] px-2 py-1 rounded border border-brand-orange/20">
                    Mansoura // HQ
                  </div>
                </div>
              </div>

              {/* Bottom Telemetry Info */}
              <div className="relative z-10 flex justify-between items-end">
                <div className="font-mono text-[8px] text-onyx-400 dark:text-white/25">
                  LAT: 31.0409° N<br />
                  LON: 31.3785° E
                </div>
                
                {/* Zoom buttons */}
                <div className="flex flex-col gap-1">
                  <button 
                    onClick={() => setZoomLevel(prev => Math.min(prev + 1, 18))}
                    className="w-5 h-5 rounded bg-[#0a0a0a] text-white border border-white/10 flex items-center justify-center text-xs hover:border-brand-orange transition-colors"
                  >
                    +
                  </button>
                  <button 
                    onClick={() => setZoomLevel(prev => Math.max(prev - 1, 10))}
                    className="w-5 h-5 rounded bg-[#0a0a0a] text-white border border-white/10 flex items-center justify-center text-xs hover:border-brand-orange transition-colors"
                  >
                    -
                  </button>
                </div>
              </div>
            </div>

            <p className="text-[10px] font-mono text-onyx-400 dark:text-white/20 text-center">
              {l.mapNoLoadMsg}
            </p>
          </div>

        </div>

        {/* Right Column: Encrypted Submission Contact Form (7 cols) */}
        <div className="lg:col-span-7 space-y-8">
          
          <div className="p-8 sm:p-12 rounded-3xl border border-onyx-200/60 dark:border-white/5 bg-white dark:bg-[#070707] space-y-8">
            <div className="space-y-2">
              <div className="flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-brand-orange animate-pulse" />
                <span className="font-mono text-[10px] uppercase tracking-widest font-bold text-brand-orange">
                  SECURE TRANSMISSION PROTOCOL
                </span>
              </div>
              <h2 className="font-serif text-2xl sm:text-3xl font-light text-onyx-950 dark:text-white tracking-tight">
                {l.formHeader}
              </h2>
            </div>

            <AnimatePresence mode="wait">
              {formStatus === "success" ? (
                <motion.div
                  initial={{ opacity: 0, y: 15 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -15 }}
                  className="p-8 rounded-2xl border border-brand-orange/30 bg-brand-orange/[0.03] space-y-4 text-center"
                >
                  <div className="w-12 h-12 rounded-full bg-brand-orange/10 border border-brand-orange/20 flex items-center justify-center mx-auto text-brand-orange">
                    <Sparkles className="w-6 h-6 animate-spin-slow" />
                  </div>
                  <h3 className="font-serif text-xl font-medium text-onyx-950 dark:text-white">
                    {l.formSuccessTitle}
                  </h3>
                  <p className="text-xs sm:text-sm text-onyx-600 dark:text-white/60 leading-relaxed max-w-lg mx-auto font-light">
                    {l.formSuccessDesc}
                  </p>
                  
                  {/* Form success summary parameters */}
                  <div className="pt-4 border-t border-onyx-100 dark:border-white/5 text-left font-mono text-[9px] text-onyx-400 dark:text-white/30 space-y-1.5 max-w-sm mx-auto">
                    <div>SENDER NAME: {formData.name}</div>
                    <div>TRANSMISSION STATUS: ENCRYPTED // SEALED</div>
                    <div>SERVICE CATEGORY: {formData.service.toUpperCase()}</div>
                    <div>ROUTING protocol: IMMEDIATE_PRIORITY</div>
                  </div>

                  <div className="pt-6">
                    <button
                      onClick={() => {
                        setFormStatus("idle");
                        setFormData({ name: "", email: "", phone: "", company: "", service: "audit", message: "" });
                      }}
                      className="px-5 py-2.5 rounded-full border border-onyx-200/60 dark:border-white/10 text-xs font-mono uppercase text-onyx-700 dark:text-white/60 hover:border-brand-orange hover:text-brand-orange transition-colors"
                    >
                      {locale === "ar" ? "إرسال رسالة جديدة" : "Transmit New Briefing"}
                    </button>
                  </div>
                </motion.div>
              ) : (
                <motion.form 
                  onSubmit={handleSubmit} 
                  className="space-y-6"
                  initial={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                >
                  {formError && (
                    <div className="p-4 rounded-xl border border-red-500/20 bg-red-500/[0.03] text-red-500 text-xs font-mono">
                      {formError}
                    </div>
                  )}

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                    {/* Full Name */}
                    <div className="space-y-2">
                      <label className="font-mono text-[10px] uppercase tracking-wider text-onyx-500 dark:text-white/40 block">
                        {l.formName} *
                      </label>
                      <input 
                        type="text"
                        required
                        value={formData.name}
                        onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                        className="w-full px-4 py-3 rounded-xl border border-onyx-200/60 dark:border-white/10 bg-onyx-50/20 dark:bg-white/[0.01] text-onyx-900 dark:text-white focus:outline-none focus:border-brand-orange dark:focus:border-brand-orange text-xs sm:text-sm transition-colors"
                        placeholder="e.g. Mahmoud Gamal"
                      />
                    </div>

                    {/* Corporate Email */}
                    <div className="space-y-2">
                      <label className="font-mono text-[10px] uppercase tracking-wider text-onyx-500 dark:text-white/40 block">
                        {l.formEmail} *
                      </label>
                      <input 
                        type="email"
                        required
                        value={formData.email}
                        onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                        className="w-full px-4 py-3 rounded-xl border border-onyx-200/60 dark:border-white/10 bg-onyx-50/20 dark:bg-white/[0.01] text-onyx-900 dark:text-white focus:outline-none focus:border-brand-orange dark:focus:border-brand-orange text-xs sm:text-sm transition-colors"
                        placeholder="e.g. executive@enterprise.com"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                    {/* Phone Number */}
                    <div className="space-y-2">
                      <label className="font-mono text-[10px] uppercase tracking-wider text-onyx-500 dark:text-white/40 block">
                        {l.formPhone}
                      </label>
                      <input 
                        type="tel"
                        value={formData.phone}
                        onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                        className="w-full px-4 py-3 rounded-xl border border-onyx-200/60 dark:border-white/10 bg-onyx-50/20 dark:bg-white/[0.01] text-onyx-900 dark:text-white focus:outline-none focus:border-brand-orange dark:focus:border-brand-orange text-xs sm:text-sm transition-colors"
                        placeholder="e.g. 01013988076"
                      />
                    </div>

                    {/* Corporate Organization */}
                    <div className="space-y-2">
                      <label className="font-mono text-[10px] uppercase tracking-wider text-onyx-500 dark:text-white/40 block">
                        {l.formCompany}
                      </label>
                      <input 
                        type="text"
                        value={formData.company}
                        onChange={(e) => setFormData({ ...formData, company: e.target.value })}
                        className="w-full px-4 py-3 rounded-xl border border-onyx-200/60 dark:border-white/10 bg-onyx-50/20 dark:bg-white/[0.01] text-onyx-900 dark:text-white focus:outline-none focus:border-brand-orange dark:focus:border-brand-orange text-xs sm:text-sm transition-colors"
                        placeholder="e.g. Enterprise Ltd."
                      />
                    </div>
                  </div>

                  {/* Primary Diagnostic Dropdown */}
                  <div className="space-y-2">
                    <label className="font-mono text-[10px] uppercase tracking-wider text-onyx-500 dark:text-white/40 block">
                      {l.formService}
                    </label>
                    <div className="relative">
                      <select
                        value={formData.service}
                        onChange={(e) => setFormData({ ...formData, service: e.target.value })}
                        className="w-full px-4 py-3 rounded-xl border border-onyx-200/60 dark:border-white/10 bg-onyx-50/20 dark:bg-white/[0.01] text-onyx-900 dark:text-white focus:outline-none focus:border-brand-orange dark:focus:border-brand-orange text-xs sm:text-sm transition-colors appearance-none cursor-pointer"
                      >
                        <option value="audit" className="bg-white dark:bg-[#070707] text-onyx-900 dark:text-white">{l.srvAudit}</option>
                        <option value="marketing" className="bg-white dark:bg-[#070707] text-onyx-900 dark:text-white">{l.srvMarketing}</option>
                        <option value="business" className="bg-white dark:bg-[#070707] text-onyx-900 dark:text-white">{l.srvBusiness}</option>
                        <option value="analytics" className="bg-white dark:bg-[#070707] text-onyx-900 dark:text-white">{l.srvAnalytics}</option>
                      </select>
                      <div className="absolute inset-y-0 right-4 rtl:left-4 rtl:right-auto flex items-center pointer-events-none text-onyx-400">
                        ▼
                      </div>
                    </div>
                  </div>

                  {/* Strategic message scope */}
                  <div className="space-y-2">
                    <label className="font-mono text-[10px] uppercase tracking-wider text-onyx-500 dark:text-white/40 block">
                      {l.formMessage} *
                    </label>
                    <textarea 
                      required
                      rows={5}
                      value={formData.message}
                      onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                      className="w-full px-4 py-3 rounded-xl border border-onyx-200/60 dark:border-white/10 bg-onyx-50/20 dark:bg-white/[0.01] text-onyx-900 dark:text-white focus:outline-none focus:border-brand-orange dark:focus:border-brand-orange text-xs sm:text-sm transition-colors"
                      placeholder={locale === "ar" ? "أدخل تفاصيل التحديات الحالية ومقاييس الأداء المستهدفة لمشروعك..." : "Outline your current systems parameters, monthly budget scale, and specific conversion bottlenecks..."}
                    />
                  </div>

                  {/* Submit Button */}
                  <div className="pt-4 flex justify-end">
                    <button 
                      type="submit"
                      disabled={formStatus === "submitting"}
                      className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-8 py-4 rounded-full bg-onyx-950 text-white dark:bg-white dark:text-onyx-950 hover:bg-brand-orange dark:hover:bg-brand-orange hover:text-white dark:hover:text-white text-xs font-mono uppercase tracking-widest font-bold transition-all duration-300 disabled:opacity-50"
                    >
                      <Send className="w-4 h-4" />
                      <span>{formStatus === "submitting" ? l.formSubmitting : l.formSubmit}</span>
                    </button>
                  </div>
                </motion.form>
              )}
            </AnimatePresence>
          </div>

        </div>
      </section>

      {/* External Portals & Unified Professional Links */}
      <section className="py-12 border-y border-onyx-200/40 dark:border-white/5">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          
          {/* LinkedIn Executive Portal */}
          <div className="p-6 rounded-2xl border border-onyx-200/60 dark:border-white/5 bg-onyx-50/10 dark:bg-transparent flex flex-col justify-between space-y-6">
            <div className="space-y-2">
              <div className="flex items-center gap-2 text-onyx-900 dark:text-white">
                <Linkedin className="w-5 h-5 text-brand-orange" />
                <span className="font-mono text-[10px] uppercase tracking-wider font-bold">
                  Professional Ledger
                </span>
              </div>
              <p className="text-xs text-onyx-500 dark:text-white/40 leading-relaxed font-light">
                {locale === "ar"
                  ? "تواصل مهنياً لمتابعة آخر المنشورات والتحليلات الدقيقة لبيانات السوق الرقمي."
                  : "Connect with Mahmoud to inspect executive writeups, live event updates, and case reports."
                }
              </p>
            </div>
            <a 
              href="https://www.linkedin.com/in/mahmoud-gamal-akl-b30895200"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-1.5 text-xs font-mono text-brand-orange hover:underline uppercase tracking-wider"
            >
              <span>{l.linkedInBtn}</span>
              <ExternalLink className="w-3.5 h-3.5" />
            </a>
          </div>

          {/* Secure Telephony */}
          <div className="p-6 rounded-2xl border border-onyx-200/60 dark:border-white/5 bg-onyx-50/10 dark:bg-transparent flex flex-col justify-between space-y-6">
            <div className="space-y-2">
              <div className="flex items-center gap-2 text-onyx-900 dark:text-white">
                <Phone className="w-5 h-5 text-brand-orange" />
                <span className="font-mono text-[10px] uppercase tracking-wider font-bold">
                  Direct Line
                </span>
              </div>
              <p className="text-xs text-onyx-500 dark:text-white/40 leading-relaxed font-light">
                {locale === "ar"
                  ? "للمسائل العاجلة ومكالمات المشتريات ذات الميزانيات المليونية الفورية."
                  : "Direct telemetry line reserved for live consultations and immediate budgeting assessments."
                }
              </p>
            </div>
            <a 
              href="tel:01013988076"
              className="inline-flex items-center gap-1.5 text-xs font-mono text-brand-orange hover:underline uppercase tracking-wider"
            >
              <span>{l.callDirect}</span>
              <ExternalLink className="w-3.5 h-3.5" />
            </a>
          </div>

          {/* Secure Messaging App */}
          <div className="p-6 rounded-2xl border border-onyx-200/60 dark:border-white/5 bg-onyx-50/10 dark:bg-transparent flex flex-col justify-between space-y-6">
            <div className="space-y-2">
              <div className="flex items-center gap-2 text-onyx-900 dark:text-white">
                <Mail className="w-5 h-5 text-brand-orange" />
                <span className="font-mono text-[10px] uppercase tracking-wider font-bold">
                  Electronic Mail
                </span>
              </div>
              <p className="text-xs text-onyx-500 dark:text-white/40 leading-relaxed font-light">
                {locale === "ar"
                  ? "للمراسلات العامة وإرسال مسودات وثائق طلب العروض (RFP)."
                  : "Standard inbox calibrated for receiving secure RFPs, NDAs, and corporate inquiries."
                }
              </p>
            </div>
            <a 
              href="mailto:mahmoudd.gamall2002@gmail.com"
              className="inline-flex items-center gap-1.5 text-xs font-mono text-brand-orange hover:underline uppercase tracking-wider"
            >
              <span>{locale === "ar" ? "إرسال بريد إلكتروني" : "Transmit Secure Mail"}</span>
              <ExternalLink className="w-3.5 h-3.5" />
            </a>
          </div>

        </div>
      </section>

      {/* Google Sheets Integration Console */}
      <section id="google-sheets-console" className="p-8 sm:p-10 rounded-3xl border border-onyx-200/60 dark:border-white/5 bg-[#050505]/30 luxury-blur space-y-8">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 pb-6 border-b border-onyx-200/40 dark:border-white/5">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <Database className="w-4 h-4 text-brand-orange animate-pulse" />
              <span className="font-mono text-[9px] uppercase tracking-widest font-bold text-brand-orange">
                {l.sheetsTitle}
              </span>
            </div>
            <p className="text-xs text-onyx-500 dark:text-white/40 max-w-xl">
              {l.sheetsDesc}
            </p>
          </div>

          <div className="flex items-center gap-3 self-start md:self-center">
            {user ? (
              <div className="flex items-center gap-3">
                <div className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-green-500/10 border border-green-500/20 text-green-500 font-mono text-[9px]">
                  <span className="w-1.5 h-1.5 rounded-full bg-green-500 animate-ping" />
                  <span>{l.sheetsStatusConnected}</span>
                </div>
                <button
                  id="sheets-disconnect-button"
                  onClick={handleSignOut}
                  className="px-4 py-1.5 rounded-full border border-red-500/30 text-red-500 hover:bg-red-500/10 font-mono text-[10px] uppercase tracking-wider flex items-center gap-1.5 transition-all cursor-pointer"
                >
                  <LogOut className="w-3.5 h-3.5" />
                  <span>{l.sheetsDisconnectBtn}</span>
                </button>
              </div>
            ) : (
              <div className="flex items-center gap-2">
                <div className="px-3 py-1.5 rounded-full bg-onyx-100 dark:bg-white/5 text-onyx-400 dark:text-white/20 font-mono text-[9px]">
                  <span>{l.sheetsStatusDisconnected}</span>
                </div>
                <button
                  id="sheets-connect-button"
                  onClick={handleSignIn}
                  disabled={isConnecting}
                  className="px-5 py-2.5 rounded-full bg-onyx-950 text-white dark:bg-white dark:text-onyx-950 hover:bg-brand-orange dark:hover:bg-brand-orange hover:text-white dark:hover:text-white font-mono text-[10px] uppercase tracking-widest font-bold transition-all flex items-center gap-2 disabled:opacity-50 cursor-pointer"
                >
                  <Database className="w-3.5 h-3.5" />
                  <span>{isConnecting ? "AUTHORIZING..." : l.sheetsConnectBtn}</span>
                </button>
              </div>
            )}
          </div>
        </div>

        {sheetError && (
          <div className="p-4 rounded-xl border border-red-500/20 bg-red-500/[0.03] text-red-500 text-xs font-mono flex items-center gap-2">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span>{sheetError}</span>
          </div>
        )}

        {sheetSuccess && (
          <div className="p-4 rounded-xl border border-green-500/20 bg-green-500/[0.03] text-green-500 text-xs font-mono flex items-center gap-2">
            <Check className="w-4 h-4 shrink-0" />
            <span>{sheetSuccess}</span>
          </div>
        )}

        {user && (
          <div className="space-y-8">
            {/* Connection Profile details */}
            <div className="p-4 rounded-2xl bg-onyx-100/50 dark:bg-white/[0.01] border border-onyx-200/40 dark:border-white/5 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
              <div className="flex items-center gap-3">
                {user.photoURL ? (
                  <img src={user.photoURL} alt={user.displayName || "Admin"} referrerPolicy="no-referrer" className="w-10 h-10 rounded-full border border-brand-orange/30" />
                ) : (
                  <div className="w-10 h-10 rounded-full bg-brand-orange/10 border border-brand-orange/30 flex items-center justify-center font-mono text-sm text-brand-orange">
                    {user.displayName?.charAt(0) || "U"}
                  </div>
                )}
                <div>
                  <h4 className="text-xs font-mono text-onyx-900 dark:text-white font-bold">{user.displayName || "Authorized Administrator"}</h4>
                  <p className="text-[10px] font-mono text-onyx-400 dark:text-white/30">{user.email}</p>
                </div>
              </div>

              {spreadsheetId && (
                <div className="flex flex-wrap gap-2">
                  <a
                    id="sheets-open-link"
                    href={`https://docs.google.com/spreadsheets/d/${spreadsheetId}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="px-4 py-2 rounded-lg bg-green-600 hover:bg-green-700 text-white font-mono text-[10px] uppercase tracking-wider flex items-center gap-1.5 transition-colors"
                  >
                    <FileSpreadsheet className="w-3.5 h-3.5" />
                    <span>{l.sheetsOpenBtn}</span>
                  </a>
                  <button
                    id="sheets-manual-sync"
                    onClick={handleManualSync}
                    disabled={isManualSyncing || isLoadingLeads}
                    className="px-4 py-2 rounded-lg bg-onyx-100 dark:bg-white/5 border border-onyx-200 dark:border-white/10 text-onyx-700 dark:text-white/75 hover:border-brand-orange font-mono text-[10px] uppercase tracking-wider flex items-center gap-1.5 transition-colors cursor-pointer"
                  >
                    <RefreshCw className={`w-3.5 h-3.5 ${isManualSyncing ? "animate-spin" : ""}`} />
                    <span>{l.sheetsManualSyncBtn}</span>
                  </button>
                  <button
                    id="sheets-unlink-button"
                    onClick={handleUnlinkSheet}
                    className="px-4 py-2 rounded-lg border border-red-500/20 text-red-500 hover:bg-red-500/5 font-mono text-[10px] uppercase tracking-wider transition-colors cursor-pointer"
                  >
                    UNLINK TARGET
                  </button>
                </div>
              )}
            </div>

            {/* Target Settings */}
            {!spreadsheetId ? (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {/* Create Sheet Option */}
                <div className="p-6 rounded-2xl border border-dashed border-onyx-250 dark:border-white/10 bg-onyx-50/10 dark:bg-transparent flex flex-col justify-between space-y-6">
                  <div className="space-y-2">
                    <h4 className="font-mono text-[10px] uppercase tracking-wider font-bold text-onyx-900 dark:text-white">
                      {l.sheetsNoSheetLinked}
                    </h4>
                    <p className="text-xs text-onyx-500 dark:text-white/40 leading-relaxed font-light">
                      {l.sheetsNoSheetLinkedDesc}
                    </p>
                  </div>
                  <button
                    id="sheets-create-new-button"
                    onClick={handleCreateSheet}
                    disabled={isCreatingSheet}
                    className="w-full py-3 rounded-xl bg-onyx-950 text-white dark:bg-white dark:text-onyx-950 hover:bg-brand-orange dark:hover:bg-brand-orange hover:text-white dark:hover:text-white font-mono text-[10px] uppercase tracking-widest font-bold transition-all flex items-center justify-center gap-2 cursor-pointer"
                  >
                    <Plus className="w-4 h-4" />
                    <span>{isCreatingSheet ? l.sheetsCreatingBtn : l.sheetsCreateBtn}</span>
                  </button>
                </div>

                {/* Link Existing Sheet Option */}
                <div className="p-6 rounded-2xl border border-dashed border-onyx-250 dark:border-white/10 bg-onyx-50/10 dark:bg-transparent flex flex-col justify-between space-y-6">
                  <div className="space-y-2">
                    <h4 className="font-mono text-[10px] uppercase tracking-wider font-bold text-onyx-900 dark:text-white">
                      LINK EXISTING GOOGLE SHEET
                    </h4>
                    <p className="text-xs text-onyx-500 dark:text-white/40 leading-relaxed font-light">
                      Enter the Google Sheet ID from your browser's address bar to synchronize with an existing spreadsheet.
                    </p>
                  </div>
                  <form onSubmit={handleLinkExistingSheet} className="flex gap-2">
                    <input
                      id="sheets-existing-id-input"
                      type="text"
                      required
                      placeholder={l.sheetsLinkInputPlaceholder}
                      value={customSpreadsheetId}
                      onChange={(e) => setCustomSpreadsheetId(e.target.value)}
                      className="flex-1 px-3 py-2.5 rounded-xl border border-onyx-200 dark:border-white/10 bg-onyx-100/30 dark:bg-[#070707] text-onyx-900 dark:text-white text-[11px] font-mono focus:outline-none focus:border-brand-orange"
                    />
                    <button
                      id="sheets-existing-link-submit"
                      type="submit"
                      className="px-4 py-2.5 rounded-xl bg-onyx-950 text-white dark:bg-white dark:text-onyx-950 hover:bg-brand-orange dark:hover:bg-brand-orange hover:text-white dark:hover:text-white font-mono text-[10px] uppercase tracking-wider font-bold transition-all shrink-0 cursor-pointer"
                    >
                      <LinkIcon className="w-3.5 h-3.5" />
                    </button>
                  </form>
                </div>
              </div>
            ) : (
              /* Leads Ledger Table */
              <div className="space-y-4">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                  <div>
                    <h4 className="font-serif text-lg font-light text-onyx-950 dark:text-white tracking-tight">
                      {l.sheetsLeadsTitle}
                    </h4>
                    <p className="text-[10px] font-mono text-onyx-400 dark:text-white/20">
                      {l.sheetsLeadsDesc}
                    </p>
                  </div>
                  
                  <div className="font-mono text-[9px] text-brand-orange break-all">
                    SHEET ID: {spreadsheetId.slice(0, 12)}...{spreadsheetId.slice(-12)}
                  </div>
                </div>

                {isLoadingLeads ? (
                  <div className="py-12 border border-onyx-200/40 dark:border-white/5 rounded-2xl bg-onyx-50/20 dark:bg-white/[0.005] flex flex-col items-center justify-center space-y-3">
                    <RefreshCw className="w-6 h-6 text-brand-orange animate-spin" />
                    <span className="font-mono text-[10px] text-onyx-400 dark:text-white/30">
                      {l.sheetsLoadingLeads}
                    </span>
                  </div>
                ) : leads.length === 0 ? (
                  <div className="py-12 border border-dashed border-onyx-200/60 dark:border-white/5 rounded-2xl bg-onyx-50/20 dark:bg-white/[0.005] flex flex-col items-center justify-center text-center space-y-2">
                    <FileSpreadsheet className="w-8 h-8 text-onyx-300 dark:text-white/10 animate-bounce" />
                    <span className="font-mono text-[11px] text-onyx-500 dark:text-white/40">
                      {l.sheetsNoLeads}
                    </span>
                  </div>
                ) : (
                  <div className="border border-onyx-200/40 dark:border-white/5 rounded-2xl overflow-hidden bg-onyx-50/10 dark:bg-[#070707]/30">
                    <div className="overflow-x-auto">
                      <table className="w-full text-left border-collapse">
                        <thead>
                          <tr className="border-b border-onyx-200/40 dark:border-white/5 bg-onyx-100/50 dark:bg-white/[0.01] font-mono text-[9px] uppercase tracking-wider text-onyx-500 dark:text-white/30">
                            <th className="px-4 py-3 font-semibold">{l.sheetsLeadHeaderTimestamp}</th>
                            <th className="px-4 py-3 font-semibold">{l.sheetsLeadHeaderName}</th>
                            <th className="px-4 py-3 font-semibold">{l.sheetsLeadHeaderService}</th>
                            <th className="px-4 py-3 font-semibold">{l.sheetsLeadHeaderStatus}</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-onyx-200/40 dark:divide-white/5 font-mono text-[10px] text-onyx-700 dark:text-white/60">
                          {leads.map((lead, idx) => (
                            <tr key={idx} className="hover:bg-onyx-100/30 dark:hover:bg-white/[0.005] transition-colors">
                              <td className="px-4 py-3 whitespace-nowrap text-[9px] text-onyx-400 dark:text-white/30">{lead.timestamp}</td>
                              <td className="px-4 py-3 font-medium text-onyx-950 dark:text-white">
                                <div>{lead.name}</div>
                                <div className="text-[9px] text-onyx-400 dark:text-white/30 font-light">{lead.email}</div>
                              </td>
                              <td className="px-4 py-3">
                                <span className="px-2 py-0.5 rounded-full bg-brand-orange/10 border border-brand-orange/20 text-brand-orange text-[9px]">
                                  {lead.service.toUpperCase()}
                                </span>
                              </td>
                              <td className="px-4 py-3">
                                <select
                                  id={`lead-status-select-${idx}`}
                                  value={lead.status}
                                  onChange={(e) => handleUpdateLeadStatus(idx, e.target.value)}
                                  className="bg-white dark:bg-[#080808] border border-onyx-200 dark:border-white/10 rounded px-2 py-1 text-[9px] focus:outline-none focus:border-brand-orange cursor-pointer text-onyx-900 dark:text-white"
                                >
                                  <option value="New Inquiry" className="bg-white dark:bg-[#080808]">{l.sheetsStatusNew}</option>
                                  <option value="In Progress" className="bg-white dark:bg-[#080808]">{l.sheetsStatusInContact}</option>
                                  <option value="Audit Completed" className="bg-white dark:bg-[#080808]">{l.sheetsStatusAuditDone}</option>
                                </select>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>
                )}
              </div>
            )}
          </div>
        )}
      </section>

      {/* Verification Seal footer */}
      <section className="text-center space-y-3 pt-4">
        <p className="text-[10px] font-mono text-onyx-400 dark:text-white/20 uppercase tracking-[0.2em]">
          INTEGRITY SYSTEMS VERIFIED // SECURE NODE ACTIVE
        </p>
      </section>

    </div>
  );
}
