import * as React from "react";
import { ErrorInfo, ReactNode } from "react";
import { useLanguage } from "./LanguageContext";
import { AlertTriangle, RefreshCw, Home } from "lucide-react";

interface Props {
  children?: ReactNode;
}

interface State {
  hasError: boolean;
  error: Error | null;
}

export class ErrorBoundary extends React.Component<Props, State> {
  constructor(props: Props) {
    super(props);
    this.state = {
      hasError: false,
      error: null
    };
  }

  public static getDerivedStateFromError(error: Error): State {
    // Update state so the next render will show the fallback UI.
    return { hasError: true, error };
  }

  public override componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    console.error("Architectural layout crash caught by ErrorBoundary:", error, errorInfo);
  }

  public override render() {
    if (this.state.hasError) {
      return (
        <ErrorFallback 
          error={this.state.error} 
          onReset={() => this.setState({ hasError: false, error: null })} 
        />
      );
    }

    return this.props.children;
  }
}

function ErrorFallback({ error, onReset }: { error: Error | null; onReset: () => void }) {
  // We can't guarantee useLanguage() will resolve perfectly inside a crashed context,
  // so we fallback safely or inspect locale from cookie/localStorage/navigator.
  let isAr = false;
  try {
    const savedLang = localStorage.getItem("preferred_lang");
    if (savedLang === "ar" || navigator.language.startsWith("ar")) {
      isAr = true;
    }
  } catch (e) {
    // Safe ignore
  }

  const handleReload = () => {
    onReset();
    window.location.hash = "#/";
    window.location.reload();
  };

  return (
    <div 
      id="error-boundary-screen"
      className="min-h-screen flex items-center justify-center bg-onyx-50 dark:bg-[#050505] px-6 py-12 text-center"
      dir={isAr ? "rtl" : "ltr"}
    >
      <div className="max-w-md w-full bg-white dark:bg-[#0D0D0D] border border-onyx-200 dark:border-white/5 p-8 md:p-10 rounded-2xl shadow-xl space-y-6 relative overflow-hidden">
        {/* Luxury subtle decorative outline */}
        <div className="absolute top-0 inset-x-0 h-[3px] bg-brand-orange" />

        <div className="flex justify-center">
          <div className="p-3 bg-red-500/10 rounded-full text-red-500">
            <AlertTriangle className="w-8 h-8" />
          </div>
        </div>

        <div className="space-y-2">
          <h1 className="font-serif text-2xl font-light text-onyx-950 dark:text-white">
            {isAr ? "حدث خلل هيكلي" : "Structural Anomaly Detected"}
          </h1>
          <p className="text-xs font-mono uppercase tracking-wider text-brand-orange">
            {isAr ? "محرك العرض المعماري تعطل مؤقتاً" : "Layout Engine Encountered an Exception"}
          </p>
        </div>

        <div className="bg-onyx-50 dark:bg-white/5 p-4 rounded-lg border border-onyx-100 dark:border-white/5 text-left font-mono text-xs text-onyx-500 dark:text-white/40 overflow-auto max-h-36">
          <span className="font-semibold text-red-500">Error:</span> {error?.message || "Unknown runtime exception in UI thread"}
        </div>

        <p className="text-xs text-onyx-400 dark:text-white/30 leading-relaxed">
          {isAr 
            ? "حدثت مشكلة غير متوقعة أثناء عرض هذا المنظور. يرجى محاولة استعادة الحالة أو إعادة تحميل اللوحة الرقمية." 
            : "An unexpected layout rendering mismatch occurred. Try resetting the current view matrix or returning to the landing viewport."}
        </p>

        <div className="grid grid-cols-2 gap-4 pt-2">
          <button
            onClick={handleReload}
            className="flex items-center justify-center gap-2 px-4 py-2.5 rounded-lg text-xs font-mono uppercase tracking-wider text-white bg-brand-orange hover:bg-brand-orange/90 transition-all cursor-pointer"
          >
            <RefreshCw className="w-3.5 h-3.5 animate-spin-reverse" />
            {isAr ? "إعادة البناء" : "Rebuild state"}
          </button>
          
          <button
            onClick={() => {
              onReset();
              window.location.hash = "#/";
            }}
            className="flex items-center justify-center gap-2 px-4 py-2.5 rounded-lg text-xs font-mono uppercase tracking-wider text-onyx-800 dark:text-white bg-onyx-100 hover:bg-onyx-200 dark:bg-white/10 dark:hover:bg-white/20 transition-all cursor-pointer"
          >
            <Home className="w-3.5 h-3.5" />
            {isAr ? "الرئيسية" : "Canvas Home"}
          </button>
        </div>
      </div>
    </div>
  );
}
