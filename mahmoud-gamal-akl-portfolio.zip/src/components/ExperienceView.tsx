import React, { useState } from "react";
import { useLanguage } from "./LanguageContext";
import { portfolioData } from "../data/portfolio";
import { 
  Briefcase, 
  Calendar, 
  Building2, 
  ChevronLeft, 
  ArrowRight, 
  Award,
  Compass,
  Cpu,
  Target,
  FileSpreadsheet,
  Layers,
  LineChart,
  ShieldCheck,
  CheckCircle2
} from "lucide-react";
import { motion } from "motion/react";

export default function ExperienceView() {
  const { t, locale, dir } = useLanguage();
  const [hoveredIndex, setHoveredIndex] = useState<string | null>(null);

  // Trajectory narrative (Executive Career Journey)
  const journeyNarrative = {
    en: {
      title: "The Professional Trajectory",
      subtitle: "Navigating high-stakes marketing, industrial alignment, and consumer scale.",
      body1: "My career has been built on a single underlying principle: treat marketing budgets not as creative expenses, but as critical engines of corporate growth. From heavy industries and ready-mixed concrete supply lines to advanced proptech structures and consumer retail footprints, I have designed systems that capture and convert high-intent market segments.",
      body2: "As an executive-level performance specialist, my operational role is to establish clear and pixel-perfect customer acquisition pipelines. This ledger demonstrates consistent delivery of growth, structure, and clarity across diverse sectors."
    },
    ar: {
      title: "الخط الزمني للمسيرة المهنية",
      subtitle: "توجيه التسويق عالي المردود، والتوافق الإنشائي الصناعي، والوصول للجمهور.",
      body1: "تأسست مسيرتي المهنية على مبدأ أساسي واحد: معاملة ميزانيات التسويق كأصول استثمارية ومحركات نمو حقيقية للمؤسسة، لا كمصاريف إبداعية مهدرة. من الصناعات الثقيلة وخطوط توريد الخرسانة الجاهزة إلى حلول التطوير العقاري التقني ومبيعات التجزئة، قمت بتطوير وبناء الأنظمة التي تستهدف وتجذب الفئات الأكثر ملاءمة للشراء.",
      body2: "بصفتي مستشاراً وخبيراً في تسويق الأداء، يرتكز دوري على بناء مسارات واضحة ودقيقة لامتلاك السوق وتوليد الطلب. يوضح هذا السجل الأثر الملموس الذي أقدمه لمختلف القطاعات التجارية بنجاح تام."
    }
  };

  return (
    <div id="experience-profile-container" className="min-h-screen py-16 px-6 max-w-7xl mx-auto space-y-24 relative z-10">
      
      {/* Navigation Breadcrumb */}
      <div className="flex justify-between items-center pb-4 border-b border-onyx-200/40 dark:border-white/5">
        <a 
          href="#/" 
          className="inline-flex items-center gap-2 text-xs font-mono uppercase tracking-widest text-onyx-400 hover:text-brand-orange transition-colors group"
        >
          <ChevronLeft className="w-4 h-4 group-hover:-translate-x-1 transition-transform rtl:rotate-180" />
          <span>{locale === "ar" ? "العودة للرئيسية" : "Return to Systems Overview"}</span>
        </a>
        <span className="font-mono text-[9px] uppercase tracking-widest text-onyx-300 dark:text-white/20">
          Executive Portfolio // Career Milestones & Ledger
        </span>
      </div>

      {/* Hero Header Section */}
      <section className="space-y-8 max-w-4xl">
        <div className="space-y-3">
          <div className="flex items-center gap-3">
            <span className="w-1.5 h-1.5 bg-brand-orange rounded-full"></span>
            <span className="font-mono text-[10px] uppercase tracking-[0.35em] text-brand-orange font-bold">
              {locale === "ar" ? "المسيرة المهنية التنفيذية" : "EXECUTIVE CHRONOLOGY & RECORD"}
            </span>
          </div>

          <h1 className="font-serif text-4xl sm:text-6xl md:text-[80px] leading-[0.95] font-light tracking-tighter text-onyx-950 dark:text-white">
            {locale === "ar" ? "السجل والمسيرة" : "Corporate Journey"}{" "}
            <span className="text-onyx-400 dark:text-white/30">
              {locale === "ar" ? "المهنية الحافلة" : "& Ledger"}
            </span>
          </h1>
          
          <p className="font-sans text-lg text-onyx-600 dark:text-white/60 font-light leading-relaxed max-w-3xl">
            {locale === "ar" 
              ? "مراجعة دقيقة وتفصيلية للمسؤوليات والأنظمة التسويقية التي تمت قيادتها وتطويرها في مختلف الكيانات والمؤسسات."
              : "A comprehensive ledger of operational marketing systems, brand alignments, and high-performance campaigns deployed across industrial, real estate, and retail landscapes."
            }
          </p>
        </div>
      </section>

      {/* Trajectory narrative & Philosophy Split */}
      <section className="grid grid-cols-1 lg:grid-cols-5 gap-16 items-start py-12 border-y border-onyx-200/40 dark:border-white/5 bg-onyx-50/50 dark:bg-white/[0.01] p-8 rounded-3xl">
        <div className="lg:col-span-2 space-y-4">
          <span className="font-mono text-[10px] uppercase tracking-[0.3em] text-brand-orange block font-bold">
            THE CAREER VISION
          </span>
          <h2 className="font-serif text-3xl font-light tracking-tight text-onyx-950 dark:text-white">
            {locale === "ar" ? journeyNarrative.ar.title : journeyNarrative.en.title}
          </h2>
          <p className="text-xs text-onyx-400 dark:text-onyx-500 font-mono tracking-wider">
            {locale === "ar" ? journeyNarrative.ar.subtitle : journeyNarrative.en.subtitle}
          </p>
        </div>

        <div className="lg:col-span-3 space-y-6 text-sm sm:text-base text-onyx-600 dark:text-white/70 font-light leading-relaxed">
          <p>
            {locale === "ar" ? journeyNarrative.ar.body1 : journeyNarrative.en.body1}
          </p>
          <p>
            {locale === "ar" ? journeyNarrative.ar.body2 : journeyNarrative.en.body2}
          </p>
        </div>
      </section>

      {/* High-Fidelity Chronological Timeline */}
      <section className="relative space-y-16">
        <div className="absolute left-[23px] rtl:left-auto rtl:right-[23px] top-8 bottom-8 w-[2px] bg-gradient-to-b from-brand-orange via-onyx-200 to-onyx-100 dark:via-white/10 dark:to-white/5"></div>

        <div className="space-y-16">
          {portfolioData.experience.map((exp, idx) => {
            const isHovered = hoveredIndex === exp.id;
            return (
              <div 
                key={exp.id}
                className="relative pl-14 rtl:pl-0 rtl:pr-14 group transition-all duration-300"
                onMouseEnter={() => setHoveredIndex(exp.id)}
                onMouseLeave={() => setHoveredIndex(null)}
              >
                {/* Timeline node */}
                <div 
                  className={`absolute left-[13px] rtl:left-auto rtl:right-[13px] top-1 w-[22px] h-[22px] rounded-full border-2 transition-all duration-500 flex items-center justify-center bg-white dark:bg-[#050505] z-10 ${
                    isHovered 
                      ? "border-brand-orange scale-125 shadow-[0_0_15px_rgba(242,125,38,0.4)]" 
                      : "border-onyx-300 dark:border-white/20"
                  }`}
                >
                  <div className={`w-2 h-2 rounded-full transition-all duration-500 ${
                    isHovered ? "bg-brand-orange scale-110" : "bg-onyx-400 dark:bg-white/40"
                  }`} />
                </div>

                {/* Main Card Content */}
                <div className={`p-8 sm:p-10 rounded-3xl border transition-all duration-300 bg-white dark:bg-[#080808] ${
                  isHovered 
                    ? "border-brand-orange/40 shadow-md translate-x-1 rtl:-translate-x-1" 
                    : "border-onyx-200/60 dark:border-white/5"
                }`}>
                  {/* Timeline Header Metadata */}
                  <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-6 border-b border-onyx-100 dark:border-white/5">
                    <div className="space-y-1.5">
                      <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-brand-orange/10 text-brand-orange font-mono text-[10px] font-bold tracking-wider uppercase">
                        <Calendar className="w-3 h-3" />
                        {exp.period}
                      </div>
                      
                      <h3 className="font-serif text-2xl sm:text-3xl font-semibold text-onyx-950 dark:text-white tracking-tight">
                        {locale === "ar" ? exp.role.ar : exp.role.en}
                      </h3>

                      <div className="flex items-center gap-2 text-xs font-mono text-onyx-500 dark:text-white/40">
                        <Building2 className="w-3.5 h-3.5 text-brand-orange" />
                        <span className="font-semibold text-onyx-800 dark:text-white/70">
                          {locale === "ar" ? exp.company.ar : exp.company.en}
                        </span>
                      </div>
                    </div>

                    <div className="hidden md:block font-mono text-[9px] text-onyx-300 dark:text-white/10 tracking-widest text-right">
                      LEDGER ID // 0{idx + 1}
                    </div>
                  </div>

                  {/* Operational Narrative Description */}
                  <div className="py-6 space-y-4">
                    <span className="font-mono text-[9px] uppercase tracking-wider text-brand-orange block font-bold">
                      {locale === "ar" ? "نطاق المسؤوليات التشغيلية" : "CORE OPERATIONAL MANDATE"}
                    </span>
                    <p className="text-sm sm:text-base text-onyx-600 dark:text-white/70 font-light leading-relaxed">
                      {locale === "ar" ? exp.description.ar : exp.description.en}
                    </p>
                  </div>

                  {/* Responsibilities Systems Matrix */}
                  <div className="space-y-4 pt-6 border-t border-onyx-100 dark:border-white/5">
                    <span className="font-mono text-[9px] uppercase tracking-wider text-brand-orange block font-bold">
                      {locale === "ar" ? "الأنظمة والمهام الخاضعة للإشراف" : "SYSTEMS UNDER DIRECT EXECUTION"}
                    </span>
                    
                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                      {(locale === "ar" ? exp.highlights.ar : exp.highlights.en).map((hl, hlIdx) => (
                        <div 
                          key={hlIdx}
                          className="flex items-center gap-2.5 p-3.5 rounded-2xl border border-onyx-100 dark:border-white/5 bg-onyx-50/50 dark:bg-white/[0.01] hover:border-brand-orange/20 transition-all duration-300"
                        >
                          <CheckCircle2 className="w-4 h-4 text-brand-orange flex-shrink-0" />
                          <span className="text-xs sm:text-sm text-onyx-700 dark:text-white/80 font-medium font-sans">
                            {hl}
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </section>

      {/* Advisory Blueprint & Trust block */}
      <section className="py-12 border-y border-onyx-200/40 dark:border-white/5">
        <div className="grid grid-cols-1 lg:grid-cols-5 gap-16 items-center">
          <div className="lg:col-span-3 space-y-6">
            <span className="font-mono text-[10px] uppercase tracking-[0.3em] text-brand-orange block font-bold">
              SYSTEM ALIGNMENT
            </span>
            <h2 className="font-serif text-3xl sm:text-4xl font-light tracking-tight text-onyx-950 dark:text-white">
              {locale === "ar" ? "ضمان التكامل والتوافق الفني" : "The Architectural Alignment Blueprint"}
            </h2>
            <p className="text-sm sm:text-base text-onyx-500 dark:text-white/60 leading-relaxed font-light">
              {locale === "ar" 
                ? "عندما نعمل سوياً، لا نقوم فقط بإطلاق حملات إعلانية عشوائية. نحن نبني قنوات تتبع متكاملة ونربطها بقواعد البيانات ونوعي الكوادر لإدارة الآلة التسويقية بكفاءة ذاتية كاملة ومستدامة للتوقف عن النزيف المالي."
                : "When integrating these systems, Mahmoud establishes fully redundant first-party tracking environments, eliminating reliance on platform estimates. By integrating standard playbooks, we shift marketing departments from chaotic cost centers to systematic commercial generators."}
            </p>
          </div>
          
          <div className="lg:col-span-2 grid grid-cols-2 gap-4">
            <div className="p-5 rounded-2xl border border-onyx-200/40 bg-white/50 dark:border-white/5 dark:bg-[#0c0c0c]/40 text-center space-y-2">
              <span className="font-serif text-3xl font-light text-brand-orange block">100%</span>
              <span className="font-mono text-[9px] text-onyx-400 dark:text-white/40 uppercase block">First-Party Data Tracking</span>
            </div>
            <div className="p-5 rounded-2xl border border-onyx-200/40 bg-white/50 dark:border-white/5 dark:bg-[#0c0c0c]/40 text-center space-y-2">
              <span className="font-serif text-3xl font-light text-brand-orange block">30%</span>
              <span className="font-mono text-[9px] text-onyx-400 dark:text-white/40 uppercase block">Sales Cycle Shortening</span>
            </div>
            <div className="p-5 rounded-2xl border border-onyx-200/40 bg-white/50 dark:border-white/5 dark:bg-[#0c0c0c]/40 text-center space-y-2">
              <span className="font-serif text-3xl font-light text-brand-orange block">3:1+</span>
              <span className="font-mono text-[9px] text-onyx-400 dark:text-white/40 uppercase block">Target LTV:CAC Ratio</span>
            </div>
            <div className="p-5 rounded-2xl border border-onyx-200/40 bg-white/50 dark:border-white/5 dark:bg-[#0c0c0c]/40 text-center space-y-2">
              <span className="font-serif text-3xl font-light text-brand-orange block">Zero</span>
              <span className="font-mono text-[9px] text-onyx-400 dark:text-white/40 uppercase block">Agency Overhead Fluff</span>
            </div>
          </div>
        </div>
      </section>

      {/* Executive Inquiry Call To Action */}
      <section className="pt-16 border-t border-onyx-200/40 dark:border-white/5 text-center space-y-8">
        <div className="max-w-2xl mx-auto space-y-4">
          <h2 className="font-serif text-2xl sm:text-3xl font-light text-onyx-950 dark:text-white">
            {locale === "ar" ? "جاهز لتمكين مؤسستك؟" : "Secure Elite Marketing Direction"}
          </h2>
          <p className="text-xs sm:text-sm text-onyx-500 dark:text-white/50 leading-relaxed font-mono">
            {locale === "ar" 
              ? "حرك الخطوة القادمة عبر حجز استفسار تنفيذي لبدء فحص وتقييم الأنظمة النشطة في كيانك التجاري."
              : "Initiate an executive inquiry to thoroughly evaluate your active media performance models and build compounding systems."}
          </p>
        </div>

        <a 
          href="#/contact"
          className="inline-flex items-center gap-2 px-6 py-3.5 rounded-full bg-onyx-950 text-white dark:bg-white dark:text-onyx-950 hover:bg-brand-orange dark:hover:bg-brand-orange hover:text-white dark:hover:text-white text-xs font-mono uppercase tracking-wider font-semibold transition-all duration-300"
        >
          <span>{locale === "ar" ? "طلب جلسة استشارية" : "Initiate Corporate Advisory"}</span>
          <ArrowRight className="w-4 h-4 rtl:rotate-180 animate-pulse" />
        </a>
      </section>

    </div>
  );
}
