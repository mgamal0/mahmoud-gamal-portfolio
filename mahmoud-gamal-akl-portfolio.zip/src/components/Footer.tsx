import { useEffect, useState } from "react";
import { useLanguage } from "./LanguageContext";
import { portfolioData } from "../data/portfolio";
import { Github, Linkedin, Twitter, Mail, ArrowUp } from "lucide-react";

export default function Footer() {
  const { t, locale } = useLanguage();
  const [localTime, setLocalTime] = useState("");

  useEffect(() => {
    const updateTime = () => {
      try {
        const formatter = new Intl.DateTimeFormat(locale === "ar" ? "ar-EG" : "en-US", {
          timeZone: portfolioData.personal.timezone,
          hour: "2-digit",
          minute: "2-digit",
          second: "2-digit",
          hour12: true,
        });
        setLocalTime(formatter.format(new Date()));
      } catch (e) {
        // Fallback if timezone not supported in environment
        setLocalTime(new Date().toLocaleTimeString());
      }
    };

    updateTime();
    const interval = setInterval(updateTime, 1000);
    return () => clearInterval(interval);
  }, [locale]);

  const socialLinks = [
    { icon: Github, href: portfolioData.personal.github, label: "GitHub" },
    { icon: Linkedin, href: portfolioData.personal.linkedin, label: "LinkedIn" },
    { icon: Twitter, href: portfolioData.personal.twitter, label: "Twitter" },
    { icon: Mail, href: `mailto:${portfolioData.personal.email}`, label: "Email" },
  ];

  return (
    <footer
      id="main-footer"
      className="w-full border-t border-onyx-200/40 bg-onyx-50/20 dark:border-white/5 dark:bg-[#050505]/40 py-16 transition-colors duration-500"
    >
      <div className="max-w-7xl mx-auto px-6">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-12 items-start">
          {/* Brand Column */}
          <div className="space-y-4">
            <h3 className="font-serif font-bold text-xl text-onyx-900 dark:text-white">
              {portfolioData.personal.name}
            </h3>
            <p className="text-xs text-onyx-500 dark:text-onyx-400 max-w-sm leading-relaxed">
              {portfolioData.personal.subtitle}
            </p>
          </div>

          {/* Local Time Indicator */}
          <div className="space-y-2 border-l border-onyx-200/40 dark:border-white/5 pl-6 rtl:border-l-0 rtl:border-r rtl:pl-0 rtl:pr-6">
            <span className="font-mono text-[10px] font-medium uppercase tracking-widest text-onyx-400 dark:text-onyx-600">
              {t("footer.localTime")}
            </span>
            <div className="font-mono text-lg font-light text-onyx-800 dark:text-onyx-200 tabular-nums">
              {localTime || "00:00:00 AM"}
            </div>
            <p className="text-[10px] text-brand-orange dark:text-brand-orange font-mono">
              {portfolioData.personal.location} ({portfolioData.personal.timezone})
            </p>
          </div>

          {/* Socials & Top Button */}
          <div className="flex flex-col sm:items-end justify-between h-full gap-6">
            <div className="flex items-center gap-4">
              {socialLinks.map((soc) => {
                const Icon = soc.icon;
                return (
                  <a
                    key={soc.label}
                    id={`social-link-${soc.label}`}
                    href={soc.href}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="p-2 rounded-full border border-onyx-200/60 text-onyx-600 hover:text-brand-orange hover:border-brand-orange/60 dark:border-white/10 dark:text-onyx-400 dark:hover:text-brand-orange dark:hover:border-brand-orange/60 transition-all duration-300"
                    aria-label={soc.label}
                  >
                    <Icon className="w-4 h-4" />
                  </a>
                );
              })}
            </div>
            
            <button
              id="back-to-top-btn"
              onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}
              className="flex items-center gap-2 text-xs font-mono uppercase tracking-wider text-onyx-500 hover:text-onyx-950 dark:hover:text-white transition-colors cursor-pointer self-start sm:self-auto"
            >
              <span>{locale === "ar" ? "الرجوع للأعلى" : "Back to top"}</span>
              <ArrowUp className="w-3.5 h-3.5 text-brand-orange animate-bounce" />
            </button>
          </div>
        </div>

        {/* Divider */}
        <div className="w-full h-[1px] bg-onyx-200/40 dark:bg-white/5 my-10" />

        {/* Bottom Line */}
        <div className="flex flex-col sm:flex-row items-center justify-between gap-6 text-[11px] text-onyx-400 dark:text-onyx-500 font-mono">
          <div className="space-y-1">
            <div>
              &copy; {new Date().getFullYear()} {portfolioData.personal.name}. {t("footer.rights")}
            </div>
            <div className="text-[10px] text-onyx-300 dark:text-onyx-600 italic">
              {t("footer.motto")}
            </div>
          </div>
          <div className="text-right flex flex-col gap-2 items-center sm:items-end">
            <div className="flex gap-2">
              <span className="px-2 py-0.5 border border-onyx-200/60 dark:border-white/10 rounded text-[9px] tracking-wider uppercase opacity-60">Schema.org/Person</span>
              <span className="px-2 py-0.5 border border-onyx-200/60 dark:border-white/10 rounded text-[9px] tracking-wider uppercase opacity-60">JSON-LD</span>
            </div>
            <p className="text-[9px] tracking-widest font-light opacity-50 uppercase">
              Designed for Longevity. Engineered with Discipline.
            </p>
          </div>
        </div>
      </div>
    </footer>
  );
}
