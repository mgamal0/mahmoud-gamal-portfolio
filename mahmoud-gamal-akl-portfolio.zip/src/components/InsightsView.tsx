import React, { useState, useMemo } from "react";
import { useLanguage } from "./LanguageContext";
import { 
  ChevronLeft, 
  ArrowRight, 
  BookOpen, 
  Search, 
  Clock, 
  User, 
  Share2, 
  Calendar, 
  ArrowUpRight, 
  Sparkles, 
  TrendingUp, 
  ShieldCheck, 
  Mail, 
  SlidersHorizontal,
  Bookmark,
  CheckCircle2,
  Tag,
  Check,
  Flame,
  FileText
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

interface Article {
  id: string;
  category: "marketing" | "performance" | "branding" | "growth" | "sales" | "seo";
  categoryLabel: { en: string; ar: string };
  title: { en: string; ar: string };
  summary: { en: string; ar: string };
  content: { en: string; ar: string };
  readTime: { en: string; ar: string };
  publishedAt: { en: string; ar: string };
  imageUrl: string;
  accentColor: string;
  author: { en: string; ar: string };
  featured?: boolean;
}

export default function InsightsView() {
  const { locale, dir } = useLanguage();
  const [activeCategory, setActiveCategory] = useState<string>("all");
  const [searchQuery, setSearchQuery] = useState<string>("");
  const [selectedArticle, setSelectedArticle] = useState<Article | null>(null);
  const [sortBy, setSortBy] = useState<"newest" | "popular">("newest");
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [subEmail, setSubEmail] = useState("");
  const [subStatus, setSubStatus] = useState<"idle" | "success">("idle");
  const [bottomEmail, setBottomEmail] = useState("");
  const [bottomStatus, setBottomStatus] = useState<"idle" | "success">("idle");

  const categories = [
    { id: "all", label: { en: "All Intel", ar: "كل التقارير" } },
    { id: "marketing", label: { en: "Marketing", ar: "التسويق" } },
    { id: "performance", label: { en: "Performance", ar: "الأداء الرقمي" } },
    { id: "branding", label: { en: "Branding", ar: "الهوية والعلامة" } },
    { id: "growth", label: { en: "Growth", ar: "النمو" } },
    { id: "sales", label: { en: "Sales", ar: "المبيعات" } },
    { id: "seo", label: { en: "SEO", ar: "محرّكات البحث" } },
  ];

  // Professional corporate marketing & systems articles
  const articles: Article[] = [
    {
      id: "attribution-2026",
      category: "performance",
      categoryLabel: { en: "Performance", ar: "الأداء الرقمي" },
      title: { 
        en: "Server-Side Attribution: Overcoming the Cookie Apocalypse in Multi-Touch Funnels", 
        ar: "الإسناد من جانب الخادم: التغلب على فناء ملفات تعريف الارتباط في مسارات التحويل المتعددة" 
      },
      summary: {
        en: "Standard browser-side pixels are losing up to 40% of conversion data. Discover why first-party server-side tagging is no longer an option, but a structural requirement for scale.",
        ar: "تفقد وحدات البكسل التقليدية في المتصفح ما يصل إلى 40٪ من بيانات التحويل. تعرف على سبب أهمية التتبع من جانب الخادم (Server-Side) كمتطلب تشغيلي للتوسع الهائل للشركات."
      },
      content: {
        en: `In the modern landscape of digital acquisition, relying on standard browser-side pixel tracking is equivalent to flying blind. Privacy-focused browser policies (such as Apple's Safari ITP) and ad-blocking extensions systematically scrub third-party identifiers within hours. 

### The Under-Attribution Trap
When browser-side pixels fail to fire, your ad manager defaults to optimizing campaigns based on fragmented, incomplete user journeys. If Facebook or Google misses 30% of your checkout events, their machine-learning bidding algorithms automatically route budgets to suboptimal audience segments. You pay more for lower quality leads, assuming your market is saturated when the bottleneck is simply measurement error.

### The Architectural Remedy: 100% First-Party Tagging
By establishing a dedicated cloud container (e.g., via Google Cloud Platform or AWS) running Google Tag Manager Server-Side, you create a direct server-to-server gateway. 

1. **Custom Subdomain Control:** All telemetry is transmitted through a secure subdomain (e.g., collect.yourcompany.com) matching your parent domain. This designates all tracking events as strict first-party cookies.
2. **Server-Side Transformations:** Remove sensitive user properties before distributing metadata to secondary platforms, ensuring rigorous GDPR and HIPAA compliance.
3. **Data Loss Prevention:** Direct integrations with Meta's Conversions API (CAPI), Google Analytics 4 Measurement Protocol, and TikTok Events API restore complete visibility of offline sales, CRM transitions, and recurring client renewals.

Ultimately, brands that deploy robust server-side measurement engines acquire deep media buying leverage, enabling them to safely scale multi-million dollar budgets with zero blind spots.`,
        ar: `في المشهد المعاصر للاستحواذ الرقمي، فإن الاعتماد على تتبع البكسل التقليدي من جانب المتصفح يعادل قيادة الطائرة معصوب العينين. تعمل سياسات المتصفح التي تركز على الخصوصية (مثل ITP من Apple في متصفح Safari) وإضافات حظر الإعلانات على مسح معرفات الطرف الثالث بشكل منهجي خلال ساعات قليلة.

### فخ الإسناد المنقوص
عندما تفشل وحدات البكسل من جانب المتصفح في إرسال البيانات، فإن مدير الإعلانات يضطر تلقائياً إلى تحسين الحملات بناءً على رحلات مستخدمين مجزأة وغير مكتملة. إذا افتقد فيسبوك أو جوجل 30٪ من أحداث الشراء الخاصة بك، فإن خوارزميات المزايدة المعتمدة على التعلم الآلي ستقوم تلقائياً بتوجيه الميزانيات إلى فئات جمهور غير مناسبة. ستدفع تكلفة أكبر مقابل عملاء أقل جودة، وتفترض كذباً أن سوقك مشبع في حين أن المشكلة تكمن في خطأ قياس البيانات فحسب.

### الحل الهيكلي: تتبع داخلي معتمد بنسبة 100٪
من خلال تأسيس حاوية سحابية مخصصة (مثلاً عبر منصة Google Cloud أو AWS) لتشغيل برنامج Google Tag Manager من جانب الخادم (Server-Side)، فإنك تنشئ بوابة مباشرة من خادمك إلى خوادم المنصات الإعلانية.

1. **التحكم بالنطاق الفرعي المخصص:** يتم نقل كافة بيانات التتبع عبر نطاق فرعي آمن (مثل collect.yourcompany.com) يطابق نطاقك الرئيسي، مما يصنف جميع أحداث التتبع كملفات تعريف ارتباط تابعة للطرف الأول.
2. **تطهير البيانات السحابية:** إزالة معرّفات المستخدمين الحساسة قبل توزيع البيانات على المنصات الثانوية، مما يضمن الامتثال الصارم للخصوصية وقوانين حماية البيانات.
3. **منع فقدان البيانات:** التكامل المباشر مع واجهة برمجة تطبيقات التحويلات لميتا (CAPI)، وبروتوكول قياس Google Analytics 4، يعيد لك الرؤية الكاملة للمبيعات غير المتصلة بالإنترنت، وتحولات الـ CRM، والاشتراكات المتكررة.

في النهاية، تكتسب العلامات التجارية التي تنشر محركات قياس قوية من جانب الخادم رافعة تسويقية هائلة، مما يسمح لها بزيادة ميزانياتها الإعلانية المليونية بثقة تامة وبدون أي بقع عمياء.`
      },
      readTime: { en: "6 min read", ar: "6 دقائق للقراءة" },
      publishedAt: { en: "June 25, 2026", ar: "25 يونيو 2026" },
      imageUrl: "https://images.unsplash.com/photo-1551288049-bebda4e38f71?auto=format&fit=crop&w=800&q=80",
      accentColor: "from-teal-500/20 to-emerald-500/10",
      author: { en: "Mahmoud Gamal Akl", ar: "محمود جمال عقل" },
      featured: true
    },
    {
      id: "brand-moat",
      category: "branding",
      categoryLabel: { en: "Branding", ar: "الهوية والعلامة" },
      title: { 
        en: "Constructing the Unassailable Brand Moat: Beyond Visuals to Cognitive Pricing Leverage", 
        ar: "تأسيس خندق العلامة التجارية المنيع: أبعد من الأشكال البصرية إلى رافعة التسعير الإدراكية" 
      },
      summary: {
        en: "Aesthetic flourishes are not brand strategy. We dissect how enterprise institutions design emotional, systemic trust moats that make commoditized price competition entirely irrelevant.",
        ar: "الزخارف الجمالية ليست إستراتيجية علامة تجارية. نحن نحلل كيف تقوم المؤسسات بتصميم خنادق ثقة شعورية ونظامية تجعل المنافسة السعرية التقليدية عديمة الأهمية تماماً."
      },
      content: {
        en: `True brand equity is measured by one diagnostic variable: price inelasticity. If raising your product pricing by 20% results in a near-total loss of customer volume, you do not have a brand; you have a utility.

### The Fallacy of "Aesthetic Slop"
Many businesses treat branding as a cosmetics exercise—selecting beautiful serif fonts, hiring boutique agencies for minimal logo redesigns, or adding clever copywriting to their headers. This is a severe conceptual error. Aesthetics are a downstream vehicle. Your core brand identity is the systematic crystallization of authority, predictable delivery, and cognitive positioning.

### Designing the Structural Moat
1. **Systemic Trust Integration:** A premium brand behaves like an institution. It builds physical, digital, and structural frameworks that confirm absolute reliability.
2. **Authority and Category Hegemony:** Position your brand as the supreme arbiter of truth in your sector. Create deep, educational, and technical content repositories that establish your systems as the official industry standard.
3. **Premium Pricing Calibration:** Align your pricing with structural value rather than competitor baselines. High prices act as a cognitive filter, attracting committed enterprise clients and repelling low-margin customer segments.

When brand strategy transitions from aesthetic decoration to systemic leverage, customer retention stabilizes, and operational margins rise to unassailable heights.`,
        ar: `يتم قياس القيمة الحقيقية للعلامة التجارية بمتغير تشخيصي واحد: عدم مرونة السعر. إذا كان رفع أسعار منتجاتك بنسبة 20٪ يؤدي إلى خسارة شبه كاملة لحجم عملائك، فأنت لا تملك علامة تجارية؛ بل تملك خدمة عادية سريعة الاستبدال.

### مغالطة "الهزل الجمالي"
تتعامل العديد من الشركات مع بناء العلامة التجارية كعملية تجميلية—اختيار خطوط جميلة، أو توظيف وكالات كبرى لتصميم شعارات مبسطة، أو إضافة عبارات تسويقية ذكية للواجهة. هذا خطأ مفاهيمي جسيم. الجماليات هي وسيلة نقل نهائية ومرحلة متأخرة. الهوية الجوهرية لعلامتك التجارية هي التبلور المنهجي للسلطة ومصداقية الخدمة والتموضع الإدراكي في عقول عملائك.

### هندسة الخندق المنيع
1. **تكامل الثقة النظامية:** تتصرف العلامة التجارية الفاخرة مثل مؤسسة عريقة. إنها تبني هياكل مادية ورقمية تؤكد الموثوقية المطلقة وتجربتها الخالية من العيوب.
2. **سيادة الفئة والتخصص:** تموضع علامتك باعتبارها المرجع الأعلى للحقيقة في قطاعك. ابنِ سجلات معلوماتية فنية تعتمد كلياً كمعيار رسمي للصناعة.
3. **معايرة التسعير الفاخر:** اربط تسعيرك بالقيمة الهيكلية الكلية بدلاً من خطوط مقارنة المنافسين. يعمل السعر المرتفع كمرشح إدراكي يجتذب عملاء الشركات الملتزمين ويطرد فئات المشترين المرهقين تشغيلياً.

عندما تتحول إستراتيجية العلامة التجارية من مجرد تزيين للمظهر الخارجي إلى رافعة نظامية صلبة، يستقر تكرار عمليات الشراء وترتفع هوامش الربح التشغيلية إلى مستويات منيعة.`
      },
      readTime: { en: "5 min read", ar: "5 دقائق للقراءة" },
      publishedAt: { en: "June 20, 2026", ar: "20 يونيو 2026" },
      imageUrl: "https://images.unsplash.com/photo-1507679799987-c73779587ccf?auto=format&fit=crop&w=800&q=80",
      accentColor: "from-blue-500/20 to-indigo-500/10",
      author: { en: "Mahmoud Gamal Akl", ar: "محمود جمال عقل" }
    },
    {
      id: "seo-mechanics",
      category: "seo",
      categoryLabel: { en: "SEO", ar: "محرّكات البحث" },
      title: { 
        en: "Semantic SEO: Dominating Search intent Engines in the Era of Generative Search Overviews", 
        ar: "السيو الدلالي: الهيمنة على محركات البحث في عصر نتائج البحث المعتمدة على الذكاء الاصطناعي" 
      },
      summary: {
        en: "With AI overviews replacing standard organic links, traditional keyword stuffing is obsolete. Learn to structure semantically rich entity nodes to anchor your site in Google's knowledge graph.",
        ar: "مع استبدال روابط البحث التقليدية بملخصات الذكاء الاصطناعي (SGE)، أصبح حشو الكلمات المفتاحية بالياً. تعلم كيفية هيكلة كيانات معلوماتية دلالية قوية لتثبيت موقعك في مخطط معرفة جوجل."
      },
      content: {
        en: `The traditional SEO playbook is dead. The rise of Google's Search Generative Experience (SGE) and AI Answer Engines means searchers no longer need to click through ten blue links to get a definitive answer. 

### From Keywords to Entities
Artificial intelligence models do not read your pages like simple text matches. They index your site based on **Entity Relationships**—concepts, nouns, actions, and authorities. 

To remain viable in 2026, you must pivot from optimization based on isolated keywords to optimization based on complete topical coverage.

### Actionable Semantic SEO Playbook
1. **Structured Schema Deployments:** Implement rigorous JSON-LD schema markups. Explicitly state the relationship between your authors, your company entity, and the technical topics you publish.
2. **Technical Depth & Topical Authority:** Avoid shallow 500-word blog posts. Write extensive, structurally organized articles that resolve primary, secondary, and tertiary search intents in one comprehensive address.
3. **Entity Linking & Citation Integrity:** Cite authoritative medical, legal, or financial entities inside your articles. Link out to verified source databases to confirm your site is a reliable node of high-integrity information.

By shifting focus to high-fidelity topical architecture, you ensure your corporate knowledge base is indexed as the source material for Google's own generative summaries.`,
        ar: `لقد ماتت الإستراتيجيات التقليدية لتحسين محركات البحث (SEO). إن صعود ميزة تجربة البحث التوليدية من جوجل (SGE) ومحركات الإجابة بالذكاء الاصطناعي يعني أن الباحثين لم يعودوا بحاجة إلى النقر فوق عشرة روابط زرقاء للحصول على إجابة قاطعة.

### من الكلمات المفتاحية إلى الكيانات الدلالية
لا تقرأ نماذج الذكاء الاصطناعي صفحات موقعك كمجرد مطابقة نصية بسيطة للكلمات. بل تقوم بفهرسة موقعك بناءً على **علاقات الكيانات (Entity Relationships)**—أي المفاهيم، والأسماء، والإجراءات، والجهات المرجعية الموثوقة.

لتبقى متصدراً في عام 2026، يجب أن تحول تركيزك تماماً من الكلمات المفتاحية المعزولة إلى التغطية الموضوعية الشاملة والمتكاملة.

### دليل عملي للسيو الدلالي المتقدم
1. **تطوير مخطط بيانات منظم (Schema Markup):** قم ببرمجة هياكل JSON-LD صارمة ومفصلة لتعريف محركات البحث بالعلاقة المباشرة بين مؤلفيك، وكيان شركتك، والموضوعات الفنية المنشورة.
2. **العمق الفني والسيادة الموضوعية:** تجنب كتابة مقالات قصيرة وهزيلة من 500 كلمة. بدلاً من ذلك، اكتب أدلة فنية عميقة ومنظمة هيكلياً تعالج النوايا الأساسية والفرعية للبحث في صفحة واحدة متكاملة.
3. **الربط بالكيانات وموثوقية المراجع:** اقتبس من مراجع علمية، أو اقتصادية معتمدة داخل مقالاتك. اربط بقواعد بيانات المصادر الموثقة لتثبت لجوجل أن موقعك مصدر آمن للمعلومات عالية الدقة.

عبر تحويل تركيزك إلى معمارية الموضوعات عالية الجودة، فإنك تضمن فهرسة قاعدتك المعرفية وتدريسها كمادة خام لملخصات جوجل التوليدية ونماذج الذكاء الاصطناعي.`
      },
      readTime: { en: "7 min read", ar: "7 دقائق للقراءة" },
      publishedAt: { en: "June 18, 2026", ar: "18 يونيو 2026" },
      imageUrl: "https://images.unsplash.com/photo-1571721795195-a2ca2d33e402?auto=format&fit=crop&w=800&q=80",
      accentColor: "from-purple-500/20 to-pink-500/10",
      author: { en: "Mahmoud Gamal Akl", ar: "محمود جمال عقل" }
    },
    {
      id: "growth-math",
      category: "growth",
      categoryLabel: { en: "Growth Strategy", ar: "إستراتيجية النمو" },
      title: { 
        en: "The Arithmetic of Scale: Deconstructing CAC, LTV, and Payback Velocity for Venture Growth", 
        ar: "رياضيات التوسع: تفكيك تكلفة الاستحواذ والقيمة الدائمة وسرعة الاسترداد للنمو الإستراتيجي" 
      },
      summary: {
        en: "Growth is a game of pure engineering. We map the precise mathematical balance between customer acquisition costs and capital efficiency metrics required for fast sustainable growth.",
        ar: "النمو هو لعبة هندسة رياضية بحتة. نحن نخطط التوازن الرياضي الدقيق بين تكاليف الاستحواذ على العملاء ومقاييس كفاءة رأس المال اللازمة للنمو السريع والمستدام للشركات."
      },
      content: {
        en: `Too many growth consulting strategies are built on fluffy, unmeasurable parameters like 'going viral' or 'brand buzz'. Real business scale, however, is a game of cold arithmetic. 

If your mathematical unit economics do not yield a healthy ratio, adding marketing budget will simply accelerate your insolvency.

### The Sacred Acquisition Ratios
To engineer sustainable, non-venture-dependent growth, your marketing systems must align with three foundational mathematical rules:

1. **LTV:CAC Ratio > 3:1:** Your customer lifetime value must be at least three times the cost required to acquire that customer. Premium business architectures should target 4:1 or 5:1.
2. **Payback Period < 6 Months:** The time required to fully recoup your acquisition cash investment must remain under six months. Long payback periods trigger severe cash flow crunches, even if your LTV is theoretically high.
3. **Negative Churn Integration:** Build system mechanics that encourage expansion revenue—upsells, modular addons, and systemic integrations—that naturally outpace standard monthly customer cancellations.

### Engineering the Pipeline
Growth is achieved when you map your marketing funnels as a series of math conversion gates. Every pixel event, landing page drop-off, and sales pipeline stage is a conversion rate that can be measured, isolated, and systematically improved through rigorous A/B testing. Treat your acquisition funnels as a mechanical factory line; isolate the bottleneck, engineer the solution, and scale.`,
        ar: `تبنى العديد من استشارات النمو على معايير وهمية وغير قابلة للقياس مثل 'الانتشار الفيروسي' أو 'ضجيج العلامة التجارية'. ومع ذلك، فإن توسع الأعمال الحقيقي هو لعبة حسابات باردة ومحكمة.

إذا كانت حساباتك ومقاييسك الأساسية لا تحقق نسبة صحية، فإن إضافة ميزانية تسويقية سوف تسرع فحسب من إفلاسك وتدهور أرقامك.

### معدلات الاستحواذ المقدسة
لهندسة نمو مستدام، يجب أن تتوافق أنظمتك التسويقية مع ثلاثة قوانين رياضية أساسية:

1. **معدل القيمة الدائمة إلى كلفة الاستحواذ (LTV:CAC) أكبر من 3:1:** يجب أن تكون القيمة الدائمة التي يقدمها العميل ثلاثة أضعاف التكلفة المدفوعة لجذبه. تستهدف أنظمة الأعمال المتقدمة نسبة 4:1 أو 5:1.
2. **فترة استرداد كلفة الاستحواذ أقل من 6 أشهر:** الوقت اللازم لاسترداد الأموال المستثمرة في جذب العميل يجب أن يقل عن ستة أشهر. تؤدي فترات الاسترداد الطويلة لخلل حاد في التدفق النقدي، حتى لو كانت القيمة الدائمة مرتفعة نظرياً.
3. **تفعيل إيرادات التوسع الإيجابية:** تصميم آليات تشجع على زيادة الشراء والترقيات والخدمات الإضافية المدمجة التي تتجاوز بشكل طبيعي معدل إلغاء الاشتراكات الشهري المعتاد.

### هندسة مسار الاستحواذ
يتحقق النمو عندما ترسم مسارات التسويق كبوابات تحويل رياضية متتالية. كل حدث تتبع، وكل خروج من صفحة الهبوط، وكل مرحلة من مسار المبيعات هي معدل تحويل يمكن قياسه، وعزله، وتحسينه بشكل منهجي عبر اختبارات A/B الصارمة. تعامل مع مسار الاستحواذ كخط إنتاج آلي في مصنع؛ اعزل موضع الاختناق، وهندس الحل، ثم ضاعف الميزانية.`
      },
      readTime: { en: "6 min read", ar: "6 دقائق للقراءة" },
      publishedAt: { en: "June 12, 2026", ar: "12 يونيو 2026" },
      imageUrl: "https://images.unsplash.com/photo-1460925895917-afdab827c52f?auto=format&fit=crop&w=800&q=80",
      accentColor: "from-brand-orange/20 to-amber-500/10",
      author: { en: "Mahmoud Gamal Akl", ar: "محمود جمال عقل" }
    },
    {
      id: "sales-automation",
      category: "sales",
      categoryLabel: { en: "Sales Systems", ar: "أنظمة المبيعات" },
      title: { 
        en: "Systematizing Sales: Transitioning from Manual Hustle to High-Performance Pipeline Architecture", 
        ar: "أتمتة وهيكلة المبيعات: الانتقال من السعي العشوائي إلى معمارية مبيعات عالية الأداء" 
      },
      summary: {
        en: "Hiring more sales reps rarely fixes a broken pipeline. Discover how automating CRM triggers, custom estimators, and lead routing can multiply close rates while reducing manual friction.",
        ar: "نادراً ما يحل تعيين المزيد من ممثلي المبيعات مسار مبيعات تالف. اكتشف كيف يؤدي ربط مشغلات CRM التلقائية، وحواسب تقدير الأسعار، وتوزيع العملاء لتضاعف المبيعات بنصف الجهد والوقت."
      },
      content: {
        en: `Many founders believe that solving a sales bottleneck is simply a matter of hiring more sales representatives or motivating the existing team to 'work harder'. This is an expensive, low-leverage assumption. 

Sales is not a human motivation problem; it is a systemic workflow problem.

### The Broken Sales Funnel
If your sales pipeline is manual, key operational failures are guaranteed to occur:
- **Delayed Follow-ups:** Unqualified leads sit in your inbox for hours, losing up to 391% in conversion probability.
- **Inconsistent Pre-Qualification:** Sales reps waste expensive phone hours talking to leads who do not possess the required budget or authority.
- **Data Blindness:** CRMs are updated irregularly, preventing leadership from predicting next month's cash position.

### Automating the Sales Engine
By engineering automated, self-qualifying sales funnels, you eliminate manual friction points entirely:
1. **Interactive Pricing Calculators:** Integrate custom estimators on your landing pages. This filters out low-budget leads automatically while sending high-fidelity intent signals straight to your CRM.
2. **Automated Lead Routing & SLA Triggers:** Route incoming enterprise inquiries instantly based on industry size, and set tight automated triggers that alert reps to initiate outreach within 5 minutes.
3. **Automated Nurture Sequence Engines:** If a prospect drops off mid-negotiation, launch automated, highly tailored email workflows that deliver technical studies matching their industry domain.

When you transition your sales workflow from a human hustle to an engineered system, sales velocities double, and client onboarding becomes completely predictable.`,
        ar: `يعتقد الكثير من أصحاب الأعمال أن حل مشكلة المبيعات يتلخص ببساطة في تعيين المزيد من موظفي المبيعات أو تحفيز الفريق الحالي لبذل 'جهد أكبر'. هذا افتراض مكلف ومنخفض الأثر والمردود.

المبيعات ليست مشكلة تحفيز بشري؛ بل هي مشكلة تنظيمية في تدفق وهيكل العمل الإداري والتسويقي.

### مسار المبيعات التالف
إذا كان مسار مبيعاتك يعتمد على العمل اليدوي، فستحدث بالضرورة إخفاقات تشغيلية كبرى:
- **تأخر المتابعة:** تظل استفسارات العملاء في صندوق الوارد لساعات، مما يفقدك ما يصل إلى 391٪ من احتمالية تحويل العميل وحسم الصفقة لصالحك.
- **تصفية غير متناسقة للعملاء:** يهدر موظفو المبيعات ساعات طويلة في مكالمات مع عملاء ليس لديهم الميزانية أو الصلاحية اللازمة للشراء.
- **غياب تتبع البيانات الفعلي:** يتم تحديث أنظمة الـ CRM بشكل عشوائي وغير منتظم، مما يمنع الإدارة العليا من التنبؤ بدقة بحجم السيولة المتوقعة للشهر القادم.

### أتمتة وهيكلة محرك المبيعات
من خلال هندسة مسارات مبيعات ذاتية التأهيل ومؤتمتة بالكامل، يمكنك القضاء على عقبات العمل اليدوي:
1. **حواسب تقدير الأسعار التفاعلية:** ادمج حواسب تثمين مخصصة على صفحات الهبوط، مما يصفي تلقائياً العملاء ذوي الميزانيات الضعيفة، ويرسل إشارات رغبة عالية الجودة لنظام الـ CRM مباشرة.
2. **توزيع تلقائي للعملاء ومحددات الاستجابة السريعة:** قم بتوزيع العملاء فوراً بناءً على تخصص الشركة وحجمها، وفعل تنبيهات آلية للموظف للاتصال بالعميل المؤهل خلال 5 دقائق فقط.
3. **محركات المتابعة الآلية المخصصة:** إذا توقف عميل محتمل في منتصف المفاوضات، أطلق تتابعاً آلياً مخصصاً لرسائل بريدية ترسل دراسات حالة فنية متطابقة تماماً مع قطاعه ونطاق عمله.

عندما تحول مبيعاتك من سعي بشري عشوائي إلى نظام هندسي متكامل ومؤتمت، تتضاعف سرعة حسم الصفقات، وتصبح عمليات الاستحواذ قابلة للتوقع والتحجيم الكامل.`
      },
      readTime: { en: "5 min read", ar: "5 دقائق للقراءة" },
      publishedAt: { en: "June 05, 2026", ar: "5 يونيو 2026" },
      imageUrl: "https://images.unsplash.com/photo-1552581230-c01bc0d48403?auto=format&fit=crop&w=800&q=80",
      accentColor: "from-blue-500/20 to-teal-500/10",
      author: { en: "Mahmoud Gamal Akl", ar: "محمود جمال عقل" }
    }
  ];

  const labels = {
    en: {
      returnBtn: "Return to Core Profile",
      subHeader: "REUSABLE BLOG ARCHITECTURE // HIGH FIDELITY LITERACY",
      heading: "Executive Insights",
      headingAccent: "& Growth Intelligence",
      desc: "A rigorously researched library of strategic briefs, performance benchmarks, and engineered acquisition systems, ready for headless CMS integration.",
      searchPlaceholder: "Search insights, frameworks, or categories...",
      allCategories: "All Intel",
      featuredBadge: "FEATURED BRIEFING",
      readMoreBtn: "Access Full Briefing Document",
      closeBtn: "Close Briefing",
      byAuthor: "By",
      publishedLabel: "Released",
      shareBtn: "Copy Document Link",
      linkCopied: "Link Copied to Clipboard",
      searchNoResults: "No executive briefings match your active query. Try selecting another category domain.",
      
      // Sidebar newsletter Widget
      newsletterTitle: "Secure Insights Dispatch",
      newsletterDesc: "Receive secure, non-promotional technical briefs on first-party attribution, GTM containers, and performance marketing architecture directly in your corporate inbox.",
      newsletterPlaceholder: "executive@enterprise.com",
      newsletterSubmit: "Subscribe to Intel",
      newsletterSuccess: "Subscription Confirmed. Your address has been securely whitelisted.",
      newsletterAgreement: "Strict mutual confidentiality compliance. Zero promotional clutter or third-party sharing.",

      // Bottom Newsletter Section
      bottomNewsletterSub: "INTEL BRIEFINGS & TRANSMISSIONS",
      bottomNewsletterTitle: "Subscribe to the Executive Dispatch",
      bottomNewsletterTitleAccent: "Stay ahead of the curve.",
      bottomNewsletterDesc: "Receive exclusive technical and strategic analyses, architectural blueprints, and industry trends on performance branding directly in your inbox. No noise. Strictly business intelligence.",
      bottomNewsletterSubmit: "Join Dispatch List",

      cmsNoticeTitle: "HEADLESS CMS INTEGRATION BRIDGES ACTIVE",
      cmsNoticeDesc: "This architecture is constructed using a decoupled structured data model, completely prepared for seamless REST API or GraphQL synchronization with Storyblok, Sanity, or Strava systems."
    },
    ar: {
      returnBtn: "العودة للملف الأساسي",
      subHeader: "بنية مدونة ذكية وإعادة استخدام برمجية متكاملة",
      heading: "المرئيات التنفيذية",
      headingAccent: "وتقارير نمو الأعمال",
      desc: "مكتبة معتمدة ودقيقة من التقارير الإستراتيجية ومقاييس الأداء المرجعية وأنظمة الاستحواذ الهندسية المجهزة للربط البرمجي الكامل مع أنظمة إدارة المحتوى السحابية (Headless CMS).",
      searchPlaceholder: "ابحث في المرئيات، أو الأطر الإستراتيجية، أو التصنيفات الفنية...",
      allCategories: "كل التقارير",
      featuredBadge: "تقرير إستراتيجي رئيسي",
      readMoreBtn: "قراءة التقرير الفني بالكامل",
      closeBtn: "إغلاق التقرير",
      byAuthor: "بواسطة",
      publishedLabel: "تاريخ النشر",
      shareBtn: "نسخ رابط التقرير الآمن",
      linkCopied: "تم نسخ رابط التقرير للحافظة",
      searchNoResults: "لا توجد تقارير مطابقة لبحثك الحالي. يرجى تجربة اختيار تصنيف فني آخر.",

      // Sidebar newsletter Widget
      newsletterTitle: "قناة النشرات الفنية المباشرة",
      newsletterDesc: "اشترك للحصول على تقارير دورية آمنة وغير ترويجية حول التتبع الفني، وإدارة بيانات الخادم (GTM Server-side)، والتحويلات الرقمية مباشرة في بريدك العملي.",
      newsletterPlaceholder: "executive@enterprise.com",
      newsletterSubmit: "الاشتراك بقناة التقارير",
      newsletterSuccess: "تم تأكيد اشتراكك بنجاح. بريدك مسجل الآن على القائمة البيضاء المعتمدة لدينا.",
      newsletterAgreement: "امتثال تام لسرية البيانات والخصوصية. لا يوجد بريد عشوائي أو ترويج غير مصادق عليه.",

      // Bottom Newsletter Section
      bottomNewsletterSub: "النشرات والتحليلات الفنية المباشرة",
      bottomNewsletterTitle: "اشترك في النشرة التنفيذية الخاصة",
      bottomNewsletterTitleAccent: "كن دائماً في الصدارة الفنية.",
      bottomNewsletterDesc: "احصل على تحليلات فنية وإستراتيجية حصرية، ومخططات برمجية معمارية، وتوجهات السوق حول الأداء الرقمي مباشرة في بريدك. بدون فوضى ترويجية، معلومات مهنية فقط.",
      bottomNewsletterSubmit: "انضم لقناة النشرات",

      cmsNoticeTitle: "روابط ربط محتوى الـ CMS نشطة",
      cmsNoticeDesc: "تم بناء هذه المعمارية باستخدام نموذج بيانات هيكلية مستقلة، ومجهزة بالكامل للتزامن السلس عبر REST API أو GraphQL مع منصات Storyblok أو Sanity أو Strava."
    }
  };

  const l = locale === "ar" ? labels.ar : labels.en;

  // Filter & Search Logic
  const filteredArticles = useMemo(() => {
    return articles.filter(article => {
      const matchesCategory = activeCategory === "all" || article.category === activeCategory;
      const titleText = (locale === "ar" ? article.title.ar : article.title.en).toLowerCase();
      const summaryText = (locale === "ar" ? article.summary.ar : article.summary.en).toLowerCase();
      const contentText = (locale === "ar" ? article.content.ar : article.content.en).toLowerCase();
      const query = searchQuery.toLowerCase();
      const matchesSearch = titleText.includes(query) || summaryText.includes(query) || contentText.includes(query);
      return matchesCategory && matchesSearch;
    });
  }, [activeCategory, searchQuery, locale]);

  const handleShare = (id: string) => {
    const url = `${window.location.origin}${window.location.pathname}#/insights/${id}`;
    navigator.clipboard.writeText(url);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const handleSubscribe = (e: React.FormEvent) => {
    e.preventDefault();
    if (!subEmail) return;
    setSubStatus("success");
    setSubEmail("");
    setTimeout(() => setSubStatus("idle"), 5000);
  };

  const handleBottomSubscribe = (e: React.FormEvent) => {
    e.preventDefault();
    if (!bottomEmail) return;
    setBottomStatus("success");
    setBottomEmail("");
    setTimeout(() => setBottomStatus("idle"), 5000);
  };

  return (
    <div className="min-h-screen py-16 px-6 max-w-7xl mx-auto space-y-20 relative z-10">
      
      {/* Top Breadcrumb Navigation */}
      <div className="flex justify-between items-center pb-4 border-b border-onyx-200/40 dark:border-white/5">
        <a 
          href="#/" 
          className="inline-flex items-center gap-2 text-xs font-mono uppercase tracking-widest text-onyx-400 hover:text-brand-orange transition-colors group"
        >
          <ChevronLeft className="w-4 h-4 group-hover:-translate-x-1 transition-transform rtl:rotate-180" />
          <span>{l.returnBtn}</span>
        </a>
        <span className="font-mono text-[9px] uppercase tracking-widest text-onyx-300 dark:text-white/20">
          Executive Portfolio // Insights Repository
        </span>
      </div>

      {/* Hero Header */}
      <section className="space-y-8 max-w-4xl">
        <div className="space-y-3">
          <div className="flex items-center gap-3">
            <span className="w-1.5 h-1.5 bg-brand-orange rounded-full"></span>
            <span className="font-mono text-[10px] uppercase tracking-[0.35em] text-brand-orange font-bold">
              {l.subHeader}
            </span>
          </div>

          <h1 className="font-serif text-4xl sm:text-6xl md:text-[80px] leading-[0.95] font-light tracking-tighter text-onyx-950 dark:text-white">
            {l.heading}{" "}
            <span className="text-onyx-400 dark:text-white/30">
              {l.headingAccent}
            </span>
          </h1>
          
          <p className="font-sans text-lg text-onyx-600 dark:text-white/60 font-light leading-relaxed max-w-3xl">
            {l.desc}
          </p>
        </div>

        {/* CMS Ready/Integrity Notice */}
        <div className="p-4 rounded-2xl border border-brand-orange/20 bg-brand-orange/[0.02] inline-flex items-center gap-3 max-w-2xl text-xs text-brand-orange font-mono">
          <FileText className="w-4 h-4 shrink-0" />
          <span>This architecture utilizes decoupled props, perfectly prepared for Contentful, Sanity or Storyblok CMS API integration.</span>
        </div>
      </section>

      {/* Category Tabs & Interactive Search Bar */}
      <section className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-center border-y border-onyx-200/40 dark:border-white/5 py-6">
        
        {/* Category filtering buttons (7 columns) */}
        <div className="lg:col-span-8 flex flex-wrap gap-2">
          {categories.map(cat => (
            <button
              key={cat.id}
              onClick={() => {
                setActiveCategory(cat.id);
                // Clear search to avoid double filtration stress unless user actively wants to
              }}
              className={`px-3.5 py-1.5 rounded-xl text-[10px] sm:text-xs font-mono uppercase tracking-wider transition-all duration-300 border ${
                activeCategory === cat.id 
                  ? "bg-onyx-950 border-onyx-950 text-white dark:bg-white dark:border-white dark:text-onyx-950 font-bold shadow-sm" 
                  : "bg-transparent border-onyx-200/60 hover:border-brand-orange/40 text-onyx-600 dark:border-white/5 dark:text-white/60 hover:text-brand-orange dark:hover:text-brand-orange"
              }`}
            >
              {locale === "ar" ? cat.label.ar : cat.label.en}
            </button>
          ))}
        </div>

        {/* Active Search Field (4 columns) */}
        <div className="lg:col-span-4 relative">
          <div className="absolute inset-y-0 left-3.5 rtl:left-auto rtl:right-3.5 flex items-center pointer-events-none text-onyx-400 dark:text-white/30">
            <Search className="w-4 h-4" />
          </div>
          <input 
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder={l.searchPlaceholder}
            className="w-full pl-10 pr-4 rtl:pr-10 rtl:pl-4 py-2.5 rounded-xl border border-onyx-200/60 dark:border-white/10 bg-onyx-50/20 dark:bg-white/[0.01] text-onyx-900 dark:text-white focus:outline-none focus:border-brand-orange dark:focus:border-brand-orange text-xs font-mono transition-colors"
          />
        </div>

      </section>

      {/* Main Grid: Articles feed & Sidebar info widget */}
      <section className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start">
        
        {/* Left Column: List of articles (8 columns) */}
        <div className="lg:col-span-8 space-y-12">
          
          <AnimatePresence mode="popLayout">
            {filteredArticles.length === 0 ? (
              <motion.div 
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0 }}
                className="p-12 rounded-3xl border border-dashed border-onyx-250 dark:border-white/10 text-center space-y-4"
              >
                <div className="w-12 h-12 rounded-full bg-onyx-100/50 dark:bg-white/5 flex items-center justify-center mx-auto text-onyx-400">
                  <FileText className="w-5 h-5" />
                </div>
                <p className="text-sm font-sans text-onyx-500 dark:text-white/40 max-w-md mx-auto leading-relaxed">
                  {l.searchNoResults}
                </p>
              </motion.div>
            ) : (
              <div className="space-y-12">
                {filteredArticles.map((article, index) => {
                  return (
                    <motion.article 
                      key={article.id}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ duration: 0.4, delay: Math.min(index * 0.1, 0.4) }}
                      className="p-6 sm:p-10 rounded-3xl border border-onyx-200/60 dark:border-white/5 bg-white dark:bg-[#070707] hover:border-brand-orange/30 transition-all duration-300 relative group overflow-hidden"
                    >
                      
                      {/* Interactive subtle colored blur glow background */}
                      <div className={`absolute right-0 top-0 w-64 h-64 bg-gradient-to-bl ${article.accentColor} opacity-5 rounded-bl-full pointer-events-none transition-opacity duration-300 group-hover:opacity-10`} />

                      {/* Header row with categories & timestamps */}
                      <div className="flex flex-wrap items-center justify-between gap-4 pb-6 border-b border-onyx-100 dark:border-white/5 text-[10px] font-mono">
                        <div className="flex items-center gap-2">
                          <span className="font-bold text-brand-orange uppercase tracking-wider px-2.5 py-0.5 rounded-full bg-brand-orange/10">
                            {locale === "ar" ? article.categoryLabel.ar : article.categoryLabel.en}
                          </span>
                          {article.featured && (
                            <span className="inline-flex items-center gap-1 text-onyx-900 bg-onyx-100 dark:text-white dark:bg-white/10 px-2 py-0.5 rounded-full font-bold">
                              <Sparkles className="w-3 h-3 text-brand-orange" />
                              <span>{l.featuredBadge}</span>
                            </span>
                          )}
                        </div>

                        <div className="flex items-center gap-3 text-onyx-400 dark:text-white/30">
                          <span className="flex items-center gap-1">
                            <Clock className="w-3.5 h-3.5" />
                            <span>{locale === "ar" ? article.readTime.ar : article.readTime.en}</span>
                          </span>
                          <span>•</span>
                          <span className="flex items-center gap-1">
                            <Calendar className="w-3.5 h-3.5" />
                            <span>{locale === "ar" ? article.publishedAt.ar : article.publishedAt.en}</span>
                          </span>
                        </div>
                      </div>

                      {/* Title & Body split structure with an elegant Image Placeholder */}
                      <div className="grid grid-cols-1 md:grid-cols-12 gap-8 py-6 items-center">
                        
                        {/* High Fidelity Image Placeholder Column */}
                        <div className="md:col-span-4 aspect-video md:aspect-square rounded-2xl border border-onyx-200/60 dark:border-white/5 bg-onyx-100 dark:bg-[#0b0b0b] overflow-hidden relative group/img flex flex-col justify-between p-4">
                          
                          {/* Visual overlay gradient */}
                          <div className="absolute inset-0 bg-cover bg-center mix-blend-luminosity opacity-30 pointer-events-none transition-transform duration-700 group-hover/img:scale-110" style={{ backgroundImage: `url(${article.imageUrl})` }} />
                          <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent pointer-events-none" />

                          {/* Top Status */}
                          <div className="relative z-10 font-mono text-[8px] uppercase tracking-widest text-white/40">
                            DOC_REF // {article.id.substring(0, 8).toUpperCase()}
                          </div>

                          {/* Large decorative Category background mark */}
                          <div className="absolute inset-0 flex items-center justify-center opacity-[0.03] select-none text-[80px] font-serif font-bold text-white pointer-events-none">
                            {article.category.substring(0, 3).toUpperCase()}
                          </div>

                          {/* Bottom logo details */}
                          <div className="relative z-10 flex justify-between items-end">
                            <div className="p-1 rounded-lg bg-black/40 border border-white/5 flex items-center gap-1">
                              <Bookmark className="w-3.5 h-3.5 text-brand-orange" />
                              <span className="text-[8px] font-mono text-white/80 uppercase">VERIFIED INTEL</span>
                            </div>
                          </div>

                        </div>

                        {/* Title, author, and description content (8 columns) */}
                        <div className="md:col-span-8 space-y-4">
                          
                          <div className="space-y-1">
                            <h3 className="font-serif text-xl sm:text-2xl font-light text-onyx-950 dark:text-white leading-tight tracking-tight group-hover:text-brand-orange transition-colors">
                              {locale === "ar" ? article.title.ar : article.title.en}
                            </h3>
                            <div className="flex items-center gap-1 text-[11px] font-mono text-onyx-400 dark:text-white/30">
                              <span>{l.byAuthor}</span>
                              <span className="text-onyx-600 dark:text-white/55 font-medium">
                                {locale === "ar" ? article.author.ar : article.author.en}
                              </span>
                            </div>
                          </div>

                          <p className="font-sans text-xs sm:text-sm text-onyx-600 dark:text-white/60 font-light leading-relaxed">
                            {locale === "ar" ? article.summary.ar : article.summary.en}
                          </p>

                        </div>

                      </div>

                      {/* Actions / Read More & Copy Link Footer row */}
                      <div className="pt-6 border-t border-onyx-100 dark:border-white/5 flex items-center justify-between">
                        
                        <button
                          onClick={() => setSelectedArticle(article)}
                          className="inline-flex items-center gap-2 text-xs font-mono uppercase tracking-widest font-semibold text-brand-orange hover:text-onyx-950 dark:hover:text-white transition-colors"
                        >
                          <span>{l.readMoreBtn}</span>
                          <ArrowRight className="w-4 h-4 rtl:rotate-180 animate-pulse" />
                        </button>

                        <button
                          onClick={() => handleShare(article.id)}
                          className="inline-flex items-center gap-1.5 p-1.5 rounded-lg text-xs font-mono text-onyx-400 hover:text-brand-orange hover:bg-onyx-50 dark:hover:bg-white/5 transition-all"
                          title={l.shareBtn}
                        >
                          {copiedId === article.id ? (
                            <>
                              <Check className="w-3.5 h-3.5 text-brand-orange" />
                              <span className="text-[10px] text-brand-orange">{l.linkCopied}</span>
                            </>
                          ) : (
                            <>
                              <Share2 className="w-3.5 h-3.5" />
                              <span className="text-[10px]">{locale === "ar" ? "مشاركة" : "Share"}</span>
                            </>
                          )}
                        </button>

                      </div>

                    </motion.article>
                  );
                })}
              </div>
            )}
          </AnimatePresence>

        </div>

        {/* Right Column: Intelligent Sidebar Widgets (4 columns) */}
        <div className="lg:col-span-4 space-y-8">
          
          {/* Newsletter / Intel Subscription Box */}
          <div className="p-8 rounded-3xl border border-brand-orange/20 bg-brand-orange/[0.01] space-y-6 relative overflow-hidden">
            <div className="absolute right-0 top-0 w-32 h-32 bg-gradient-to-bl from-brand-orange/10 to-transparent rounded-bl-full pointer-events-none" />
            
            <div className="space-y-2">
              <div className="flex items-center gap-2 text-brand-orange font-mono text-[10px] font-bold uppercase tracking-wider">
                <Flame className="w-4 h-4 text-brand-orange animate-pulse" />
                <span>{l.newsletterTitle}</span>
              </div>
              <h3 className="font-serif text-lg sm:text-xl font-light text-onyx-950 dark:text-white tracking-tight">
                {locale === "ar" ? "قناة البيانات الفنية المغلقة" : "The Core Intel Dispatch"}
              </h3>
              <p className="text-xs text-onyx-600 dark:text-white/60 leading-relaxed font-light">
                {l.newsletterDesc}
              </p>
            </div>

            {subStatus === "success" ? (
              <motion.div 
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className="p-4 rounded-xl border border-brand-orange/20 bg-brand-orange/[0.03] space-y-2"
              >
                <div className="flex items-center gap-2 text-xs font-mono text-brand-orange font-bold">
                  <CheckCircle2 className="w-4 h-4" />
                  <span>{l.newsletterSuccess}</span>
                </div>
              </motion.div>
            ) : (
              <form onSubmit={handleSubscribe} className="space-y-3">
                <div className="relative">
                  <div className="absolute inset-y-0 left-3.5 rtl:left-auto rtl:right-3.5 flex items-center pointer-events-none text-onyx-400">
                    <Mail className="w-4 h-4" />
                  </div>
                  <input 
                    type="email"
                    required
                    value={subEmail}
                    onChange={(e) => setSubEmail(e.target.value)}
                    placeholder={l.newsletterPlaceholder}
                    className="w-full pl-10 pr-4 rtl:pr-10 rtl:pl-4 py-3 rounded-xl border border-onyx-200 dark:border-white/10 bg-white dark:bg-black/40 text-onyx-900 dark:text-white text-xs font-mono focus:outline-none focus:border-brand-orange"
                  />
                </div>

                <button
                  type="submit"
                  className="w-full inline-flex items-center justify-center gap-2 py-3 rounded-xl bg-onyx-950 text-white dark:bg-white dark:text-onyx-950 hover:bg-brand-orange dark:hover:bg-brand-orange hover:text-white dark:hover:text-white transition-all text-xs font-mono uppercase tracking-widest font-bold"
                >
                  <span>{l.newsletterSubmit}</span>
                </button>
              </form>
            )}

            <div className="pt-2 border-t border-brand-orange/10 text-[9px] font-mono text-onyx-400 dark:text-white/25 leading-normal">
              {l.newsletterAgreement}
            </div>
          </div>

          {/* Technical Architecture Notice */}
          <div className="p-6 rounded-3xl border border-onyx-200/60 dark:border-white/5 bg-onyx-50/20 dark:bg-white/[0.003] space-y-4">
            <div className="flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-brand-orange" />
              <span className="font-mono text-[9px] uppercase tracking-widest font-bold text-onyx-900 dark:text-white">
                CMS INTEGRATION MATRIX
              </span>
            </div>

            <p className="text-[11px] text-onyx-500 dark:text-white/50 leading-relaxed font-mono">
              {l.cmsNoticeDesc}
            </p>

            <div className="pt-2 border-t border-onyx-100 dark:border-white/5 flex items-center justify-between text-[8px] font-mono text-onyx-400 dark:text-white/20">
              <span>STATUS: REST_COMPLIANT</span>
              <span>API PROT: active</span>
            </div>
          </div>

        </div>

      </section>

      {/* Immersive interactive modal to view full article (Read More trigger) */}
      <AnimatePresence>
        {selectedArticle && (
          <div className="fixed inset-0 z-50 overflow-y-auto flex items-center justify-center p-4 sm:p-6 md:p-10">
            {/* Dark blur backdrop */}
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setSelectedArticle(null)}
              className="fixed inset-0 bg-black/80 backdrop-blur-md cursor-zoom-out"
            />

            {/* Modal Body */}
            <motion.div 
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              className="relative w-full max-w-4xl max-h-[85vh] overflow-y-auto rounded-3xl bg-white dark:bg-[#080808] border border-onyx-200/60 dark:border-white/10 p-6 sm:p-12 z-10 space-y-8 shadow-2xl"
              dir={dir}
            >
              
              {/* Back breadcrumb inside modal */}
              <div className="flex items-center justify-between pb-4 border-b border-onyx-100 dark:border-white/5">
                <button
                  onClick={() => setSelectedArticle(null)}
                  className="inline-flex items-center gap-2 text-xs font-mono uppercase tracking-widest text-onyx-400 hover:text-brand-orange transition-colors"
                >
                  <ChevronLeft className="w-4 h-4 rtl:rotate-180" />
                  <span>{l.closeBtn}</span>
                </button>
                <span className="font-mono text-[9px] uppercase tracking-widest text-onyx-300 dark:text-white/20">
                  SYSTEM DOC // {selectedArticle.id.toUpperCase()}
                </span>
              </div>

              {/* Category and times */}
              <div className="flex flex-wrap items-center gap-3 text-[10px] font-mono">
                <span className="font-bold text-brand-orange uppercase tracking-wider px-2.5 py-0.5 rounded-full bg-brand-orange/10">
                  {locale === "ar" ? selectedArticle.categoryLabel.ar : selectedArticle.categoryLabel.en}
                </span>
                <span className="text-onyx-400 dark:text-white/30">•</span>
                <span className="text-onyx-400 dark:text-white/30">{locale === "ar" ? selectedArticle.readTime.ar : selectedArticle.readTime.en}</span>
                <span className="text-onyx-400 dark:text-white/30">•</span>
                <span className="text-onyx-400 dark:text-white/30">{locale === "ar" ? selectedArticle.publishedAt.ar : selectedArticle.publishedAt.en}</span>
              </div>

              {/* Title & Header */}
              <div className="space-y-3">
                <h2 className="font-serif text-3xl sm:text-5xl font-light text-onyx-950 dark:text-white leading-tight tracking-tight">
                  {locale === "ar" ? selectedArticle.title.ar : selectedArticle.title.en}
                </h2>
                
                <div className="flex items-center gap-2 text-xs font-mono text-onyx-400 dark:text-white/40">
                  <span>{l.byAuthor}</span>
                  <span className="text-onyx-600 dark:text-white/60 font-semibold">
                    {locale === "ar" ? selectedArticle.author.ar : selectedArticle.author.en}
                  </span>
                </div>
              </div>

              {/* Big High Fidelity Header Image placeholder */}
              <div className="h-48 sm:h-80 w-full rounded-2xl border border-onyx-200/60 dark:border-white/5 bg-onyx-100 dark:bg-[#0b0b0b] overflow-hidden relative">
                <div className="absolute inset-0 bg-cover bg-center mix-blend-luminosity opacity-40" style={{ backgroundImage: `url(${selectedArticle.imageUrl})` }} />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent" />
                <div className="absolute bottom-6 left-6 font-mono text-xs text-white/60 uppercase tracking-widest">
                  verified operational publication // mahmoud gamal akl
                </div>
              </div>

              {/* Main Content Body render with formatted custom paragraphs */}
              <div className="prose prose-onyx dark:prose-invert max-w-none text-sm sm:text-base text-onyx-700 dark:text-white/80 font-light leading-relaxed space-y-6">
                {(locale === "ar" ? selectedArticle.content.ar : selectedArticle.content.en)
                  .split("\n\n")
                  .map((paragraph, pIdx) => {
                    // Check if it's a section header
                    if (paragraph.startsWith("### ")) {
                      return (
                        <h3 key={pIdx} className="font-serif text-lg sm:text-xl font-semibold text-brand-orange pt-4">
                          {paragraph.replace("### ", "")}
                        </h3>
                      );
                    }
                    // Check if it's a list item
                    if (paragraph.match(/^\d+\.\s/)) {
                      return (
                        <div key={pIdx} className="pl-4 rtl:pl-0 rtl:pr-4 py-1.5 border-l-2 border-brand-orange/40 dark:border-brand-orange/20 my-2 text-xs sm:text-sm font-sans text-onyx-600 dark:text-white/60 space-y-1">
                          {paragraph}
                        </div>
                      );
                    }
                    return (
                      <p key={pIdx} className="font-sans text-xs sm:text-sm leading-relaxed text-onyx-600 dark:text-white/70">
                        {paragraph}
                      </p>
                    );
                  })}
              </div>

              {/* Modal footer controls */}
              <div className="pt-8 border-t border-onyx-100 dark:border-white/5 flex flex-wrap gap-4 items-center justify-between">
                
                <button
                  onClick={() => setSelectedArticle(null)}
                  className="px-6 py-3 rounded-full bg-onyx-950 text-white dark:bg-white dark:text-onyx-950 hover:bg-brand-orange dark:hover:bg-brand-orange hover:text-white dark:hover:text-white text-xs font-mono uppercase tracking-wider font-semibold transition-all duration-300"
                >
                  {l.closeBtn}
                </button>

                <button
                  onClick={() => handleShare(selectedArticle.id)}
                  className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-onyx-100 hover:bg-brand-orange/10 dark:bg-white/5 dark:hover:bg-brand-orange/10 text-xs font-mono text-onyx-600 dark:text-white/60 hover:text-brand-orange dark:hover:text-brand-orange transition-colors border border-onyx-200/40 dark:border-white/5"
                >
                  {copiedId === selectedArticle.id ? (
                    <>
                      <Check className="w-3.5 h-3.5" />
                      <span>{l.linkCopied}</span>
                    </>
                  ) : (
                    <>
                      <Share2 className="w-3.5 h-3.5" />
                      <span>{l.shareBtn}</span>
                    </>
                  )}
                </button>

              </div>

            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Subtle, minimalist newsletter signup section */}
      <section className="pt-20 pb-12 border-t border-onyx-200/40 dark:border-white/5">
        <div className="relative max-w-4xl mx-auto rounded-3xl border border-onyx-200/40 dark:border-white/5 bg-onyx-50/20 dark:bg-white/[0.005] p-8 sm:p-12 overflow-hidden">
          {/* Ambient decorative glow background */}
          <div className="absolute top-0 right-0 w-[300px] h-[300px] bg-brand-orange/5 rounded-full blur-[80px] pointer-events-none translate-x-1/4 -translate-y-1/4" />
          
          <div className="relative z-10 max-w-2xl mx-auto text-center space-y-6">
            <div className="space-y-2">
              <div className="flex items-center justify-center gap-2 text-brand-orange font-mono text-[9px] font-bold uppercase tracking-[0.25em]">
                <span className="w-1.5 h-1.5 bg-brand-orange rounded-full animate-pulse" />
                <span>{l.bottomNewsletterSub}</span>
              </div>
              <h2 className="font-serif text-2xl sm:text-4xl font-light text-onyx-950 dark:text-white leading-tight tracking-tight">
                {l.bottomNewsletterTitle}{" "}
                <span className="text-onyx-400 dark:text-white/30 font-sans italic font-normal text-xl sm:text-3xl block sm:inline">
                  {l.bottomNewsletterTitleAccent}
                </span>
              </h2>
              <p className="font-sans text-xs sm:text-sm text-onyx-600 dark:text-white/60 font-light leading-relaxed max-w-lg mx-auto">
                {l.bottomNewsletterDesc}
              </p>
            </div>

            {bottomStatus === "success" ? (
              <motion.div
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                className="p-4 rounded-2xl border border-brand-orange/30 bg-brand-orange/[0.03] inline-flex items-center gap-3 text-xs font-mono text-brand-orange"
              >
                <CheckCircle2 className="w-4 h-4 shrink-0 text-brand-orange" />
                <span>{l.newsletterSuccess}</span>
              </motion.div>
            ) : (
              <form onSubmit={handleBottomSubscribe} className="flex flex-col sm:flex-row gap-3 max-w-md mx-auto items-stretch">
                <div className="relative flex-1">
                  <div className="absolute inset-y-0 left-3.5 rtl:left-auto rtl:right-3.5 flex items-center pointer-events-none text-onyx-400 dark:text-white/30">
                    <Mail className="w-4 h-4" />
                  </div>
                  <input
                    type="email"
                    required
                    value={bottomEmail}
                    onChange={(e) => setBottomEmail(e.target.value)}
                    placeholder={l.newsletterPlaceholder}
                    className="w-full pl-10 pr-4 rtl:pr-10 rtl:pl-4 py-3 rounded-full border border-onyx-200/60 dark:border-white/10 bg-white/50 dark:bg-black/20 text-onyx-900 dark:text-white text-xs font-mono focus:outline-none focus:border-brand-orange transition-colors"
                  />
                </div>
                <button
                  type="submit"
                  className="px-6 py-3 rounded-full bg-onyx-950 text-white dark:bg-white dark:text-onyx-950 hover:bg-brand-orange dark:hover:bg-brand-orange hover:text-white dark:hover:text-white transition-all text-xs font-mono uppercase tracking-widest font-bold whitespace-nowrap cursor-pointer"
                >
                  <span>{l.bottomNewsletterSubmit}</span>
                </button>
              </form>
            )}

            <p className="text-[9px] font-mono text-onyx-400 dark:text-white/20 max-w-md mx-auto leading-normal">
              {l.newsletterAgreement}
            </p>
          </div>
        </div>
      </section>

      {/* Trust Signoff footer */}
      <section className="pt-16 border-t border-onyx-200/40 dark:border-white/5 text-center space-y-4">
        <p className="text-[10px] font-mono text-onyx-400 dark:text-white/20 uppercase tracking-[0.2em]">
          DATA SYNDICATION PROTOCOLS // REST FULLY RESOLVED
        </p>
      </section>

    </div>
  );
}
