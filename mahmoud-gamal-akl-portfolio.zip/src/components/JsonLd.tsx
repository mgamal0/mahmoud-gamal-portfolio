import { useEffect } from "react";
import { getPersonSchema, getBreadcrumbSchema } from "../lib/metadata";
import { useLanguage } from "./LanguageContext";

export default function JsonLd() {
  const { locale } = useLanguage();

  useEffect(() => {
    // 1. Person Schema Setup
    let personScript = document.getElementById("person-jsonld") as HTMLScriptElement;
    if (!personScript) {
      personScript = document.createElement("script");
      personScript.id = "person-jsonld";
      personScript.type = "application/ld+json";
      document.head.appendChild(personScript);
    }
    personScript.innerHTML = JSON.stringify(getPersonSchema(), null, 2);

    // 2. Breadcrumbs Schema Setup & Update on Hash/Language changes
    const updateBreadcrumbs = () => {
      let breadcrumbScript = document.getElementById("breadcrumb-jsonld") as HTMLScriptElement;
      if (!breadcrumbScript) {
        breadcrumbScript = document.createElement("script");
        breadcrumbScript.id = "breadcrumb-jsonld";
        breadcrumbScript.type = "application/ld+json";
        document.head.appendChild(breadcrumbScript);
      }
      breadcrumbScript.innerHTML = JSON.stringify(
        getBreadcrumbSchema(window.location.hash || "#/", locale),
        null,
        2
      );
    };

    // Initial breadcrumbs sync
    updateBreadcrumbs();

    // Listen to hash change for real-time Breadcrumb updating
    window.addEventListener("hashchange", updateBreadcrumbs);

    return () => {
      window.removeEventListener("hashchange", updateBreadcrumbs);
    };
  }, [locale]);

  return null;
}
