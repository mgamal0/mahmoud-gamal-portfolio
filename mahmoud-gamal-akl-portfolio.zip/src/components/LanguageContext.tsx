import React, { createContext, useContext, useEffect, useState } from "react";
import en from "../messages/en.json";
import ar from "../messages/ar.json";

export type Locale = "en" | "ar";

type Dictionary = typeof en;

const dictionaries: Record<Locale, Dictionary> = {
  en,
  ar,
};

interface LanguageContextType {
  locale: Locale;
  setLocale: (locale: Locale) => void;
  t: (key: string) => string;
  dir: "ltr" | "rtl";
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

export function LanguageProvider({ children }: { children: React.ReactNode }) {
  const [locale, setLocaleState] = useState<Locale>(() => {
    if (typeof window !== "undefined") {
      const saved = localStorage.getItem("portfolio-locale") as Locale;
      return saved || "en";
    }
    return "en";
  });

  const setLocale = (newLocale: Locale) => {
    setLocaleState(newLocale);
    localStorage.setItem("portfolio-locale", newLocale);
  };

  const dir = locale === "ar" ? "rtl" : "ltr";

  useEffect(() => {
    // Update document attributes dynamically for full accessibility
    document.documentElement.lang = locale;
    document.documentElement.dir = dir;
    
    // Set appropriate fonts based on script direction
    const root = document.body;
    if (locale === "ar") {
      root.style.fontFamily = '"Inter", system-ui, -apple-system, sans-serif';
    } else {
      root.style.fontFamily = 'var(--font-sans)';
    }
  }, [locale, dir]);

  // Translate function that supports nested dot notation, e.g. "showcase.title"
  const t = (path: string): string => {
    const dictionary = dictionaries[locale];
    const keys = path.split(".");
    
    let result: any = dictionary;
    for (const key of keys) {
      if (result && Object.prototype.hasOwnProperty.call(result, key)) {
        result = result[key];
      } else {
        return path; // Fallback to key path if translation is missing
      }
    }
    
    return typeof result === "string" ? result : path;
  };

  return (
    <LanguageContext.Provider value={{ locale, setLocale, t, dir }}>
      {children}
    </LanguageContext.Provider>
  );
}

export function useLanguage() {
  const context = useContext(LanguageContext);
  if (!context) {
    throw new Error("useLanguage must be used within a LanguageProvider");
  }
  return context;
}
