import { motion } from "motion/react";
import { useLanguage, Locale } from "./LanguageContext";
import { Languages } from "lucide-react";

export default function LanguageSwitch() {
  const { locale, setLocale, t } = useLanguage();

  const locales: { value: Locale; label: string }[] = [
    { value: "en", label: "EN" },
    { value: "ar", label: "عربي" },
  ];

  return (
    <div 
      id="language-switcher-container"
      className="inline-flex p-0.5 rounded-full border border-onyx-200/60 bg-onyx-100/50 dark:border-onyx-800/80 dark:bg-onyx-900/40 font-mono text-[10px] font-medium tracking-wider"
    >
      {locales.map((loc) => {
        const isActive = locale === loc.value;
        return (
          <button
            key={loc.value}
            id={`lang-btn-${loc.value}`}
            onClick={() => setLocale(loc.value)}
            className="relative flex items-center justify-center px-2.5 py-1 rounded-full text-onyx-500 hover:text-onyx-900 dark:hover:text-onyx-50 transition-colors focus:outline-none"
            title={t(`lang.${loc.value}`)}
            aria-label={t(`lang.${loc.value}`)}
          >
            {isActive && (
              <motion.span
                layoutId="activeLangBg"
                className="absolute inset-0 rounded-full bg-white dark:bg-onyx-800 shadow-sm"
                transition={{ type: "spring", stiffness: 380, damping: 30 }}
              />
            )}
            <span className="relative z-10">{loc.label}</span>
          </button>
        );
      })}
    </div>
  );
}
