import React from "react";
import { motion } from "motion/react";

interface LoadingPageProps {
  fullScreen?: boolean;
}

export default function LoadingPage({ fullScreen = true }: LoadingPageProps) {
  return (
    <div 
      id="loading-page"
      className={`${
        fullScreen ? "fixed inset-0 z-[100] bg-onyx-50 dark:bg-[#050505]" : "w-full h-[400px]"
      } flex flex-col items-center justify-center`}
    >
      <div className="relative flex flex-col items-center space-y-6">
        {/* Architectural Geometry Pulse */}
        <div className="relative w-16 h-16 flex items-center justify-center">
          <motion.div 
            animate={{ rotate: 360 }}
            transition={{ repeat: Infinity, duration: 4, ease: "linear" }}
            className="absolute inset-0 border border-brand-orange/40 rounded-sm"
          />
          <motion.div 
            animate={{ rotate: -360 }}
            transition={{ repeat: Infinity, duration: 3, ease: "linear" }}
            className="absolute inset-2 border border-dashed border-onyx-300 dark:border-white/10 rounded-full"
          />
          <span className="font-serif text-sm font-medium tracking-widest text-brand-orange">
            M
          </span>
        </div>

        {/* Minimal Progress Line */}
        <div className="w-24 h-[1px] bg-onyx-200 dark:bg-white/10 overflow-hidden relative rounded-full">
          <motion.div 
            initial={{ left: "-100%" }}
            animate={{ left: "100%" }}
            transition={{ repeat: Infinity, duration: 1.5, ease: "easeInOut" }}
            className="absolute top-0 bottom-0 w-1/2 bg-brand-orange"
          />
        </div>

        <span className="text-[10px] font-mono uppercase tracking-widest text-onyx-400 dark:text-white/30 animate-pulse">
          INITIALIZING CANVAS
        </span>
      </div>
    </div>
  );
}
