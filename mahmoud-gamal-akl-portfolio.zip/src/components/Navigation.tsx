import { useState } from "react";
import { useLanguage } from "./LanguageContext";
import { portfolioData } from "../data/portfolio";
import ThemeSwitch from "./ThemeSwitch";
import LanguageSwitch from "./LanguageSwitch";
import { ArrowUpRight, Menu, X } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

export default function Navigation() {
  const { t, locale, dir } = useLanguage();
  const [isOpen, setIsOpen] = useState(false);

  const handleToggle = () => setIsOpen(!isOpen);
  const handleClose = () => setIsOpen(false);

  return (
    <nav
      id="main-navigation"
      className="sticky top-0 z-50 w-full border-b border-onyx-200/40 bg-onyx-50/60 luxury-blur dark:border-white/5 dark:bg-[#050505]/60 transition-colors duration-500"
    >
      <div className="max-w-7xl mx-auto px-6 h-16 flex items-center justify-between">
        {/* Monogram / Logo */}
        <a
          id="logo-brand"
          href="#"
          onClick={handleClose}
          className="font-serif font-semibold text-lg tracking-tight hover:opacity-80 transition-opacity flex items-center gap-2"
        >
          <span className="text-brand-orange select-none font-sans font-light">M·G·A</span>
          <span className="hidden sm:inline-block text-xs font-mono font-light tracking-widest text-onyx-400 dark:text-onyx-600">
            {locale === "ar" ? "استراتيجي نمو" : "GROWTH STRATEGIST"}
          </span>
        </a>

        {/* Links (Desktop) */}
        <div id="nav-links" className="hidden md:flex items-center gap-8 text-xs font-medium tracking-wider uppercase text-onyx-600 dark:text-onyx-400">
          {portfolioData.navigation.map((item) => (
            <a
              key={item.key}
              id={`nav-link-${item.key}`}
              href={item.path}
              className="hover:text-onyx-950 dark:hover:text-white transition-colors relative py-1 group"
            >
              {locale === "ar" ? item.label.ar : item.label.en}
              <span className="absolute bottom-0 left-0 w-0 h-[1px] bg-brand-orange transition-all duration-300 group-hover:w-full" />
            </a>
          ))}
        </div>

        {/* System Controls */}
        <div id="nav-controls" className="flex items-center gap-3 sm:gap-4">
          <LanguageSwitch />
          <span className="w-[1px] h-4 bg-onyx-200 dark:bg-onyx-800" />
          <ThemeSwitch />
          
          <a
            id="nav-cta-contact"
            href="#/contact"
            className="hidden sm:inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-full bg-onyx-950 text-white dark:bg-white dark:text-onyx-950 text-[11px] font-mono uppercase tracking-wider font-medium hover:bg-brand-orange dark:hover:bg-brand-orange hover:text-white dark:hover:text-white transition-all duration-350"
          >
            <span>{t("nav.contact")}</span>
            <ArrowUpRight className="w-3 h-3" />
          </a>

          {/* Hamburger Menu Toggle */}
          <button
            id="mobile-nav-toggle"
            onClick={handleToggle}
            className="p-1.5 rounded-lg border border-onyx-200/40 text-onyx-600 dark:border-white/5 dark:text-onyx-400 md:hidden hover:text-brand-orange hover:border-brand-orange/40 transition-colors cursor-pointer"
            aria-label={isOpen ? "Close navigation menu" : "Open navigation menu"}
          >
            {isOpen ? <X className="w-4 h-4" /> : <Menu className="w-4 h-4" />}
          </button>
        </div>
      </div>

      {/* Mobile Drawer */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            id="mobile-drawer"
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            transition={{ duration: 0.3, ease: [0.16, 1, 0.3, 1] }}
            className="w-full bg-onyx-50 dark:bg-[#080808] border-b border-onyx-200/40 dark:border-white/5 md:hidden overflow-hidden"
          >
            <div className="px-6 py-6 flex flex-col gap-4 text-xs font-mono tracking-widest uppercase text-onyx-600 dark:text-onyx-400">
              {portfolioData.navigation.map((item, index) => (
                <motion.a
                  key={item.key}
                  id={`mobile-nav-link-${item.key}`}
                  href={item.path}
                  onClick={handleClose}
                  initial={{ opacity: 0, x: -10 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: index * 0.05 }}
                  className="py-2.5 hover:text-brand-orange border-b border-onyx-100 dark:border-white/5 last:border-0 transition-colors flex items-center justify-between"
                >
                  <span>{locale === "ar" ? item.label.ar : item.label.en}</span>
                  <ArrowUpRight className="w-3 h-3 opacity-40 text-brand-orange" />
                </motion.a>
              ))}

              <a
                id="mobile-nav-cta"
                href="#/contact"
                onClick={handleClose}
                className="mt-2 w-full text-center py-3 rounded-full bg-onyx-950 text-white dark:bg-white dark:text-onyx-950 hover:bg-brand-orange dark:hover:bg-brand-orange hover:text-white dark:hover:text-white font-mono text-xs uppercase tracking-widest transition-all duration-300"
              >
                {t("nav.contact")}
              </a>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </nav>
  );
}
