import React from "react";
import { useLanguage } from "./LanguageContext";
import { motion } from "motion/react";
import { ArrowLeft, ArrowRight, Compass } from "lucide-react";

export default function NotFoundView() {
  const { locale } = useLanguage();

  const content = {
    en: {
      code: "404",
      title: "Page Not Found",
      subtitle: "Structural Anomaly",
      desc: "The digital asset or architectural blueprint you are searching for does not exist, has been archived, or has been permanently relocated.",
      btnText: "Return to Main Canvas"
    },
    ar: {
      code: "٤٠٤",
      title: "الصفحة غير موجودة",
      subtitle: "خلل في الهيكل الرقمي",
      desc: "المرجع الرقمي أو المخطط المعماري الذي تبحث عنه غير موجود، أو تم أرشفته، أو نقله بشكل دائم.",
      btnText: "العودة إلى اللوحة الرئيسية"
    }
  };

  const current = content[locale] || content.en;

  const handleGoHome = () => {
    window.location.hash = "#/";
  };

  return (
    <div 
      id="not-found-view"
      className="min-h-[80vh] flex flex-col items-center justify-center px-6 py-20 text-center relative overflow-hidden"
    >
      {/* Abstract Architectural Background Grid Accent */}
      <div className="absolute inset-0 opacity-5 pointer-events-none flex items-center justify-center">
        <div className="w-[500px] h-[500px] border border-onyx-950 dark:border-white rounded-full flex items-center justify-center">
          <div className="w-[350px] h-[350px] border border-dashed border-onyx-950 dark:border-white rounded-full flex items-center justify-center">
            <div className="w-[200px] h-[200px] border border-onyx-950 dark:border-white rounded-full"></div>
          </div>
        </div>
      </div>

      <motion.div 
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
        className="max-w-xl space-y-8 relative z-10"
      >
        <div className="flex justify-center">
          <div className="p-4 rounded-full bg-brand-orange/5 border border-brand-orange/20 text-brand-orange animate-pulse">
            <Compass className="w-8 h-8" />
          </div>
        </div>

        <div className="space-y-3">
          <span className="text-xs font-mono uppercase tracking-widest text-brand-orange">
            {current.subtitle}
          </span>
          <h1 className="font-serif text-8xl md:text-[120px] font-extralight tracking-tighter text-onyx-950 dark:text-white leading-none">
            {current.code}
          </h1>
          <h2 className="text-2xl font-light text-onyx-800 dark:text-white/80 tracking-tight">
            {current.title}
          </h2>
        </div>

        <p className="text-sm md:text-base text-onyx-500 dark:text-white/50 leading-relaxed max-w-md mx-auto">
          {current.desc}
        </p>

        <div className="pt-4">
          <button
            id="back-to-home-btn"
            onClick={handleGoHome}
            className="inline-flex items-center gap-2 px-6 py-3 rounded-full text-xs font-mono uppercase tracking-wider text-white bg-onyx-950 hover:bg-brand-orange dark:bg-white dark:text-onyx-950 dark:hover:bg-brand-orange dark:hover:text-white transition-all duration-300 shadow-sm"
          >
            {locale === "ar" ? <ArrowRight className="w-4 h-4" /> : <ArrowLeft className="w-4 h-4" />}
            {current.btnText}
          </button>
        </div>
      </motion.div>
    </div>
  );
}
