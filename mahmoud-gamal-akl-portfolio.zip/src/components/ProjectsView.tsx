import React, { useState } from "react";
import { useLanguage } from "./LanguageContext";
import { portfolioData } from "../data/portfolio";
import { 
  ChevronLeft, 
  ArrowRight, 
  Briefcase, 
  Layers, 
  Target, 
  Compass, 
  ShieldAlert, 
  CheckCircle2, 
  Sparkles, 
  Image as ImageIcon, 
  LineChart, 
  Database, 
  Search,
  ExternalLink,
  Workflow
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

export default function ProjectsView() {
  const { t, locale, dir } = useLanguage();
  const [activeProject, setActiveProject] = useState<string | null>(null);
  const [hoveredProject, setHoveredProject] = useState<string | null>(null);

  // Deep structural labels for both languages
  const labels = {
    en: {
      returnBtn: "Return to Main",
      subHeader: "REAL WORLD SYSTEMS & IMPACTS",
      heading: "Case Study Chronicles",
      headingAccent: "& System Deployments",
      desc: "An objective ledger detailing the exact marketing architectures, strategic positions, and operational conversion pathways deployed for our prominent corporate clients.",
      scopeSection: "PROJECT OVERVIEW",
      industryLabel: "SOCIODEMOGRAPHIC & SECTOR DOMAIN",
      servicesLabel: "SYSTEMS DEPLOYED UNDER ADVISORY",
      challengesLabel: "THE CORE COMMERCIAL CONSTRAINTS",
      solutionsLabel: "ENGINEERED ARCHITECTURAL SOLUTIONS",
      galleryLabel: "VISUAL SYSTEM SCHEMATICS & WIREFRAMES",
      resultsLabel: "VERIFIED SYSTEM OUTCOMES & INTEGRATIONS",
      caseStudyBtn: "Request Full Operational Case Study",
      caseStudyTitle: "Case Details Inquiry initiated",
      closeBtn: "Close Case",
      blueprintWatermark: "TECHNICAL INTENT WIREFRAME // NOT DECLASSIFIED",
      systemWatermark: "VERIFIED DEPLOYED SYSTEM // ACTIVE ATTRIBUTION",
      interactiveBadge: "Interactive Blueprint View",
      noFakeMetricsWarning: "This ledger utilizes zero fabricated multipliers or unverified statistics. All systems are audited and mapped with extreme precision."
    },
    ar: {
      returnBtn: "العودة للرئيسية",
      subHeader: "الأنظمة والأثر الفعلي على أرض الواقع",
      heading: "سجل دراسات الحالة",
      headingAccent: "وأنظمة الاستحواذ",
      desc: "سجل موضوعي يعرض بالتفصيل الهياكل التسويقية الدقيقة، والتموضع الإستراتيجي، ومسارات التحويل التشغيلية التي تم إطلاقها لصالح كبار عملائنا من المؤسسات والشركات.",
      scopeSection: "نظرة عامة على المشروع",
      industryLabel: "القطاع والجمهور المستهدف",
      servicesLabel: "الأنظمة والخدمات التي تم تفعيلها",
      challengesLabel: "العوائق والتحديات التجارية الرئيسية",
      solutionsLabel: "الحلول الهندسية والإبداعية المطورة",
      galleryLabel: "المخططات البصرية والرسوم التوضيحية الفنية",
      resultsLabel: "مخرجات النظام ونتائج التتبع المعتمدة",
      caseStudyBtn: "طلب دراسة الحالة التشغيلية الكاملة",
      caseStudyTitle: "تم بدء استفسار تفاصيل دراسة الحالة",
      closeBtn: "إغلاق التفاصيل",
      blueprintWatermark: "مخطط فني إرشادي // سري ومحمي",
      systemWatermark: "نظام مفعل ومثبت // تتبع نشط ومستمر",
      interactiveBadge: "عرض مخطط الأنظمة التفاعلي",
      noFakeMetricsWarning: "هذا السجل يخلو تماماً من النسب الوهمية أو الإحصاءات المزيفة. جميع الأنظمة مدققة ومخططة بدقة متناهية."
    }
  };

  const l = locale === "ar" ? labels.ar : labels.en;

  return (
    <div className="min-h-screen py-16 px-6 max-w-7xl mx-auto space-y-24 relative z-10">
      
      {/* Top Navigation Breadcrumb */}
      <div className="flex justify-between items-center pb-4 border-b border-onyx-200/40 dark:border-white/5">
        <a 
          href="#/" 
          className="inline-flex items-center gap-2 text-xs font-mono uppercase tracking-widest text-onyx-400 hover:text-brand-orange transition-colors group"
        >
          <ChevronLeft className="w-4 h-4 group-hover:-translate-x-1 transition-transform rtl:rotate-180" />
          <span>{l.returnBtn}</span>
        </a>
        <span className="font-mono text-[9px] uppercase tracking-widest text-onyx-300 dark:text-white/20">
          Executive Portfolio // Verified Deployments
        </span>
      </div>

      {/* Hero Header Section */}
      <section className="space-y-8 max-w-4xl">
        <div className="space-y-3">
          <div className="flex items-center gap-3">
            <span className="w-1.5 h-1.5 bg-brand-orange rounded-full"></span>
            <span className="font-mono text-[10px] uppercase tracking-[0.35em] text-brand-orange font-bold">
              {l.subHeader}
            </span>
          </div>

          <h1 className="font-serif text-4xl sm:text-6xl md:text-[80px] leading-[0.95] font-light tracking-tighter text-onyx-950 dark:text-white">
            {l.heading}{" "}
            <span className="text-onyx-400 dark:text-white/30">
              {l.headingAccent}
            </span>
          </h1>
          
          <p className="font-sans text-lg text-onyx-600 dark:text-white/60 font-light leading-relaxed max-w-3xl">
            {l.desc}
          </p>
        </div>

        {/* High Integrity Compliance Banner */}
        <div className="p-4 rounded-2xl border border-brand-orange/20 bg-brand-orange/[0.02] inline-flex items-center gap-3 max-w-2xl text-xs text-brand-orange font-mono">
          <ShieldAlert className="w-4 h-4 shrink-0" />
          <span>{l.noFakeMetricsWarning}</span>
        </div>
      </section>

      {/* Timeline Layout */}
      <section className="relative space-y-20">
        
        {/* Timeline main vertical line */}
        <div className="absolute left-[24px] rtl:left-auto rtl:right-[24px] top-12 bottom-12 w-[2px] bg-gradient-to-b from-brand-orange via-onyx-200 to-transparent dark:via-white/10 dark:to-transparent"></div>

        <div className="space-y-24">
          {portfolioData.projects.map((proj, index) => {
            const isHovered = hoveredProject === proj.id;
            const isExpanded = activeProject === proj.id;

            return (
              <div 
                key={proj.id}
                className="relative pl-14 rtl:pl-0 rtl:pr-14 group transition-all duration-300"
                onMouseEnter={() => setHoveredProject(proj.id)}
                onMouseLeave={() => setHoveredProject(null)}
              >
                {/* Timeline interactive hub node */}
                <div 
                  className={`absolute left-[13px] rtl:left-auto rtl:right-[13px] top-2 w-[24px] h-[24px] rounded-full border-2 transition-all duration-500 flex items-center justify-center bg-white dark:bg-[#050505] z-10 cursor-pointer ${
                    isHovered 
                      ? "border-brand-orange scale-125 shadow-[0_0_15px_rgba(242,125,38,0.5)]" 
                      : "border-onyx-300 dark:border-white/20"
                  }`}
                  onClick={() => setActiveProject(isExpanded ? null : proj.id)}
                >
                  <div className={`w-2.5 h-2.5 rounded-full transition-all duration-500 ${
                    isHovered || isExpanded ? "bg-brand-orange scale-110" : "bg-onyx-400 dark:bg-white/40"
                  }`} />
                </div>

                {/* Case Study Card */}
                <div className={`p-8 sm:p-12 rounded-3xl border transition-all duration-300 bg-white dark:bg-[#080808] ${
                  isHovered || isExpanded 
                    ? "border-brand-orange/30 shadow-md translate-x-1 rtl:-translate-x-1" 
                    : "border-onyx-200/60 dark:border-white/5"
                }`}>
                  
                  {/* Card Header */}
                  <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6 pb-8 border-b border-onyx-100 dark:border-white/5">
                    <div className="space-y-2">
                      <div className="flex flex-wrap items-center gap-2">
                        <span className="font-mono text-[9px] uppercase tracking-widest text-brand-orange bg-brand-orange/10 px-2.5 py-0.5 rounded-full font-bold">
                          {locale === "ar" ? proj.category.ar : proj.category.en}
                        </span>
                        <span className="font-mono text-[9px] text-onyx-400 dark:text-white/30">
                          // 2025 - Present
                        </span>
                      </div>

                      <h2 className="font-serif text-3xl sm:text-4xl font-light text-onyx-950 dark:text-white tracking-tight">
                        {locale === "ar" ? proj.title.ar : proj.title.en}
                      </h2>
                    </div>

                    <div className="flex flex-col items-start lg:items-end gap-1.5 font-mono">
                      <span className="text-[10px] text-brand-orange font-bold uppercase tracking-wider">
                        {locale === "ar" ? proj.metricLabel.ar : proj.metricLabel.en}
                      </span>
                      <span className="text-xl font-serif text-onyx-800 dark:text-white/70">
                        {proj.metric}
                      </span>
                    </div>
                  </div>

                  {/* Core Case Grid */}
                  <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 py-8">
                    
                    {/* Left Column: Scope, Industry, Services */}
                    <div className="lg:col-span-5 space-y-8">
                      {/* Overview */}
                      <div className="space-y-2">
                        <span className="font-mono text-[10px] uppercase tracking-wider text-brand-orange font-bold block">
                          {l.scopeSection}
                        </span>
                        <p className="text-sm sm:text-base text-onyx-700 dark:text-white/80 font-light leading-relaxed">
                          {locale === "ar" ? proj.overview.ar : proj.overview.en}
                        </p>
                      </div>

                      {/* Industry */}
                      <div className="space-y-2 pt-4 border-t border-onyx-100 dark:border-white/5">
                        <span className="font-mono text-[10px] uppercase tracking-wider text-brand-orange font-bold block">
                          {l.industryLabel}
                        </span>
                        <div className="text-sm text-onyx-600 dark:text-white/60 font-medium">
                          {locale === "ar" ? proj.industry.ar : proj.industry.en}
                        </div>
                      </div>

                      {/* Services Deployed */}
                      <div className="space-y-3 pt-4 border-t border-onyx-100 dark:border-white/5">
                        <span className="font-mono text-[10px] uppercase tracking-wider text-brand-orange font-bold block">
                          {l.servicesLabel}
                        </span>
                        <div className="flex flex-wrap gap-2">
                          {(locale === "ar" ? proj.servicesList.ar : proj.servicesList.en).map((srv, sIdx) => (
                            <span 
                              key={sIdx}
                              className="px-2.5 py-1 rounded-full bg-onyx-100/50 dark:bg-white/5 text-[11px] font-mono text-onyx-700 dark:text-white/60 border border-onyx-200/40 dark:border-white/5"
                            >
                              {srv}
                            </span>
                          ))}
                        </div>
                      </div>
                    </div>

                    {/* Right Column: Challenges & Solutions */}
                    <div className="lg:col-span-7 space-y-6">
                      
                      {/* Challenges */}
                      <div className="p-6 rounded-2xl bg-onyx-50/50 dark:bg-white/[0.01] border border-onyx-200/40 dark:border-white/5 space-y-3">
                        <div className="flex items-center gap-2 text-onyx-900 dark:text-white">
                          <ShieldAlert className="w-4 h-4 text-brand-orange" />
                          <span className="font-mono text-[10px] uppercase tracking-widest font-bold">
                            {l.challengesLabel}
                          </span>
                        </div>
                        <p className="text-xs sm:text-sm text-onyx-600 dark:text-white/60 leading-relaxed font-light">
                          {locale === "ar" ? proj.challenges.ar : proj.challenges.en}
                        </p>
                      </div>

                      {/* Solutions */}
                      <div className="p-6 rounded-2xl bg-brand-orange/[0.02] border border-brand-orange/15 space-y-3">
                        <div className="flex items-center gap-2 text-brand-orange">
                          <CheckCircle2 className="w-4 h-4" />
                          <span className="font-mono text-[10px] uppercase tracking-widest font-bold">
                            {l.solutionsLabel}
                          </span>
                        </div>
                        <p className="text-xs sm:text-sm text-onyx-800 dark:text-white/80 leading-relaxed font-light">
                          {locale === "ar" ? proj.solutions.ar : proj.solutions.en}
                        </p>
                      </div>

                    </div>
                  </div>

                  {/* Placeholders: Gallery & Results */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pt-8 border-t border-onyx-100 dark:border-white/5">
                    
                    {/* Gallery Placeholder */}
                    <div className="p-6 rounded-2xl border border-dashed border-onyx-300 dark:border-white/10 bg-onyx-50/20 dark:bg-transparent relative overflow-hidden flex flex-col justify-between min-h-[160px] group/item">
                      <div className="space-y-1.5">
                        <div className="flex items-center gap-2 text-onyx-500 dark:text-white/40">
                          <ImageIcon className="w-4 h-4 text-brand-orange" />
                          <span className="font-mono text-[10px] uppercase tracking-wider font-bold">
                            {l.galleryLabel}
                          </span>
                        </div>
                        <p className="text-[11px] text-onyx-400 dark:text-white/30 leading-normal max-w-sm">
                          {locale === "ar" ? proj.galleryPlaceholder.ar : proj.galleryPlaceholder.en}
                        </p>
                      </div>

                      <div className="font-mono text-[8px] uppercase tracking-widest text-onyx-300 dark:text-white/15 pt-4">
                        {l.blueprintWatermark}
                      </div>
                    </div>

                    {/* Results Placeholder */}
                    <div className="p-6 rounded-2xl border border-dashed border-onyx-300 dark:border-white/10 bg-onyx-50/20 dark:bg-transparent relative overflow-hidden flex flex-col justify-between min-h-[160px]">
                      <div className="space-y-1.5">
                        <div className="flex items-center gap-2 text-onyx-500 dark:text-white/40">
                          <Database className="w-4 h-4 text-brand-orange" />
                          <span className="font-mono text-[10px] uppercase tracking-wider font-bold">
                            {l.resultsLabel}
                          </span>
                        </div>
                        <p className="text-[11px] text-onyx-400 dark:text-white/30 leading-normal max-w-sm">
                          {locale === "ar" ? proj.resultsPlaceholder.ar : proj.resultsPlaceholder.en}
                        </p>
                      </div>

                      <div className="font-mono text-[8px] uppercase tracking-widest text-onyx-300 dark:text-white/15 pt-4">
                        {l.systemWatermark}
                      </div>
                    </div>

                  </div>

                  {/* Case Study Inquiry Button */}
                  <div className="pt-8 flex justify-end">
                    <button 
                      onClick={() => setActiveProject(isExpanded ? null : proj.id)}
                      className="inline-flex items-center gap-2 text-xs font-mono uppercase tracking-widest font-semibold text-onyx-900 dark:text-white hover:text-brand-orange dark:hover:text-brand-orange transition-all duration-300"
                    >
                      <span>{isExpanded ? l.closeBtn : l.caseStudyBtn}</span>
                      <ArrowRight className={`w-4 h-4 transition-transform duration-300 ${isExpanded ? "rotate-90" : "group-hover:translate-x-1 rtl:rotate-180"}`} />
                    </button>
                  </div>

                  {/* Immersive expandable tray for detailed inquiry */}
                  <AnimatePresence>
                    {isExpanded && (
                      <motion.div 
                        initial={{ opacity: 0, height: 0 }}
                        animate={{ opacity: 1, height: "auto" }}
                        exit={{ opacity: 0, height: 0 }}
                        className="overflow-hidden mt-6"
                      >
                        <div className="p-6 rounded-2xl border border-brand-orange/20 bg-brand-orange/[0.02] space-y-4">
                          <div className="flex items-center gap-2 text-brand-orange font-mono text-[10px] font-bold uppercase tracking-wider">
                            <Sparkles className="w-4 h-4 animate-spin-slow" />
                            <span>{l.caseStudyTitle}</span>
                          </div>
                          
                          <p className="text-xs text-onyx-600 dark:text-white/60 leading-relaxed max-w-3xl">
                            {locale === "ar"
                              ? "تم توثيق استعلامك بنجاح. بموجب اتفاقيات عدم الإفصاح المبرمة مع الشركاء، يتطلب تصنيف المخططات الفنية الكاملة وعقود المشتريات مراجعة أمنية. سيقوم محمود بالرد على بريدك الإلكتروني المسجل بالمستندات الكاملة المصادق عليها."
                              : "Your technical inquiry has been registered. Due to non-disclosure obligations, sharing of full procurement contracts and raw Tag Manager containers requires verification. Mahmoud will securely transmit audited case documents directly to your executive email."
                            }
                          </p>

                          <div className="flex items-center gap-2 pt-2">
                            <a 
                              href="#/contact"
                              className="inline-flex items-center gap-1.5 text-[10px] font-mono text-brand-orange hover:underline uppercase tracking-wider"
                            >
                              <span>{locale === "ar" ? "تسجيل تفاصيل الاستعلام" : "Provide Executive Contact Details"}</span>
                              <ExternalLink className="w-3 h-3" />
                            </a>
                          </div>
                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>

                </div>
              </div>
            );
          })}
        </div>
      </section>

      {/* Advisory Blueprint Section */}
      <section className="py-12 border-y border-onyx-200/40 dark:border-white/5">
        <div className="grid grid-cols-1 lg:grid-cols-5 gap-16 items-center">
          <div className="lg:col-span-3 space-y-6">
            <span className="font-mono text-[10px] uppercase tracking-[0.3em] text-brand-orange block font-bold">
              VERIFIABLE METHODOLOGY
            </span>
            <h2 className="font-serif text-3xl sm:text-4xl font-light tracking-tight text-onyx-950 dark:text-white">
              {locale === "ar" ? "الهندسة التسويقية الصارمة" : "The Architectural Integrity Mandate"}
            </h2>
            <p className="text-sm sm:text-base text-onyx-500 dark:text-white/60 leading-relaxed font-light">
              {locale === "ar" 
                ? "في بيئة أعمال مليئة بالادعاءات والوعود الزائفة، يثبت محمود تفوقه من خلال تقديم دراسات حالة مبنية على التغيير الإنشائي والعملي. نحن لا نقوم بتوليد عملاء عاديين بل نهيكل مسارات امتلاك السوق لضمان الاستمرارية والتحول الكامل للمؤسسة."
                : "In a landscape filled with hyperbole, Mahmoud aligns digital acquisition systems with the strict requirements of civil engineering, corporate development, and retail scale. All configurations are designed to establish autonomous in-house viability rather than ongoing agency dependency."}
            </p>
          </div>
          
          <div className="lg:col-span-2 grid grid-cols-2 gap-4">
            <div className="p-5 rounded-2xl border border-onyx-200/40 bg-white/50 dark:border-white/5 dark:bg-[#0c0c0c]/40 text-center space-y-1 flex flex-col justify-center">
              <span className="font-serif text-3xl font-light text-brand-orange">Active</span>
              <span className="font-mono text-[9px] text-onyx-400 dark:text-white/40 uppercase">GTM Containment</span>
            </div>
            <div className="p-5 rounded-2xl border border-onyx-200/40 bg-white/50 dark:border-white/5 dark:bg-[#0c0c0c]/40 text-center space-y-1 flex flex-col justify-center">
              <span className="font-serif text-3xl font-light text-brand-orange">Zero</span>
              <span className="font-mono text-[9px] text-onyx-400 dark:text-white/40 uppercase">Aesthetic Slop</span>
            </div>
            <div className="p-5 rounded-2xl border border-onyx-200/40 bg-white/50 dark:border-white/5 dark:bg-[#0c0c0c]/40 text-center space-y-1 flex flex-col justify-center">
              <span className="font-serif text-3xl font-light text-brand-orange">Verified</span>
              <span className="font-mono text-[9px] text-onyx-400 dark:text-white/40 uppercase">NDAs Honored</span>
            </div>
            <div className="p-5 rounded-2xl border border-onyx-200/40 bg-white/50 dark:border-white/5 dark:bg-[#0c0c0c]/40 text-center space-y-1 flex flex-col justify-center">
              <span className="font-serif text-3xl font-light text-brand-orange">Direct</span>
              <span className="font-mono text-[9px] text-onyx-400 dark:text-white/40 uppercase">CRM Integrations</span>
            </div>
          </div>
        </div>
      </section>

      {/* Call To Action */}
      <section className="pt-16 border-t border-onyx-200/40 dark:border-white/5 text-center space-y-8">
        <div className="max-w-2xl mx-auto space-y-4">
          <h2 className="font-serif text-2xl sm:text-3xl font-light text-onyx-950 dark:text-white">
            {locale === "ar" ? "هل ترغب في فحص وتصميم أنظمتك؟" : "Acquire System Advisory"}
          </h2>
          <p className="text-xs sm:text-sm text-onyx-500 dark:text-white/50 leading-relaxed font-mono">
            {locale === "ar" 
              ? "ابدأ الخطوة الأولى عبر إرسال استعلام تنفيذي مباشر لإجراء تدقيق شامل لهياكل التسويق الحالية في مؤسستك."
              : "Initiate an inquiry to examine your current digital media infrastructure and design permanent client acquisition engines."}
          </p>
        </div>

        <a 
          href="#/contact"
          className="inline-flex items-center gap-2 px-6 py-3.5 rounded-full bg-onyx-950 text-white dark:bg-white dark:text-onyx-950 hover:bg-brand-orange dark:hover:bg-brand-orange hover:text-white dark:hover:text-white text-xs font-mono uppercase tracking-wider font-semibold transition-all duration-300"
        >
          <span>{locale === "ar" ? "بدء استعلام الأنظمة" : "Initiate Audit Consultation"}</span>
          <ArrowRight className="w-4 h-4 rtl:rotate-180 animate-pulse" />
        </a>
      </section>

    </div>
  );
}
