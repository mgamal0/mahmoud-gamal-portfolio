import React from "react";
import { motion, useScroll, useSpring } from "motion/react";
import { useLanguage } from "./LanguageContext";

export default function ScrollProgress() {
  const { dir } = useLanguage();
  const { scrollYProgress } = useScroll();

  // Fine-tuned spring dynamics for a highly responsive yet silky smooth editorial feel
  const scaleX = useSpring(scrollYProgress, {
    stiffness: 120,
    damping: 25,
    restDelta: 0.001
  });

  return (
    <motion.div
      id="scroll-progress-indicator"
      className="fixed top-0 xl:top-[16px] left-0 xl:left-[16px] right-0 xl:right-[16px] h-[3px] bg-brand-orange z-50 pointer-events-none"
      style={{
        scaleX,
        transformOrigin: dir === "rtl" ? "right" : "left",
      }}
    />
  );
}
