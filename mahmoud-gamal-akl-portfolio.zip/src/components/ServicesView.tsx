import React, { useState } from "react";
import { useLanguage } from "./LanguageContext";
import { 
  Target, 
  TrendingUp, 
  Cpu, 
  Users, 
  Layers, 
  Compass, 
  Settings, 
  Eye, 
  Globe, 
  BarChart3, 
  Zap, 
  ChevronLeft, 
  ArrowRight,
  ShieldCheck,
  Check,
  Search,
  Filter
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

interface ServiceItem {
  id: string;
  category: "strategy" | "acquisition" | "infrastructure";
  icon: React.ComponentType<any>;
  title: { en: string; ar: string };
  code: string;
  description: { en: string; ar: string };
  deliverables: { en: string[]; ar: string[] };
  businessValue: { en: string; ar: string };
  ctaText: { en: string; ar: string };
}

export default function ServicesView() {
  const { t, locale, dir } = useLanguage();
  const [activeCategory, setActiveCategory] = useState<"all" | "strategy" | "acquisition" | "infrastructure">("all");
  const [searchQuery, setSearchQuery] = useState("");

  const categories = [
    { id: "all", label: { en: "All Solutions", ar: "كافة الأنظمة" } },
    { id: "strategy", label: { en: "Strategy & Positioning", ar: "الإستراتيجية والتموضع" } },
    { id: "acquisition", label: { en: "Acquisition & Conversion", ar: "الاستقطاب والتحويل" } },
    { id: "infrastructure", label: { en: "Infrastructure & Scale", ar: "البنية التحتية والنمو" } },
  ] as const;

  const servicesList: ServiceItem[] = [
    {
      id: "marketing-strategy",
      category: "strategy",
      icon: Target,
      code: "SYS-MKT-STR",
      title: {
        en: "Marketing Strategy",
        ar: "استراتيجية التسويق الشاملة"
      },
      description: {
        en: "Long-term high-level growth blueprints linking customer psychology with capital efficiency to capture dominant market segments.",
        ar: "مخططات نمو بعيدة المدى تربط بين السيكولوجيا العميقة للجمهور وكفاءة رأس المال للاستحواذ السريع على الصدارة السوقية."
      },
      deliverables: {
        en: ["Strategic market positioning map", "Competitor vulnerability report", "12-month capital deployment & growth blueprint"],
        ar: ["خريطة التموضع الإستراتيجي المنافس", "تقرير ثغرات ونقاط ضعف المنافسين", "مخطط توجيه الميزانيات والنمو لـ 12 شهراً"]
      },
      businessValue: {
        en: "Establishes institutional alignment, driving long-term profitability while minimizing wasted operational cycles.",
        ar: "تحقيق توافق مؤسسي شامل يضمن أقصى ربحية ممكنة مع القضاء على الهدر المالي والتشغيلي."
      },
      ctaText: {
        en: "Request Strategic Briefing",
        ar: "طلب جلسة تخطيط إستراتيجي"
      }
    },
    {
      id: "performance-marketing",
      category: "acquisition",
      icon: TrendingUp,
      code: "SYS-PERF-MKT",
      title: {
        en: "Performance Marketing",
        ar: "التسويق القائم على الأداء"
      },
      description: {
        en: "Deploying high-impact advertising campaigns focused entirely on positive unit economics, scaling customer acquisition profitably.",
        ar: "إطلاق حملات إعلانية متكاملة تركز كلياً على اقتصاديات الوحدة الإيجابية وجذب العملاء بكفاءة ربحية عالية."
      },
      deliverables: {
        en: ["Multi-platform performance strategy", "Conversion probability models", "CAC/LTV sensitivity matrices"],
        ar: ["إستراتيجية الأداء عبر مختلف المنصات", "نماذج احتمالات معدلات التحويل", "مصفوفة فحص تكلفة الاستحواذ مقابل القيمة الدائمة"]
      },
      businessValue: {
        en: "Optimizes capital deployment to guarantee negative-friction scaling (LTV:CAC ratio exceeding 3:1).",
        ar: "تحسين توظيف ميزانيات التسويق لضمان نمو مرن بمعدل قيمة حياة عميل إلى تكلفة استحواذ تفوق 3:1."
      },
      ctaText: {
        en: "Acquire Performance Engine",
        ar: "طلب هندسة محرك الأداء"
      }
    },
    {
      id: "media-buying",
      category: "acquisition",
      icon: Cpu,
      code: "SYS-MED-BUY",
      title: {
        en: "Media Buying",
        ar: "إدارة الشراء الإعلامي الرقمي"
      },
      description: {
        en: "Algorithmic buying of digital ad inventory with hyper-rigorous cohort testing protocols and bidding optimization.",
        ar: "شراء خوارزمي دقيق للمساحات الإعلانية الرقمية مع تطبيق بروتوكولات اختبار وتقسيم صارمة للجمهور."
      },
      deliverables: {
        en: ["Enterprise ad account structure overhaul", "Custom bidding & allocation algorithms", "Deep negative-audience mapping"],
        ar: ["إعادة هيكلة حسابات الإعلانات المؤسسية", "خوارزميات مخصصة لعروض الأسعار والتوزيع", "تخطيط استبعاد الفئات غير المستهدفة بدقة"]
      },
      businessValue: {
        en: "Eliminates inefficient ad-spend leakage and continuously taps into low-CAC high-value audience segments.",
        ar: "القضاء الفوري على تسرب ميزانيات الإعلانات وتوجيهها لشرائح عالية القيمة بأقل كلفة استحواذ."
      },
      ctaText: {
        en: "Initiate Media Audit",
        ar: "طلب تدقيق ميزانيات الإعلان"
      }
    },
    {
      id: "lead-generation",
      category: "acquisition",
      icon: Users,
      code: "SYS-LEAD-GEN",
      title: {
        en: "Lead Generation",
        ar: "نظام توليد العملاء المحتملين"
      },
      description: {
        en: "Constructing high-intent acquisition pipelines that identify, attract, and filter premium enterprise B2B and consumer leads.",
        ar: "بناء مسارات استقطاب عالية الاهتمام لتحديد وجذب وفلترة العملاء المحتملين ذوي الجودة والقدرة المالية المرتفعة."
      },
      deliverables: {
        en: ["Interactive high-intent lead magnet systems", "Multistep qualification screening flows", "CRM direct injection & routing protocols"],
        ar: ["منظومة مغناطيس جذب العملاء المتفاعلة", "مسارات التقييم والتأهيل متعددة الخطوات", "بروتوكولات التوجيه والحقن المباشر في الـ CRM"]
      },
      businessValue: {
        en: "Generates a predictable stream of sales-ready opportunities, cutting average sales team cycles by over 30%.",
        ar: "توفير تدفق مستدام وقابل للتنبؤ بفرص مبيعات حقيقية، مما يقلص دورة المبيعات بنسبة تفوق 30%."
      },
      ctaText: {
        en: "Design Lead Architecture",
        ar: "هندسة بنية توليد العملاء"
      }
    },
    {
      id: "sales-funnels",
      category: "acquisition",
      icon: Layers,
      code: "SYS-SAL-FNL",
      title: {
        en: "Sales Funnels",
        ar: "تصميم قنوات ومسارات التحويل"
      },
      description: {
        en: "Multi-stage conversion path designs optimized to eliminate purchase friction, increase trust, and maximize average order value.",
        ar: "تصميم مسارات التحويل متعددة المراحل والمحسنة لإزالة عقبات اتخاذ القرار وزيادة الثقة ومتوسط قيمة الطلب الأول."
      },
      deliverables: {
        en: ["Wireframed conversion layouts & schema", "Psychological sequence copywriting", "Post-purchase upsell/cross-sell protocols"],
        ar: ["مخططات وهيكلية مسارات التحويل المرئية", "صياغة نصوص الإقناع النفسي المتسلسل", "بروتوكولات البيع الإضافي والتبادلي اللاحق"]
      },
      businessValue: {
        en: "Reduces cart abandonment rates and significantly improves the immediate ROI of every user click.",
        ar: "تقليل معدلات التخلي عن سلة الشراء وزيادة عائد الاستثمار الفوري لكل زائر للموقع."
      },
      ctaText: {
        en: "Optimize Conversion Flow",
        ar: "طلب تحسين مسار المبيعات"
      }
    },
    {
      id: "brand-positioning",
      category: "strategy",
      icon: Compass,
      code: "SYS-BRN-POS",
      title: {
        en: "Brand Positioning",
        ar: "التموضع الإستراتيجي للعلامة"
      },
      description: {
        en: "Carving out a distinct mental shelf space in your industry that commands premium pricing power and strong customer loyalty.",
        ar: "حفر صورة ذهنية فريدة وحصرية لعلامتك التجارية تتيح لك فرض هوامش تسعير مرتفعة وكسب ولاء حقيقي."
      },
      deliverables: {
        en: ["Unique Value Proposition (UVP) blueprints", "Market-perception differentiator map", "Tone-of-voice & authority guidelines"],
        ar: ["مخطط عرض القيمة الفريدة للشركة", "خريطة تفاضل الصورة الذهنية في السوق", "إرشادات نبرة الصوت والمصداقية المهنية"]
      },
      businessValue: {
        en: "Insulates your business from price-war commoditization and elevates your brand value in premium segments.",
        ar: "تحصين عملك بالكامل ضد المنافسة السعرية الضارية ويرفع قيمة العلامة لتناسب الفئات المتميزة."
      },
      ctaText: {
        en: "Establish Brand Authority",
        ar: "صياغة تموضع العلامة التجارية"
      }
    },
    {
      id: "marketing-systems",
      category: "infrastructure",
      icon: Settings,
      code: "SYS-MKT-OPS",
      title: {
        en: "Marketing Systems",
        ar: "هندسة الأنظمة والعمليات"
      },
      description: {
        en: "Assembling robust internal marketing infrastructures that synchronize software, custom playbooks, and internal talent.",
        ar: "تأسيس بنية تحتية داخلية قوية لتنظيم الأنشطة التسويقية تدمج بانسجام بين البرمجيات وخطط العمل المعيارية والكوادر."
      },
      deliverables: {
        en: ["Custom Marketing Playbooks & SOPs", "Consolidated tech stack architecture map", "Operational resource utilization logs"],
        ar: ["مخططات اللعب القياسية وإجراءات التشغيل", "خريطة معمارية شاملة لتكامل الأدوات والبرمجيات", "سجلات الاستغلال الأمثل للموارد البشرية والمالية"]
      },
      businessValue: {
        en: "Transitions marketing from a chaotic, owner-dependent department to a predictable, compounding corporate asset.",
        ar: "تحويل التسويق من قسم عشوائي يعتمد على الإدارة الفردية إلى أصل مؤسسي دقيق يتراكم نموه آلياً."
      },
      ctaText: {
        en: "Construct Operational Infrastructure",
        ar: "طلب تصميم بنية العمليات"
      }
    },
    {
      id: "creative-direction",
      category: "infrastructure",
      icon: Eye,
      code: "SYS-CRT-DIR",
      title: {
        en: "Creative Direction",
        ar: "الإشراف والتوجه الإبداعي"
      },
      description: {
        en: "Directing high-converting visual architectures that command professional attention while reinforcing premium brand equity.",
        ar: "قيادة وتوجيه إنتاج وتصميم الأصول البصرية ذات معدلات التحويل الفائقة لتعزيز مصداقية وجاذبية علامتك التجارية."
      },
      deliverables: {
        en: ["Strategic design system standards", "High-performance dynamic ad templates", "Artistic concept & content briefs"],
        ar: ["معايير ونظم التصميم البصري الإستراتيجي", "قوالب تصميمات إعلانية مرنة وعالية الأداء", "موجزات الأفكار الفنية والجمالية للمحتوى"]
      },
      businessValue: {
        en: "Maintains a pristine aesthetic threshold across all consumer touchpoints, guaranteeing instant premium authority.",
        ar: "الحفاظ على معايير بصرية فائقة الأناقة والجمال في كافة قنوات اتصالك بالعميل، لفرض جدارة علامتك الفاخرة."
      },
      ctaText: {
        en: "Elevate Visual Standards",
        ar: "طلب توجيه بصرى إبداعي"
      }
    },
    {
      id: "website-strategy",
      category: "strategy",
      icon: Globe,
      code: "SYS-WEB-STR",
      title: {
        en: "Website Strategy",
        ar: "استراتيجية وهندسة المواقع"
      },
      description: {
        en: "Re-engineering company websites into high-fidelity conversion environments, optimized for speed, clarity, and engagement.",
        ar: "إعادة هندسة البنية الرقمية للمواقع الإلكترونية وتحويلها لبيئات تحويل تفاعلية مفرطة السرعة والوضوح."
      },
      deliverables: {
        en: ["Interactive conversion mapping", "Technical speed & mobile response diagnostics", "User-intent search infrastructure planning"],
        ar: ["تخطيط تفاعلي لمسارات وسلوكيات الزوار", "تحليل وتشخيص سرعة الموقع واستجابة الهاتف", "تخطيط بنية محركات البحث المرتكزة على نية المستخدم"]
      },
      businessValue: {
        en: "Converts static, informational digital real estate into proactive, 24/7 client acquisition generators.",
        ar: "تحويل موقع الويب الراكد والتقليدي لآلة بيع وجذب عملاء مؤهلة تعمل تلقائياً على مدار الساعة."
      },
      ctaText: {
        en: "Re-Architect Digital Storefront",
        ar: "طلب إعادة هندسة موقع الويب"
      }
    },
    {
      id: "analytics",
      category: "infrastructure",
      icon: BarChart3,
      code: "SYS-ANL-TRK",
      title: {
        en: "Analytics",
        ar: "تحليلات البيانات الدقيقة"
      },
      description: {
        en: "Implementing end-to-end multi-channel tracking to provide deep mathematical clarity on cost-to-transaction performance.",
        ar: "إعداد وتكوين أنظمة تتبع متقدمة توفر شفافية رقمية مطلقة وموثقة من مصدر الإعلانات وحتى العمليات المالية."
      },
      deliverables: {
        en: ["Server-side tracking (GTM Server-Side, Conversions API)", "Unified executive business dashboards", "Multi-touch attribution models"],
        ar: ["إعداد التتبع من جهة الخادم (GTM API & CAPI)", "لوحات تحكم تنفيذية موحدة وقابلة للقراءة الفورية", "نماذج الإسناد ونسب المبيعات لعدة قنوات"]
      },
      businessValue: {
        en: "Unlocks real-time, tamper-proof decision making by directly tracing every single ad-dollar spent to net bank revenue.",
        ar: "تمكين اتخاذ القرارات اللحظية الحكيمة عبر تتبع كل قرش من ميزانيتك وربطه مباشرة بصافي الأرباح."
      },
      ctaText: {
        en: "Secure Precision Analytics",
        ar: "طلب تهيئة أنظمة التتبع والتحليل"
      }
    },
    {
      id: "marketing-automation",
      category: "infrastructure",
      icon: Zap,
      code: "SYS-MKT-AUT",
      title: {
        en: "Marketing Automation",
        ar: "أتمتة العمليات التسويقية"
      },
      description: {
        en: "Designing dynamic trigger-based nurturing workflows that react instantly to lead behaviors to optimize close-rates.",
        ar: "تصميم وتنفيذ سلاسل تواصل آلية تتفاعل فوراً مع سلوكيات العميل المحتمل لرفع احتمالات إغلاق الصفقات."
      },
      deliverables: {
        en: ["Multi-step lifecycle nurturing flows", "Dynamic cart-abandonment & recovery streams", "Automated executive booking protocols"],
        ar: ["سلاسل ومسارات رعاية العملاء متعددة الخطوات", "أتمتة متابعة واسترداد سلال التسوق المتروكة", "بروتوكولات حجز المواعيد والاجتماعات الآلية"]
      },
      businessValue: {
        en: "Extracts additional high-margin revenue from inactive databases without adding permanent human resource overhead.",
        ar: "استخراج إيرادات مبيعات إضافية من قواعد البيانات الراكدة دون زيادة تكاليف الكادر البشري."
      },
      ctaText: {
        en: "Automate Scaling Systems",
        ar: "طلب تصميم أنظمة الأتمتة"
      }
    }
  ];

  const filteredServices = servicesList.filter((service) => {
    const matchesCategory = activeCategory === "all" || service.category === activeCategory;
    const query = searchQuery.toLowerCase();
    const matchesSearch = 
      service.title.en.toLowerCase().includes(query) ||
      service.title.ar.toLowerCase().includes(query) ||
      service.description.en.toLowerCase().includes(query) ||
      service.description.ar.toLowerCase().includes(query) ||
      service.code.toLowerCase().includes(query);
    return matchesCategory && matchesSearch;
  });

  return (
    <div id="services-page-container" className="min-h-screen py-16 px-6 max-w-7xl mx-auto space-y-16 relative z-10">
      
      {/* Back Button & Navigation Header */}
      <div className="flex justify-between items-center pb-4 border-b border-onyx-200/40 dark:border-white/5">
        <a 
          href="#/" 
          className="inline-flex items-center gap-2 text-xs font-mono uppercase tracking-widest text-onyx-400 hover:text-brand-orange transition-colors group"
        >
          <ChevronLeft className="w-4 h-4 group-hover:-translate-x-1 transition-transform rtl:rotate-180" />
          <span>{locale === "ar" ? "العودة للرئيسية" : "Return to Systems Overview"}</span>
        </a>
        <span className="font-mono text-[9px] uppercase tracking-widest text-onyx-300 dark:text-white/20">
          Executive Portfolio // Services & Systems Ledger
        </span>
      </div>

      {/* Hero Header Section */}
      <section className="space-y-8 max-w-4xl">
        <div className="space-y-3">
          <div className="flex items-center gap-3">
            <span className="w-1.5 h-1.5 bg-brand-orange rounded-full"></span>
            <span className="font-mono text-[10px] uppercase tracking-[0.35em] text-brand-orange font-bold">
              {locale === "ar" ? "كتالوج الأنظمة والحلول" : "SYSTEMS & ARCHITECTURE DIRECTORY"}
            </span>
          </div>

          <h1 className="font-serif text-4xl sm:text-6xl md:text-[80px] leading-[0.95] font-light tracking-tighter text-onyx-950 dark:text-white">
            {locale === "ar" ? "أنظمة تسويق وهندسة" : "Growth Marketing"}{" "}
            <span className="text-onyx-400 dark:text-white/30">
              {locale === "ar" ? "النمو للمؤسسات" : "Engines & Architecture"}
            </span>
          </h1>
          
          <p className="font-sans text-lg text-onyx-600 dark:text-white/60 font-light leading-relaxed max-w-3xl">
            {locale === "ar" 
              ? "مجموعة من الخدمات والأنظمة التسويقية عالية الدقة المصممة لتنسجم مع ميزانياتك وتحقق أهدافك المالية دون تعقيد أو هدر."
              : "An array of structured, engineering-grade marketing frameworks and software solutions. Each system is custom integrated into your existing workflows to maximize bottom-line margin expansion."
            }
          </p>
        </div>
      </section>

      {/* Filter and Search Bar Section */}
      <section className="flex flex-col lg:flex-row gap-6 justify-between items-start lg:items-center py-6 border-y border-onyx-200/40 dark:border-white/5 bg-onyx-50/50 dark:bg-white/[0.01] p-6 rounded-3xl">
        {/* Category Tabs */}
        <div className="flex flex-wrap gap-2">
          {categories.map((cat) => (
            <button
              key={cat.id}
              onClick={() => setActiveCategory(cat.id)}
              className={`px-4 py-2 rounded-full text-xs font-mono tracking-wider transition-all duration-300 ${
                activeCategory === cat.id
                  ? "bg-brand-orange text-white"
                  : "bg-onyx-100 dark:bg-white/5 text-onyx-500 dark:text-white/55 hover:bg-onyx-200 dark:hover:bg-white/10 hover:text-onyx-950 dark:hover:text-white"
              }`}
            >
              {locale === "ar" ? cat.label.ar : cat.label.en}
            </button>
          ))}
        </div>

        {/* Live Search */}
        <div className="relative w-full lg:w-80">
          <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-onyx-400 dark:text-white/20" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder={locale === "ar" ? "ابحث عن نظام أو خدمة..." : "Search services directory..."}
            className="w-full pl-10 pr-4 py-2 rounded-full border border-onyx-200/60 dark:border-white/10 bg-white/50 dark:bg-black/20 text-xs font-mono focus:border-brand-orange focus:outline-none transition-colors"
          />
        </div>
      </section>

      {/* Systems Catalog Cards Grid */}
      <section className="relative">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          <AnimatePresence mode="popLayout">
            {filteredServices.map((service, idx) => {
              const Icon = service.icon;
              return (
                <motion.div
                  key={service.id}
                  layout
                  initial={{ opacity: 0, y: 15 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, scale: 0.95 }}
                  transition={{ duration: 0.3 }}
                  className="p-8 rounded-3xl border border-onyx-200/50 bg-white dark:border-white/5 dark:bg-[#080808] hover:border-brand-orange/40 transition-all duration-300 flex flex-col justify-between space-y-8 shadow-sm hover:shadow-md relative overflow-hidden group"
                >
                  <div className="absolute top-0 right-0 p-6 pointer-events-none text-brand-orange/5 text-6xl font-mono select-none">
                    {idx + 1 < 10 ? `0${idx + 1}` : idx + 1}
                  </div>

                  <div className="space-y-6">
                    {/* Header: Icon + Code */}
                    <div className="flex justify-between items-center">
                      <div className="p-3 rounded-2xl bg-brand-orange/10 text-brand-orange">
                        <Icon className="w-5 h-5" />
                      </div>
                      <span className="font-mono text-[9px] tracking-widest text-onyx-400 dark:text-white/20 uppercase">
                        {service.code}
                      </span>
                    </div>

                    {/* Title & Description */}
                    <div className="space-y-3">
                      <h3 className="font-serif text-xl sm:text-2xl font-semibold text-onyx-950 dark:text-white leading-snug group-hover:text-brand-orange transition-colors">
                        {locale === "ar" ? service.title.ar : service.title.en}
                      </h3>
                      <p className="text-xs sm:text-sm text-onyx-500 dark:text-white/50 leading-relaxed font-light min-h-[56px]">
                        {locale === "ar" ? service.description.ar : service.description.en}
                      </p>
                    </div>

                    {/* Deliverables / Scope */}
                    <div className="space-y-3 pt-2 border-t border-onyx-100 dark:border-white/5">
                      <span className="font-mono text-[9px] uppercase tracking-wider text-brand-orange block font-bold">
                        {locale === "ar" ? "مخرجات النظام وتسليماته" : "SYSTEM DELIVERABLES // SCOPE"}
                      </span>
                      <ul className="space-y-2">
                        {(locale === "ar" ? service.deliverables.ar : service.deliverables.en).map((del, dIdx) => (
                          <li key={dIdx} className="flex items-start gap-2 text-xs text-onyx-600 dark:text-white/60">
                            <Check className="w-3.5 h-3.5 text-brand-orange mt-0.5 flex-shrink-0" />
                            <span>{del}</span>
                          </li>
                        ))}
                      </ul>
                    </div>

                    {/* Business Value Metrics */}
                    <div className="p-4 rounded-2xl bg-onyx-50 dark:bg-white/[0.02] border border-onyx-100 dark:border-white/5 space-y-1.5">
                      <span className="font-mono text-[8px] uppercase tracking-wider text-onyx-400 dark:text-white/30 block">
                        {locale === "ar" ? "الأثر المالي والقيمة المحققة" : "BUSINESS VALUE // ROAS IMPACT"}
                      </span>
                      <p className="text-xs font-serif font-medium text-onyx-900 dark:text-white/90 italic">
                        {locale === "ar" ? service.businessValue.ar : service.businessValue.en}
                      </p>
                    </div>
                  </div>

                  {/* CTA Action */}
                  <a
                    href="#/contact"
                    className="w-full inline-flex items-center justify-between px-5 py-3 rounded-2xl border border-onyx-200 dark:border-white/10 bg-white/80 dark:bg-black/40 hover:bg-brand-orange hover:text-white dark:hover:bg-brand-orange dark:hover:text-white font-mono text-xs uppercase tracking-wider transition-all duration-300 group/btn"
                  >
                    <span>{locale === "ar" ? service.ctaText.ar : service.ctaText.en}</span>
                    <ArrowRight className="w-4 h-4 group-hover/btn:translate-x-1 transition-transform rtl:rotate-180" />
                  </a>
                </motion.div>
              );
            })}
          </AnimatePresence>
        </div>

        {/* Empty State */}
        {filteredServices.length === 0 && (
          <div className="text-center py-20 space-y-4">
            <Filter className="w-12 h-12 text-onyx-300 dark:text-white/10 mx-auto" />
            <p className="font-mono text-xs text-onyx-400 dark:text-white/30">
              {locale === "ar" ? "لم يتم العثور على أنظمة مطابقة لمصطلح البحث." : "No matching growth architectures found."}
            </p>
          </div>
        )}
      </section>

      {/* Advisory Banner Bottom */}
      <section className="pt-16 border-t border-onyx-200/40 dark:border-white/5 text-center space-y-8">
        <div className="max-w-2xl mx-auto space-y-4">
          <h2 className="font-serif text-2xl sm:text-3xl font-light text-onyx-950 dark:text-white">
            {locale === "ar" ? "هل ترغب في صياغة أنظمتك التسويقية المخصصة؟" : "Configure Your Corporate Marketing Architecture"}
          </h2>
          <p className="text-xs sm:text-sm text-onyx-500 dark:text-white/50 leading-relaxed font-mono">
            {locale === "ar" 
              ? "اضمن توحيد كافة عمليات الشراء واستقطاب العملاء لتتناسب تماماً مع ميزانيتك وخطة مبيعاتك الإستراتيجية."
              : "Let's engineer custom workflows, playbooks, and server-side attributions tailored explicitly to your commercial footprint."}
          </p>
        </div>

        <a 
          href="#/contact"
          className="inline-flex items-center gap-2 px-6 py-3.5 rounded-full bg-onyx-950 text-white dark:bg-white dark:text-onyx-950 hover:bg-brand-orange dark:hover:bg-brand-orange hover:text-white dark:hover:text-white text-xs font-mono uppercase tracking-wider font-semibold transition-all duration-300"
        >
          <span>{locale === "ar" ? "بدء استشارة الأنظمة" : "Initiate Engineering Audit"}</span>
          <ArrowRight className="w-4 h-4 rtl:rotate-180 animate-pulse" />
        </a>
      </section>

    </div>
  );
}
