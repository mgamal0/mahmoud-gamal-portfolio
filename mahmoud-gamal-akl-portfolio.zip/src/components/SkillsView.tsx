import React, { useState } from "react";
import { useLanguage } from "./LanguageContext";
import { 
  ChevronLeft, 
  ArrowRight, 
  Cpu, 
  TrendingUp, 
  Compass, 
  Layers, 
  Database, 
  LineChart, 
  Laptop, 
  Wrench, 
  BadgeCheck,
  CheckCircle2,
  ExternalLink,
  Bot
} from "lucide-react";
import { motion } from "motion/react";

interface SkillItem {
  name: string;
  nameAr: string;
  proficiency: number; // 0-100
  level: { en: string; ar: string };
  metrics: { en: string; ar: string };
}

interface SkillGroup {
  id: string;
  title: { en: string; ar: string };
  subtitle: { en: string; ar: string };
  icon: React.ComponentType<any>;
  color: string;
  skills: SkillItem[];
}

export default function SkillsView() {
  const { locale, dir } = useLanguage();
  const [hoveredSkill, setHoveredSkill] = useState<string | null>(null);
  const [activeGroup, setActiveGroup] = useState<string>("all");

  const skillGroups: SkillGroup[] = [
    {
      id: "marketing",
      title: { en: "Growth & Marketing Engineering", ar: "هندسة النمو والتسويق" },
      subtitle: { en: "High-yield conversion loops and deep psychological positioning models.", ar: "حلقات تحويل عالية العائد ونماذج تموضع نفسي عميق." },
      icon: TrendingUp,
      color: "from-brand-orange to-amber-500",
      skills: [
        {
          name: "Performance Marketing",
          nameAr: "تسويق الأداء الرقمي",
          proficiency: 95,
          level: { en: "Expert / Lead Architect", ar: "خبير / مهندس رئيسي" },
          metrics: { en: "Direct-response campaigns & multi-channel funnels", ar: "الحملات المباشرة ومسارات الاستحواذ متعددة القنوات" }
        },
        {
          name: "Growth Strategy",
          nameAr: "إستراتيجية نمو الأعمال",
          proficiency: 92,
          level: { en: "Expert Consultant", ar: "مستشار خبير" },
          metrics: { en: "LTV maximization, CAC optimization & pipeline math", ar: "تعظيم القيمة العمرية، تحسين تكلفة الاستحواذ وحساب المبيعات" }
        },
        {
          name: "Media Buying",
          nameAr: "الشراء الفني للمساحات الإعلانية",
          proficiency: 94,
          level: { en: "Elite Media Buyer", ar: "مشتري إعلانات متميز" },
          metrics: { en: "Multi-million dollar budgeting & real-time bid orchestration", ar: "إدارة الميزانيات المليونية وتوجيه المزايدات اللحظية" }
        },
        {
          name: "Brand Positioning",
          nameAr: "التموضع الإستراتيجي للعلامة",
          proficiency: 89,
          level: { en: "Strategic Director", ar: "مدير إستراتيجي" },
          metrics: { en: "Corporate authority positioning & premium pricing setups", ar: "تموضع الهيئة المؤسسية وتنسيق هيكل التسعير الفاخر" }
        }
      ]
    },
    {
      id: "business",
      title: { en: "Business & Acquisition Systems", ar: "أنظمة الأعمال والاستحواذ" },
      subtitle: { en: "Translating digital traffic into robust enterprise valuation and automated pipelines.", ar: "تحويل التدفق الرقمي لتقييم مؤسسي قوي ومسارات مبيعات مؤتمتة." },
      icon: Layers,
      color: "from-blue-500 to-indigo-600",
      skills: [
        {
          name: "Business Development",
          nameAr: "تطوير الأعمال والشركات",
          proficiency: 90,
          level: { en: "Strategic Advisor", ar: "مستشار إستراتيجي" },
          metrics: { en: "B2B enterprise partnership models & commercial leverage", ar: "نماذج شراكات الشركات B2B والرافعة التجارية للمؤسسات" }
        },
        {
          name: "Sales Systems",
          nameAr: "تصميم أنظمة المبيعات",
          proficiency: 88,
          level: { en: "Systems Architect", ar: "مهندس أنظمة مبيعات" },
          metrics: { en: "CRM pipelines, automated estimators & sales routing", ar: "مسارات الـ CRM، حواسب التثمين المؤتمتة وتوزيع الصفقات" }
        },
        {
          name: "Customer Acquisition",
          nameAr: "الاستحواذ وجذب العملاء",
          proficiency: 93,
          level: { en: "Expert / Architect", ar: "خبير / مهندس استحواذ" },
          metrics: { en: "Inbound engine construction & pre-qualification funnels", ar: "بناء محركات البحث الواردة ومسارات تصفية وتأهيل العملاء" }
        }
      ]
    },
    {
      id: "analytics",
      title: { en: "Analytics & Attribution Engines", ar: "محركات التحليل وإسناد البيانات" },
      subtitle: { en: "Eliminating reliance on platform estimates. Establishing 100% first-party tracking.", ar: "إلغاء الاعتماد على تقديرات المنصات. تأسيس تتبع داخلي معتمد بنسبة 100٪." },
      icon: LineChart,
      color: "from-teal-500 to-emerald-600",
      skills: [
        {
          name: "Google Analytics (GA4)",
          nameAr: "تحليلات جوجل (GA4)",
          proficiency: 94,
          level: { en: "Advanced Analytics Architect", ar: "مهندس تحليلات متقدم" },
          metrics: { en: "Cohort retention tracking & behavioral user flow design", ar: "تتبع الاحتفاظ بالفئات وتصميم تدفقات سلوك المستخدمين" }
        },
        {
          name: "Looker Studio",
          nameAr: "لوكر ستوديو",
          proficiency: 91,
          level: { en: "Visual Intelligence Director", ar: "مدير ذكاء البيانات البصري" },
          metrics: { en: "Interactive executive dashboards & live margin monitors", ar: "لوحات بيانات تنفيذية تفاعلية ومراقبات لحظية لهوامش الربح" }
        },
        {
          name: "Google Tag Manager",
          nameAr: "مدير علامات جوجل (GTM)",
          proficiency: 95,
          level: { en: "Technical Deployment Lead", ar: "قائد التنفيذ الفني" },
          metrics: { en: "Server-side tagging & robust pixel-perfect events API", ar: "تتبع الخادم (Server-side) وتكامل أحداث بيكسل المتكاملة" }
        }
      ]
    },
    {
      id: "tools",
      title: { en: "Core Operational Stack & AI Engines", ar: "الأدوات التشغيلية ومحركات الذكاء" },
      subtitle: { en: "Leveraging state-of-the-art software systems to accelerate project delivery cycles.", ar: "استغلال أحدث الأنظمة والبرمجيات لتسريع دورات تسليم المشروعات الكبرى." },
      icon: Wrench,
      color: "from-purple-500 to-pink-600",
      skills: [
        {
          name: "Meta Business Suite",
          nameAr: "ميتا بزنس سويت",
          proficiency: 96,
          level: { en: "Enterprise Admin", ar: "مدير إعلانات مؤسسي" },
          metrics: { en: "Catalog automation & pixel API servers", ar: "أتمتة الكتالوجات وخوادم بيكسل البرمجية للتحويل" }
        },
        {
          name: "Canva",
          nameAr: "كانفا للتصميم",
          proficiency: 85,
          level: { en: "Creative Director", ar: "توجيه إبداعي مرئي" },
          metrics: { en: "Rapid responsive wireframing & conceptual mockups", ar: "بناء هياكل التخطيط السريعة والنماذج التجريبية المفاهيمية" }
        },
        {
          name: "WordPress",
          nameAr: "ووردبريس",
          proficiency: 88,
          level: { en: "Core Deployment Engine", ar: "محرك النشر الأساسي" },
          metrics: { en: "SEO-compliant landing page structure & CMS tuning", ar: "بناء صفحات الهبوط الصديقة لمحركات البحث وضبط CMS" }
        },
        {
          name: "Notion",
          nameAr: "نوشن للتنظيم",
          proficiency: 90,
          level: { en: "Operations Architect", ar: "مهندس عمليات تشغيلية" },
          metrics: { en: "Centralized client portals & unified system documentation", ar: "بوابات العملاء المركزية وتوحيد توثيق أنظمة العمل" }
        },
        {
          name: "ChatGPT",
          nameAr: "شات جي بي تي",
          proficiency: 92,
          level: { en: "Advanced Cognitive Engineer", ar: "مهندس إدراك معرفي متقدم" },
          metrics: { en: "Text modeling & consumer psychology hook framing", ar: "نمذجة النصوص وصياغة محفزات علم نفس المستهلك" }
        },
        {
          name: "Claude",
          nameAr: "كلود الذكي",
          proficiency: 93,
          level: { en: "Advanced Prompt Engineer", ar: "مهندس هندسة الأوامر المتقدمة" },
          metrics: { en: "Analytical research synthesis & rigorous strategic planning", ar: "تركيب التحليلات البحثية والتخطيط الإستراتيجي الدقيق" }
        },
        {
          name: "Gemini",
          nameAr: "جوجل جيميناي",
          proficiency: 94,
          level: { en: "Technical Systems Engineer", ar: "مهندس أنظمة ذكاء فنية" },
          metrics: { en: "Industrial market data processing & Google API hooks", ar: "معالجة بيانات السوق الصناعي وربط واجهات جوجل الذكية" }
        }
      ]
    }
  ];

  const labels = {
    en: {
      returnBtn: "Return to Core Profile",
      subHeader: "PRECISE PROFESSIONAL CAPABILITY MATRIX",
      heading: "The Technical Skills",
      headingAccent: "& Architecture Matrix",
      desc: "An audited blueprint of Mahmoud's functional capabilities, diagnostic tools, and operational proficiencies mapped with extreme high fidelity.",
      groupAll: "Comprehensive Stack",
      groupMarketing: "Growth & Marketing",
      groupBusiness: "Business & Acquisition",
      groupAnalytics: "Analytics & Tracking",
      groupTools: "Software Stack & AI",
      noHypeGuarantee: "Absolute capability transparency. No fabricated values, no redundant acronyms.",
      proficiencyTerm: "Proficiency Factor",
      levelTerm: "Operational Depth",
      metricsTerm: "Functional Deliverable Map",
      advisoryCallTitle: "Secure Architect-Level Capabilities",
      advisoryCallDesc: "Request a custom systems diagnostic evaluation to identify leaky conversion funnels and deploy robust, high-yielding acquisition mechanics in your enterprise.",
      advisoryBtn: "Secure System Advisory"
    },
    ar: {
      returnBtn: "العودة للملف الأساسي",
      subHeader: "مصفوفة القدرات والإمكانات المهنية الدقيقة",
      heading: "مصفوفة المهارات",
      headingAccent: "والبنية الفنية والتطبيقات",
      desc: "مخطط هيكلي مدقق يستعرض القدرات والمهارات الفنية، والتشخيصية، والتشغيلية المعتمدة للدرجة الأولى من كفاءة محمود التشغيلية.",
      groupAll: "المنظومة الكاملة",
      groupMarketing: "التسويق والنمو",
      groupBusiness: "الأعمال والاستحواذ",
      groupAnalytics: "التحليلات والتتبع",
      groupTools: "أدوات التشغيل والذكاء",
      noHypeGuarantee: "شفافية مطلقة للقدرات. بدون مبالغات وهمية، أو اختصارات فارغة من الأثر التجاري الفعلي.",
      proficiencyTerm: "معامل الكفاءة والتمكن",
      levelTerm: "العمق التشغيلي الفني",
      metricsTerm: "المخرجات ونطاق الأثر الوظيفي",
      advisoryCallTitle: "احصل على الكفاءة الهندسية والتسويقية",
      advisoryCallDesc: "اطلب فحصاً تشخيصياً شاملاً ومخصصاً لأنظمتك للتعرف على مواضع نزيف العملاء والتحويل، وإطلاق آليات استحواذ صلبة وعالية المردود في مؤسستك.",
      advisoryBtn: "طلب استشارة الأنظمة والتدقيق"
    }
  };

  const l = locale === "ar" ? labels.ar : labels.en;

  // Filter groups
  const filteredGroups = activeGroup === "all" 
    ? skillGroups 
    : skillGroups.filter(g => g.id === activeGroup);

  return (
    <div className="min-h-screen py-16 px-6 max-w-7xl mx-auto space-y-24 relative z-10">
      
      {/* Breadcrumb Header */}
      <div className="flex justify-between items-center pb-4 border-b border-onyx-200/40 dark:border-white/5">
        <a 
          href="#/" 
          className="inline-flex items-center gap-2 text-xs font-mono uppercase tracking-widest text-onyx-400 hover:text-brand-orange transition-colors group"
        >
          <ChevronLeft className="w-4 h-4 group-hover:-translate-x-1 transition-transform rtl:rotate-180" />
          <span>{l.returnBtn}</span>
        </a>
        <span className="font-mono text-[9px] uppercase tracking-widest text-onyx-300 dark:text-white/20">
          Executive Portfolio // Capabilities Audit
        </span>
      </div>

      {/* Hero Header */}
      <section className="space-y-8 max-w-4xl">
        <div className="space-y-3">
          <div className="flex items-center gap-3">
            <span className="w-1.5 h-1.5 bg-brand-orange rounded-full"></span>
            <span className="font-mono text-[10px] uppercase tracking-[0.35em] text-brand-orange font-bold">
              {l.subHeader}
            </span>
          </div>

          <h1 className="font-serif text-4xl sm:text-6xl md:text-[80px] leading-[0.95] font-light tracking-tighter text-onyx-950 dark:text-white">
            {l.heading}{" "}
            <span className="text-onyx-400 dark:text-white/30">
              {l.headingAccent}
            </span>
          </h1>
          
          <p className="font-sans text-lg text-onyx-600 dark:text-white/60 font-light leading-relaxed max-w-3xl">
            {l.desc}
          </p>
        </div>

        {/* Security / Quality Check banner */}
        <div className="p-4 rounded-2xl border border-brand-orange/20 bg-brand-orange/[0.02] inline-flex items-center gap-3 max-w-2xl text-xs text-brand-orange font-mono">
          <BadgeCheck className="w-4 h-4 shrink-0 text-brand-orange" />
          <span>{l.noHypeGuarantee}</span>
        </div>
      </section>

      {/* Interactive Quick Filter bar */}
      <section className="border-b border-onyx-200/40 dark:border-white/5 pb-6">
        <div className="flex flex-wrap gap-2">
          {[
            { id: "all", label: l.groupAll },
            { id: "marketing", label: l.groupMarketing },
            { id: "business", label: l.groupBusiness },
            { id: "analytics", label: l.groupAnalytics },
            { id: "tools", label: l.groupTools }
          ].map(btn => (
            <button
              key={btn.id}
              onClick={() => setActiveGroup(btn.id)}
              className={`px-4 py-2 rounded-xl text-xs font-mono uppercase tracking-wider transition-all duration-300 border ${
                activeGroup === btn.id 
                  ? "bg-onyx-950 border-onyx-950 text-white dark:bg-white dark:border-white dark:text-onyx-950 font-bold" 
                  : "bg-transparent border-onyx-200/60 hover:border-brand-orange/40 text-onyx-600 dark:border-white/5 dark:text-white/60 hover:text-brand-orange dark:hover:text-brand-orange"
              }`}
            >
              {btn.label}
            </button>
          ))}
        </div>
      </section>

      {/* Main Groups Matrix with premium progress displays */}
      <section className="space-y-16">
        {filteredGroups.map((group) => {
          const GroupIcon = group.icon;
          return (
            <div 
              key={group.id} 
              className="space-y-8 p-8 sm:p-10 rounded-3xl border border-onyx-200/60 dark:border-white/5 bg-onyx-50/20 dark:bg-white/[0.005] relative overflow-hidden"
            >
              {/* Subtle background overlay */}
              <div className="absolute right-0 top-0 w-64 h-64 bg-gradient-to-bl from-brand-orange/5 to-transparent rounded-bl-full pointer-events-none" />

              {/* Group Header */}
              <div className="flex items-start gap-4 pb-6 border-b border-onyx-200/40 dark:border-white/5 max-w-4xl">
                <div className="p-3.5 rounded-2xl bg-brand-orange/10 text-brand-orange shrink-0">
                  <GroupIcon className="w-6 h-6" />
                </div>
                <div className="space-y-1.5">
                  <h2 className="font-serif text-2xl sm:text-3xl font-light text-onyx-950 dark:text-white tracking-tight">
                    {locale === "ar" ? group.title.ar : group.title.en}
                  </h2>
                  <p className="text-xs sm:text-sm text-onyx-500 dark:text-white/55 font-sans leading-relaxed">
                    {locale === "ar" ? group.subtitle.ar : group.subtitle.en}
                  </p>
                </div>
              </div>

              {/* Premium Skills Timeline and Progress Cards */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                {group.skills.map((skill, sIdx) => {
                  const skillUniqueKey = `${group.id}-${sIdx}`;
                  const isHovered = hoveredSkill === skillUniqueKey;
                  
                  return (
                    <div
                      key={sIdx}
                      className={`p-6 sm:p-8 rounded-2xl border transition-all duration-300 relative bg-white dark:bg-[#070707] ${
                        isHovered 
                          ? "border-brand-orange/40 shadow-sm translate-x-1 rtl:-translate-x-1" 
                          : "border-onyx-150 dark:border-white/5"
                      }`}
                      onMouseEnter={() => setHoveredSkill(skillUniqueKey)}
                      onMouseLeave={() => setHoveredSkill(null)}
                    >
                      {/* Badge / Index indicator */}
                      <div className="absolute top-4 right-4 rtl:right-auto rtl:left-4 font-mono text-[9px] text-onyx-300 dark:text-white/10 tracking-widest uppercase">
                        {group.id.substring(0, 3)} // 0{sIdx + 1}
                      </div>

                      {/* Name & Basic level */}
                      <div className="space-y-1 pr-12 rtl:pr-0 rtl:pl-12">
                        <h3 className="font-serif text-lg sm:text-xl font-medium text-onyx-950 dark:text-white tracking-tight">
                          {locale === "ar" ? skill.nameAr : skill.name}
                        </h3>
                        <div className="flex items-center gap-1.5 text-xs text-brand-orange font-mono">
                          <CheckCircle2 className="w-3.5 h-3.5" />
                          <span>{locale === "ar" ? skill.level.ar : skill.level.en}</span>
                        </div>
                      </div>

                      {/* Premium Technical Progress Gauge */}
                      <div className="mt-6 space-y-2.5">
                        <div className="flex justify-between items-center text-[10px] font-mono uppercase tracking-wider">
                          <span className="text-onyx-400 dark:text-white/30">{l.proficiencyTerm}</span>
                          <span className="text-brand-orange font-bold font-mono">{skill.proficiency}%</span>
                        </div>
                        
                        {/* Premium custom bar gauge */}
                        <div className="h-2 w-full rounded-full bg-onyx-100 dark:bg-white/5 overflow-hidden relative">
                          {/* Segmented architectural background markers */}
                          <div className="absolute inset-0 flex justify-between pointer-events-none px-1">
                            {[...Array(10)].map((_, i) => (
                              <div key={i} className="w-[1px] h-full bg-white/20 dark:bg-[#121212]/40" />
                            ))}
                          </div>
                          
                          {/* Animated main fill */}
                          <motion.div 
                            initial={{ width: 0 }}
                            animate={{ width: `${skill.proficiency}%` }}
                            transition={{ duration: 1.2, ease: "easeOut" }}
                            className={`h-full bg-gradient-to-r ${group.color} rounded-full`}
                          />
                        </div>
                      </div>

                      {/* Functional Deliverables & Metadata */}
                      <div className="mt-6 pt-5 border-t border-onyx-100 dark:border-white/5 space-y-1.5">
                        <span className="font-mono text-[9px] uppercase tracking-wider text-onyx-400 dark:text-white/30 block">
                          {l.metricsTerm}
                        </span>
                        <p className="text-xs sm:text-sm text-onyx-600 dark:text-white/60 font-light leading-relaxed">
                          {locale === "ar" ? skill.metrics.ar : skill.metrics.en}
                        </p>
                      </div>

                      {/* Tooltip detail when hovered */}
                      <div className={`mt-4 pt-3 border-t border-dashed border-onyx-100 dark:border-white/5 text-[10px] font-mono text-onyx-400 dark:text-white/25 flex items-center justify-between transition-opacity duration-300 ${
                        isHovered ? "opacity-100" : "opacity-0"
                      }`}>
                        <span>SYSTEM TYPE: PRODUCTION LEVEL</span>
                        <span>STATUS: VERIFIED</span>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          );
        })}
      </section>

      {/* Methodological Blueprint / Summary Box */}
      <section className="py-12 border-y border-onyx-200/40 dark:border-white/5">
        <div className="grid grid-cols-1 lg:grid-cols-5 gap-16 items-center">
          <div className="lg:col-span-3 space-y-6">
            <span className="font-mono text-[10px] uppercase tracking-[0.3em] text-brand-orange block font-bold">
              OPERATIONAL INTEGRITY
            </span>
            <h2 className="font-serif text-3xl sm:text-4xl font-light tracking-tight text-onyx-950 dark:text-white">
              {locale === "ar" ? "الهندسة المعرفية والعملية" : "The Multi-Core Execution Model"}
            </h2>
            <p className="text-sm sm:text-base text-onyx-500 dark:text-white/60 leading-relaxed font-light">
              {locale === "ar" 
                ? "إن التمكن من الأدوات ليس مجرد معرفة بوجودها، بل هو القدرة على دمجها في نظام تشغيل تجاري متكامل. نربط الحملات المدفوعة بإحصاءات الخادم (GA4) ونوظف الذكاء الاصطناعي (Claude/Gemini) لتسريع توليد المحتوى الإبداعي وصقل العروض بما يضمن التفوق التنافسي التام للمؤسسة."
                : "Operational capability is not about isolated platforms; it is about cross-platform synthesis. By aligning CRM data pipelines with server-side tagging (GTM) and utilizing advanced cognitive AI models (Claude, Gemini), Mahmoud establishes self-healing acquisition engines. Every skill in this matrix is deployed to remove commercial friction and build compounding corporate assets."}
            </p>
          </div>
          
          <div className="lg:col-span-2 grid grid-cols-2 gap-4">
            <div className="p-5 rounded-2xl border border-onyx-200/40 bg-white/50 dark:border-white/5 dark:bg-[#0c0c0c]/40 text-center space-y-1 flex flex-col justify-center">
              <span className="font-serif text-3xl font-light text-brand-orange">100%</span>
              <span className="font-mono text-[9px] text-onyx-400 dark:text-white/40 uppercase">Practical Output</span>
            </div>
            <div className="p-5 rounded-2xl border border-onyx-200/40 bg-white/50 dark:border-white/5 dark:bg-[#0c0c0c]/40 text-center space-y-1 flex flex-col justify-center">
              <span className="font-serif text-3xl font-light text-brand-orange">Server</span>
              <span className="font-mono text-[9px] text-onyx-400 dark:text-white/40 uppercase">Side Tagging</span>
            </div>
            <div className="p-5 rounded-2xl border border-onyx-200/40 bg-white/50 dark:border-white/5 dark:bg-[#0c0c0c]/40 text-center space-y-1 flex flex-col justify-center">
              <span className="font-serif text-3xl font-light text-brand-orange">AI</span>
              <span className="font-mono text-[9px] text-onyx-400 dark:text-white/40 uppercase">Accelerated Cycles</span>
            </div>
            <div className="p-5 rounded-2xl border border-onyx-200/40 bg-white/50 dark:border-white/5 dark:bg-[#0c0c0c]/40 text-center space-y-1 flex flex-col justify-center">
              <span className="font-serif text-3xl font-light text-brand-orange">Zero</span>
              <span className="font-mono text-[9px] text-onyx-400 dark:text-white/40 uppercase">Aesthetic Slop</span>
            </div>
          </div>
        </div>
      </section>

      {/* Advisory Call to Action */}
      <section className="pt-16 border-t border-onyx-200/40 dark:border-white/5 text-center space-y-8">
        <div className="max-w-2xl mx-auto space-y-4">
          <h2 className="font-serif text-2xl sm:text-3xl font-light text-onyx-950 dark:text-white">
            {l.advisoryCallTitle}
          </h2>
          <p className="text-xs sm:text-sm text-onyx-500 dark:text-white/50 leading-relaxed font-mono">
            {l.advisoryCallDesc}
          </p>
        </div>

        <a 
          href="#/contact"
          className="inline-flex items-center gap-2 px-6 py-3.5 rounded-full bg-onyx-950 text-white dark:bg-white dark:text-onyx-950 hover:bg-brand-orange dark:hover:bg-brand-orange hover:text-white dark:hover:text-white text-xs font-mono uppercase tracking-wider font-semibold transition-all duration-300"
        >
          <span>{l.advisoryBtn}</span>
          <ArrowRight className="w-4 h-4 rtl:rotate-180 animate-pulse" />
        </a>
      </section>

    </div>
  );
}
