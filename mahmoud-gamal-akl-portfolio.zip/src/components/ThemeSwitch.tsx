import { motion } from "motion/react";
import { Sun, Moon, Laptop } from "lucide-react";
import { useTheme, Theme } from "./ThemeContext";
import { useLanguage } from "./LanguageContext";

export default function ThemeSwitch() {
  const { theme, setTheme } = useTheme();
  const { t } = useLanguage();

  const options: { value: Theme; icon: any; labelKey: string }[] = [
    { value: "light", icon: Sun, labelKey: "theme.light" },
    { value: "dark", icon: Moon, labelKey: "theme.dark" },
    { value: "system", icon: Laptop, labelKey: "theme.system" },
  ];

  return (
    <div 
      id="theme-switcher-container"
      className="inline-flex p-0.5 rounded-full border border-onyx-200/60 bg-onyx-100/50 dark:border-onyx-800/80 dark:bg-onyx-900/40"
    >
      {options.map((opt) => {
        const Icon = opt.icon;
        const isActive = theme === opt.value;
        return (
          <button
            key={opt.value}
            id={`theme-btn-${opt.value}`}
            onClick={() => setTheme(opt.value)}
            className="relative flex items-center justify-center p-1.5 rounded-full text-onyx-500 hover:text-onyx-900 dark:hover:text-onyx-50 transition-colors focus:outline-none"
            title={t(opt.labelKey)}
            aria-label={t(opt.labelKey)}
          >
            {isActive && (
              <motion.span
                layoutId="activeThemeBg"
                className="absolute inset-0 rounded-full bg-white dark:bg-onyx-800 shadow-sm"
                transition={{ type: "spring", stiffness: 380, damping: 30 }}
              />
            )}
            <Icon className="relative w-3.5 h-3.5 z-10" />
            <span className="sr-only">{t(opt.labelKey)}</span>
          </button>
        );
      })}
    </div>
  );
}
