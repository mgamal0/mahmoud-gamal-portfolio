export interface PersonalInfo {
  name: string;
  title: string;
  subtitle: string;
  roles: {
    en: string[];
    ar: string[];
  };
  headline: {
    en: string;
    ar: string;
  };
  location: string;
  timezone: string;
  email: string;
  github: string;
  linkedin: string;
  twitter: string;
  phone?: string;
  biography: {
    en: string;
    ar: string;
  };
}

export interface NavigationItem {
  key: string;
  label: {
    en: string;
    ar: string;
  };
  path: string;
}

export interface ServiceItem {
  id: string;
  title: { en: string; ar: string };
  description: { en: string; ar: string };
  features: { en: string[]; ar: string[] };
}

export interface ProjectItem {
  id: string;
  title: { en: string; ar: string };
  category: { en: string; ar: string };
  metric: string;
  metricLabel: { en: string; ar: string };
  description: { en: string; ar: string };
  deliverables: { en: string[]; ar: string[] };
  overview: { en: string; ar: string };
  industry: { en: string; ar: string };
  servicesList: { en: string[]; ar: string[] };
  challenges: { en: string; ar: string };
  solutions: { en: string; ar: string };
  galleryPlaceholder: { en: string; ar: string };
  resultsPlaceholder: { en: string; ar: string };
}

export interface ExperienceItem {
  id: string;
  period: string;
  role: { en: string; ar: string };
  company: { en: string; ar: string };
  description: { en: string; ar: string };
  highlights: { en: string[]; ar: string[] };
}

export interface IndustryItem {
  id: string;
  name: { en: string; ar: string };
  percentage: string;
  description: { en: string; ar: string };
}

export interface PortfolioData {
  personal: PersonalInfo;
  navigation: NavigationItem[];
  services: ServiceItem[];
  projects: ProjectItem[];
  experience: ExperienceItem[];
  industries: IndustryItem[];
  meta: {
    titleTemplate: string;
    defaultTitle: string;
    description: {
      en: string;
      ar: string;
    };
    siteUrl: string;
    author: string;
    openGraph: {
      type: string;
      locale: string;
      siteName: string;
    };
  };
}

export const portfolioData: PortfolioData = {
  personal: {
    name: "Mahmoud Gamal Akl",
    title: "Growth & Performance Marketing Strategist",
    subtitle: "Building marketing systems that drive measurable business growth. Performance marketing specialist & executive consultant.",
    roles: {
      en: [
        "Growth & Performance Marketing Strategist",
        "Performance Marketing Specialist",
        "Marketing Consultant"
      ],
      ar: [
        "خبير استراتيجيات النمو والتسويق الرقمي القائم على الأداء",
        "أخصائي التسويق الرقمي عالي الأداء",
        "مستشار تسويق وإستراتيجية أعمال"
      ]
    },
    headline: {
      en: "Building Marketing Systems That Drive Measurable Business Growth.",
      ar: "بناء أنظمة تسويقية متكاملة تدفع عجلة النمو القابل للقياس للمؤسسات."
    },
    location: "Mansoura, Egypt",
    timezone: "Africa/Cairo",
    email: "mahmoudd.gamall2002@gmail.com",
    github: "https://github.com/mahmoudgamal",
    linkedin: "https://www.linkedin.com/in/mahmoud-gamal-akl-b30895200",
    twitter: "https://twitter.com/mahmoudgamal",
    phone: "01013988076",
    biography: {
      en: "Mahmoud Gamal Akl is an elite Growth & Performance Marketing Strategist and Executive Consultant. He architects mathematical, data-driven customer acquisition systems that blend technical media buying with brand psychology. Inspired by high-performance engineering systems, Mahmoud discards standard marketing vanity metrics in favor of absolute bottom-line profitability, designing conversion loops and attribution systems that scale multinational institutions and luxury brands with operational fluidity.",
      ar: "محمود جمال عقل هو خبير استراتيجي نخبوية في نمو الأعمال والتسويق القائم على الأداء ومستشار تنفيذي. يقوم بتصميم أنظمة رياضية مبنية على البيانات لجذب العملاء تجمع بين الشراء الفني للمساحات الإعلانية وعلم نفس العلامة التجارية. مستوحى من أنظمة الهندسة عالية الأداء، يتجاوز محمود مقاييس التسويق الرقمي التقليدية وغير المجدية لصالح تحقيق ربحية صافية مطلقة وتصميم حلقات تحويل دقيقة للشركات الكبرى والعلامات التجارية الفاخرة."
    }
  },
  navigation: [
    { key: "about", label: { en: "Executive Profile", ar: "الملف التنفيذي" }, path: "#/about" },
    { key: "services", label: { en: "Systems & Services", ar: "الخدمات والأنظمة" }, path: "#/services" },
    { key: "projects", label: { en: "Impact Proofs", ar: "إثبات الأثر" }, path: "#/projects" },
    { key: "experience", label: { en: "Career Ledger", ar: "مسيرة الخبرة" }, path: "#/experience" },
    { key: "skills", label: { en: "Skills Matrix", ar: "مصفوفة المهارات" }, path: "#/skills" },
    { key: "insights", label: { en: "Executive Insights", ar: "المرئيات التنفيذية" }, path: "#/insights" },
    { key: "industries", label: { en: "Sectors", ar: "القطاعات" }, path: "#industries" },
    { key: "contact", label: { en: "Executive Inquiry", ar: "الاستعلام التنفيذي" }, path: "#/contact" }
  ],
  services: [
    {
      id: "perf-marketing",
      title: { en: "Paid Acquisition & Media Buying", ar: "الاستحواذ المدفوع وإدارة الحملات" },
      description: {
        en: "Engineering hyper-targeted paid campaigns across Meta, Google, LinkedIn, and TikTok. Built on strict unit economic models to guarantee negative CAC-to-LTV ratios.",
        ar: "هندسة حملات ممولة فائقة الاستهداف عبر جوجل، وميتا، ولينكد إن، وتيك توك. مصممة وفق نماذج اقتصادية صارمة لضمان زيادة القيمة الدائمة للعميل بالنسبة لكلفة الاستحواذ."
      },
      features: {
        en: ["Multi-channel attribution architecture", "Mathematical cohort split-testing", "Custom conversion API integrations", "Dynamic creative optimization"],
        ar: ["هيكلية إسناد الحملات متعددة القنوات", "اختبارات مقارنة رياضية دقيقة", "ربط واجهات برمجة تطبيقات التحويل المخصصة", "تحسين إبداعي ديناميكي مستمر"]
      }
    },
    {
      id: "growth-strategy",
      title: { en: "Growth Strategy & Funnel Architecture", ar: "استراتيجية النمو وهندسة مسارات التحويل" },
      description: {
        en: "Deconstructing customer journeys to build elegant conversion tunnels. Optimizing product activation, subscription retention, and executive funnel mechanics.",
        ar: "تفكيك رحلات العملاء لبناء قنوات تحويل سلسة. تحسين مستويات التفعيل للمنتجات، والاحتفاظ بالمشتركين، وآليات مسارات المبيعات التنفيذية."
      },
      features: {
        en: ["Full-funnel conversion rate optimization", "LTV amplification models", "B2B pipeline design & orchestration", "SaaS expansion & monetization frameworks"],
        ar: ["تحسين معدل التحويل للمسار بالكامل", "نماذج تضخيم القيمة الدائمة للعميل", "تصميم وتنسيق قنوات مبيعات الشركات B2B", "أطر التوسع وتحقيق الأرباح لشركات البرمجيات SaaS"]
      }
    },
    {
      id: "mktg-consulting",
      title: { en: "Marketing Systems Audit & Advisory", ar: "تدقيق الأنظمة التسويقية والاستشارات التنفيذية" },
      description: {
        en: "Acting as an external advisor to executive boards. Auditing active marketing stacks, team structures, budget allocation algorithms, and reporting tools.",
        ar: "العمل كمستشار خارجي لمجالس الإدارة التنفيذية. تدقيق الأدوات التقنية التسويقية الحالية، وهياكل الفرق، وخوارزميات تخصيص الميزانيات، وأنظمة التقارير."
      },
      features: {
        en: ["High-accuracy technical infrastructure audit", "Independent fractional CMO consultation", "Marketing team restructuring blueprints", "Vendor & agency performance evaluation"],
        ar: ["تدقيق البنية التحتية التقنية بدقة عالية", "استشارات إدارية تسويقية مستقلة (Fractional CMO)", "مخططات إعادة هيكلة فرق التسويق", "تقييم أداء الوكالات الخارجية والموردين"]
      }
    }
  ],
  projects: [
    {
      id: "al-madina-ready-mix",
      title: { en: "Al Madina Ready Mixed Concrete", ar: "المدينة للخرسانة الجاهزة" },
      category: { en: "Heavy Industry Supply", ar: "صناعات ثقيلة وتوريد" },
      metric: "B2B Lead Flow",
      metricLabel: { en: "Industrial Pipeline Automation", ar: "أتمتة مبيعات القطاع الصناعي" },
      description: {
        en: "Establishing high-value industrial visibility and digital client acquisition systems for concrete supply pipelines. Moving traditional procurement to modern inbound channels.",
        ar: "تأسيس حضور رقمي عالي القيمة وأنظمة استقطاب عملاء صناعيين لخطوط توريد الخرسانة الجاهزة، مع تحويل عمليات الشراء التقليدية إلى قنوات واردة حديثة."
      },
      deliverables: {
        en: ["Brand Positioning", "Performance Campaigns", "Website Strategy", "LinkedIn Strategy", "Creative Direction", "Marketing Strategy"],
        ar: ["تموضع العلامة التجارية", "حملات الأداء والميديا", "إستراتيجية المواقع الإلكترونية", "إستراتيجية لينكد إن", "التوجيه الإبداعي", "إستراتيجية التسويق"]
      },
      overview: {
        en: "Establishment of modern digital lead generation networks and structural corporate brand alignment for one of the region's premium ready-mixed concrete providers. This system targets general contractors, commercial developers, and project procurement executives.",
        ar: "تأسيس شبكات حديثة لتوليد العملاء المحتملين وتنسيق الهوية المؤسسية لأحد أبرز مزودي الخرسانة الجاهزة في المنطقة. يستهدف هذا النظام مقاولي العموم، والمطورين التجاريين، ومديري المشتريات بالمشروعات الكبرى."
      },
      industry: {
        en: "Industrial Manufacturing & Construction Supply",
        ar: "التصنيع الصناعي وتوريد قطاع الإنشاءات"
      },
      servicesList: {
        en: ["Brand Positioning", "Performance Campaigns", "Website Strategy", "LinkedIn Strategy", "Creative Direction", "Marketing Strategy"],
        ar: ["تموضع العلامة التجارية", "حملات تسويق الأداء", "إستراتيجية المواقع الإلكترونية", "إستراتيجية منصة لينكد إن", "التوجيه الإبداعي للفنون", "إستراتيجية التسويق الشاملة"]
      },
      challenges: {
        en: "Heavy industry has historically relied on purely traditional, offline sales networks. Digital attribution in ready-mixed concrete is notoriously low, and standard marketing agency campaigns fail because they do not speak the specialized technical language of concrete formulas, ASTM standards, and large-scale contractor procurement.",
        ar: "تعتمد الصناعات الثقيلة تقليدياً على شبكات مبيعات وعلاقات شخصية غير متصلة بالإنترنت تماماً. يصعب تتبع وإسناد الحملات الرقمية في قطاع الخرسانة الجاهزة، وتفشل وكالات التسويق التقليدية لعدم إلمامها باللغة الفنية المتخصصة لمواصفات الخرسانة، واختبارات الجودة، وعمليات الشراء للمقاولين الكبار."
      },
      solutions: {
        en: "Mahmoud engineered a highly tailored corporate marketing system. This combined Google Search intent-capturing (harvesting search queries from contractors seeking concrete supply) with professional LinkedIn executive authority positioning. Leads are pre-qualified on structural capacity requirements before being routed directly to internal engineering estimators.",
        ar: "قام محمود بهندسة نظام تسويق مؤسسي مخصص. يجمع هذا النظام بين استقطاب نية الشراء عبر محرك بحث جوجل (استهداف استعلامات المقاولين الباحثين عن توريد الخرسانة) وبناء المصداقية والتموضع التنفيذي عبر لينكد إن. يتم تصفية وتأهيل العملاء بناءً على متطلبات الطاقة الإنشائية والمواصفات الفنية قبل توجيههم مباشرة إلى مهندسي التسعير الداخليين."
      },
      galleryPlaceholder: {
        en: "Detailed blueprint layouts of industrial concrete mixing facilities, ready-mixed mixer fleet dispatch operations, and corporate asset structural photographs.",
        ar: "مخططات تفصيلية لمنشآت خلط الخرسانة الصناعية، عمليات توجيه أسطول سيارات الخلط الجاهز، وصور هيكلية لأصول الشركة المؤسسية."
      },
      resultsPlaceholder: {
        en: "Active, validated corporate inbound lead tracking interface. Direct CRM pipeline records and automated quotation request flows showing verified contractor contact profiles.",
        ar: "واجهة تتبع وتأهيل عملاء الشركات الواردة والمحققة بنجاح. سجلات تدفق المبيعات المباشرة بالـ CRM وتدفقات طلبات عروض الأسعار المؤتمتة التي تظهر ملفات تواصل المقاولين المعتمدين."
      }
    },
    {
      id: "constar-acquisition",
      title: { en: "Constar", ar: "كونستار" },
      category: { en: "Commercial Contracting", ar: "المقاولات والإنشاءات التجارية" },
      metric: "Corporate Leads",
      metricLabel: { en: "Enterprise Funnel Infrastructure", ar: "بنية مسارات الاستحواذ للمؤسسات" },
      description: {
        en: "Designing robust lead acquisition models and premium brand systems for commercial contracting. Aligning inbound digital pipeline flow directly with estimating team workflows.",
        ar: "تصميم نماذج قوية للاستحواذ على العملاء المحتملين وأنظمة العلامات التجارية الفاخرة لقطاع المقاولات التجارية. مواءمة تدفق العملاء الرقمي الوارد مع عمليات المبيعات المباشرة."
      },
      deliverables: {
        en: ["Lead Generation", "Marketing Funnels", "Digital Marketing", "Website Planning", "Corporate Identity"],
        ar: ["توليد العملاء المحتملين", "مسارات التسويق والتحويل", "التسويق الرقمي", "تخطيط المواقع الإلكترونية", "الهوية المؤسسية"]
      },
      overview: {
        en: "Designing and scaling corporate acquisition mechanics and high-intent lead generation channels for Constar, a premier player in commercial contracting. This system transforms the online footprint into a reliable commercial growth driver.",
        ar: "تصميم وتوسيع نطاق آليات الاستحواذ المؤسسي وقنوات جذب العملاء المحتملين ذوي النية العالية لصالح شركة كونستار، الرائدة في قطاع المقاولات التجارية. يقوم هذا النظام بتحويل الحضور الرقمي إلى محرك نمو تجاري موثوق."
      },
      industry: {
        en: "Commercial Contracting & Construction Services",
        ar: "المقاولات التجارية وخدمات الإنشاءات"
      },
      servicesList: {
        en: ["Lead Generation", "Marketing Funnels", "Digital Marketing", "Website Planning", "Corporate Identity"],
        ar: ["توليد العملاء المحتملين", "مسارات التسويق والتحويل", "التسويق الرقمي المتكامل", "تخطيط وبناء المواقع الإلكترونية", "تصميم الهوية المؤسسية"]
      },
      challenges: {
        en: "A fragmented online profile and lack of authoritative brand system failed to capture trust from major real estate developers and corporate partners. Lead generation methods were capturing broad, low-intent consumer inquiries instead of high-value commercial construction contracts, burdening estimation teams with noise.",
        ar: "أدى تشتت المظهر الرقمي وغياب نظام قوي للعلامة التجارية لعدم كسب ثقة كبار المطورين العقاريين والشركاء المؤسسيين. كما كانت أساليب جذب العملاء السابقة تجمع استفسارات عادية من أفراد منخفضي الأهمية بدلاً من صفقات الإنشاءات التجارية الضخمة، مما أرهق فرق التسعير ببيانات غير مجدية."
      },
      solutions: {
        en: "Mahmoud restructured Constar's corporate brand positioning with high-end, premium engineering aesthetics. A systematic lead qualification funnel was implemented, requiring prospects to provide verified location, project scale, and investment tiers, thereby ensuring only enterprise-level opportunities reach the physical sales desk.",
        ar: "أعاد محمود هيكلة تموضع العلامة التجارية لشركة كونستار بلمسة بصرية هندسية فاخرة وراقية. وتم إطلاق مسار تصفية وتأهيل منهجي للعملاء، يلزم العميل المحتمل بتقديم الموقع المعتمد، وحجم المشروع، وفئات الاستثمار المتوقعة، لضمان وصول الصفقات ذات القيمة الكبرى فقط لمكاتب المبيعات."
      },
      galleryPlaceholder: {
        en: "High-contrast architectural design assets, engineering project wireframes, and premium corporate identity documentation layouts.",
        ar: "أصول تصاميم معمارية عالية التباين، وهياكل العمل للمشروعات الهندسية، ومخططات توثيق الهوية المؤسسية الفاخرة."
      },
      resultsPlaceholder: {
        en: "Standardized lead-qualification tracking logs, showcasing systematic capture of commercial builders, property owners, and corporate development partners with complete project details.",
        ar: "سجلات تتبع وتأهيل العملاء القياسية، التي تعرض الجمع المنهجي لبيانات شركات البناء، وملاك العقارات، وشركاء التطوير المؤسسي بتفاصيل المشاريع الكاملة."
      }
    },
    {
      id: "tomaihy-retail",
      title: { en: "El Tomaihy", ar: "التميحي" },
      category: { en: "Consumer Retail Marketing", ar: "تسويق التجزئة الاستهلاكية" },
      metric: "Meta Ad Campaigns",
      metricLabel: { en: "Highly Optimized Media Spending", ar: "الإنفاق الإعلاني فائق التحسين" },
      description: {
        en: "Directing B2C retail brand amplification, executing optimized Meta campaign models, and deploying targeted content strategies to drive consistent foot traffic.",
        ar: "توجيه حملات التجزئة الاستهلاكية B2C، وإطلاق حملات ممولة عالية التحسين عبر منصات ميتا، وتطبيق إستراتيجيات محتوى مستهدفة لزيادة الإقبال والزيارات."
      },
      deliverables: {
        en: ["Meta Ads", "Social Media", "Retail Marketing", "Campaign Planning", "Content Strategy"],
        ar: ["إعلانات منصة ميتا الممولة", "قنوات التواصل الاجتماعي", "تسويق التجزئة", "تخطيط وبناء الحملات", "إستراتيجية صياغة المحتوى"]
      },
      overview: {
        en: "Directing targeted B2C retail growth and digital amplification for El Tomaihy. Crafting responsive multi-layered social strategies and highly systematic retail advertising models.",
        ar: "توجيه النمو والاستحواذ الاستهلاكي B2C وحملات الانتشار الرقمي لشركة التميحي. صياغة استراتيجيات شبكات اجتماعية متعددة الطبقات ونماذج إعلانات تجزئة بالغة المنهجية."
      },
      industry: {
        en: "Retail & Consumer Brand Distribution",
        ar: "التجزئة وتوزيع العلامات التجارية الاستهلاكية"
      },
      servicesList: {
        en: ["Meta Ads", "Social Media", "Retail Marketing", "Campaign Planning", "Content Strategy"],
        ar: ["إعلانات منصة ميتا الممولة", "إدارة التواصل الاجتماعي", "تسويق قطاع التجزئة", "تخطيط وبناء الحملات", "إستراتيجية صياغة المحتوى"]
      },
      challenges: {
        en: "The consumer retail landscape suffers from severe ad fatigue, skyrocketing acquisition costs, and short attention spans. Generating predictable, cost-effective offline foot traffic and digital product traction requires constant creative refresh and highly localized targeting.",
        ar: "يعاني قطاع التجزئة الاستهلاكية من تشبع إعلاني شديد، وارتفاع متزايد في تكاليف الاستحواذ، وقصر انتباه المستهلكين. يتطلب تحقيق تدفقات متوقعة وفعالة من حيث التكلفة للزيارات الفعلية بالفروع والمبيعات الرقمية تجديداً إبداعياً مستمراً واستهدافاً محلياً دقيقاً."
      },
      solutions: {
        en: "Mahmoud implemented a high-volume creative testing methodology on Meta Ads. Instead of relying on static advertising, campaigns are structured around consumer psychology hooks, localized geo-fences, and systematic content sequences that nurture prospects from initial social discovery directly to physical checkout.",
        ar: "طبق محمود منهجية اختبار إبداعي مكثف وعالي الكفاءة لإعلانات منصات ميتا. بدلاً من الاعتماد على إعلانات جامدة، تم تنظيم الحملات بالارتكاز على محفزات علم نفس المستهلك، واستهداف النطاق الجغرافي للمحلات بدقة، وبناء سلاسل محتوى تفاعلية ترعى المستهلك من الاكتشاف الأول حتى الشراء الفعلي."
      },
      galleryPlaceholder: {
        en: "Consumer creative sequencing wireframes, localized promotional campaign asset maps, and interactive social content guides.",
        ar: "هياكل تسلسل التصاميم الإبداعية للمستهلكين، خرائط أصول الحملات الترويجية المحلية، وأدلة المحتوى الاجتماعي التفاعلي."
      },
      resultsPlaceholder: {
        en: "Social ad account structure logs and verified consumer interaction dashboards showcasing consistent demographic engagement without media waste.",
        ar: "سجلات هيكلة الحسابات الإعلانية على المنصات الرقمية ولوحات تتبع تفاعل المستهلكين المعتمدة التي تظهر مستويات التفاعل الديمغرافي المتناسق دون أي هدر في الميزانيات."
      }
    }
  ],
  experience: [
    {
      id: "exp-al-madina",
      period: "2025 - PRESENT",
      role: { en: "Performance Marketing Specialist", ar: "أخصائي تسويق الأداء" },
      company: { en: "Al Madina Ready Mixed Concrete", ar: "المدينة للخرسانة الجاهزة" },
      description: {
        en: "Spearheading modern performance acquisition systems and institutional marketing alignment for one of the region's prominent industrial suppliers. Driving structural visibility and corporate lead flow.",
        ar: "قيادة أنظمة الاستحواذ والتسويق الرقمي الحديثة وتنسيق التموضع المؤسسي لأحد أكبر موردي الصناعات الإنشائية والخرسانية في المنطقة، بهدف تحقيق أعلى معدلات تدفق مبيعات وجذب عملاء."
      },
      highlights: {
        en: [
          "Brand Positioning",
          "Performance Campaigns",
          "Website Strategy",
          "LinkedIn Strategy",
          "Creative Direction",
          "Marketing Strategy"
        ],
        ar: [
          "تموضع العلامة التجارية",
          "حملات تسويق الأداء",
          "إستراتيجية المواقع الإلكترونية",
          "إستراتيجية منصة لينكد إن",
          "التوجيه الإبداعي الفني",
          "إستراتيجية التسويق الشاملة"
        ]
      }
    },
    {
      id: "exp-constar",
      period: "2025 - PRESENT",
      role: { en: "Performance Marketing Specialist", ar: "أخصائي تسويق الأداء" },
      company: { en: "Constar", ar: "كونستار" },
      description: {
        en: "Designing and scaling corporate acquisition mechanics and lead generation infrastructure. Aligning automated digital pipelines with sales workflows to enhance closure speeds.",
        ar: "تصميم وتوسيع نطاق آليات الاستحواذ المؤسسي وبنية توليد العملاء المحتملين وتكاملها مع قنوات المبيعات المباشرة لتسريع دورات التعاقد."
      },
      highlights: {
        en: [
          "Lead Generation",
          "Marketing Funnels",
          "Digital Marketing",
          "Website Planning",
          "Corporate Identity"
        ],
        ar: [
          "توليد وجذب العملاء المحتملين",
          "مسارات التحويل والتسويق",
          "التسويق الرقمي المتكامل",
          "تخطيط المواقع الإلكترونية",
          "الهوية المؤسسية الرفيعة"
        ]
      }
    },
    {
      id: "exp-tomaihy",
      period: "MARCH 2026 - PRESENT",
      role: { en: "Digital Marketing Specialist", ar: "أخصائي التسويق الرقمي" },
      company: { en: "El Tomaihy", ar: "التميحي" },
      description: {
        en: "Directing B2C retail brand amplification, deploying highly-optimized Meta campaigns, and crafting interactive content sequences that build strong consumer retention.",
        ar: "توجيه حملات التجزئة الاستهلاكية B2C، وإطلاق حملات إعلانية ممولة فائقة التحسين عبر منصات ميتا، وصياغة سلاسل المحتوى لتعزيز الوعي بالعلامة."
      },
      highlights: {
        en: [
          "Meta Ads",
          "Social Media",
          "Retail Marketing",
          "Campaign Planning",
          "Content Strategy"
        ],
        ar: [
          "إعلانات منصة ميتا الممولة",
          "إدارة منصات التواصل الاجتماعي",
          "تسويق التجزئة والمنتجات",
          "تخطيط وبناء الحملات التسويقية",
          "صياغة إستراتيجية المحتوى"
        ]
      }
    }
  ],
  industries: [
    { id: "saas", name: { en: "Enterprise B2B SaaS", ar: "البرمجيات المؤسسية SaaS" }, percentage: "40%", description: { en: "Optimizing pipelines, trial signups, and customer acquisition algorithms.", ar: "تحسين قنوات البيع، واشتراكات التجربة المجانية، وخوارزميات الاستحواذ." } },
    { id: "ecom", name: { en: "Luxury E-Commerce & Retail", ar: "التجارة الإلكترونية الفاخرة والتجزئة" }, percentage: "30%", description: { en: "Scaling return on ad spend (ROAS) and loyalty purchase cycles.", ar: "تعظيم العائد على الإنفاق الإعلاني ROAS ودورات الشراء المتكررة." } },
    { id: "fin", name: { en: "Financial Services & Fintech", ar: "الخدمات المالية والتكنولوجيا المالية" }, percentage: "20%", description: { en: "Sourcing high-trust qualified signups within strict compliance regulations.", ar: "جلب عملاء مؤهلين ذوي ثقة عالية في إطار لوائح امتثال صارمة." } },
    { id: "real", name: { en: "Real Estate & PropTech", ar: "العقارات والتكنولوجيا العقارية" }, percentage: "10%", description: { en: "Capturing premium real estate buyers and automated CRM matching.", ar: "جذب مشتري العقارات الفاخرة وتأهيلهم عبر التوزيع المؤتمت." } }
  ],
  meta: {
    titleTemplate: "%s | Mahmoud Gamal Akl",
    defaultTitle: "Mahmoud Gamal Akl | Growth & Performance Marketing Strategist",
    description: {
      en: "The portfolio of Mahmoud Gamal Akl. Growth & Performance Marketing Strategist and Marketing Consultant building high-performance marketing systems that drive measurable business growth.",
      ar: "الملف المهني لمحمود جمال عقل. خبير استراتيجي ومستشار في نمو الأعمال والتسويق القائم على الأداء لبناء أنظمة تسويقية متكاملة تحقق عائداً ملموساً ونمواً مستمراً."
    },
    siteUrl: "https://mahmoudakl.com",
    author: "Mahmoud Gamal Akl",
    openGraph: {
      type: "website",
      locale: "en_US",
      siteName: "Mahmoud Gamal Akl Portfolio"
    }
  }
};
