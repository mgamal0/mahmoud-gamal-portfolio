import { portfolioData } from "../data/portfolio";

export interface SEOConfig {
  title: string;
  description: string;
  siteUrl: string;
  author: string;
  keywords: string[];
  ogImage: string;
}

export const defaultSEO: SEOConfig = {
  title: portfolioData.meta.defaultTitle,
  description: portfolioData.meta.description.en,
  siteUrl: portfolioData.meta.siteUrl,
  author: portfolioData.meta.author,
  keywords: [
    "Mahmoud Gamal Akl",
    "Digital Architect",
    "Creative Director",
    "Portfolio",
    "Software Engineer",
    "Enterprise Design Systems",
    "Vite",
    "React Architect",
    "Executive",
    "Luxury Portfolio"
  ],
  ogImage: "https://mahmoudakl.com/og-image.jpg" // Placeholder for high-end preview image
};

/**
 * Dynamically updates head meta tags for SEO verification.
 * In a Vite-based single-page application, this enables crawlers that execute JS 
 * to index correct, language-specific titles and descriptions.
 */
export function updateDocumentMetadata(locale: "en" | "ar") {
  if (typeof window === "undefined") return;

  const title = locale === "ar" 
    ? "محمود جمال عقل | مهندس معماري رقمي ومخرج إبداعي"
    : portfolioData.meta.defaultTitle;
  
  const description = portfolioData.meta.description[locale];

  // Sync Dynamic Lang & Dir in HTML Tag
  document.documentElement.lang = locale;
  document.documentElement.dir = locale === "ar" ? "rtl" : "ltr";

  // Update Title
  document.title = title;

  // Helper to set meta tag
  const setMetaTag = (nameOrProperty: string, content: string, isProperty = false) => {
    const attribute = isProperty ? "property" : "name";
    let element = document.querySelector(`meta[${attribute}="${nameOrProperty}"]`);
    
    if (!element) {
      element = document.createElement("meta");
      element.setAttribute(attribute, nameOrProperty);
      document.head.appendChild(element);
    }
    element.setAttribute("content", content);
  };

  // Standard Meta Tags
  setMetaTag("description", description);
  setMetaTag("author", defaultSEO.author);
  setMetaTag("keywords", defaultSEO.keywords.join(", "));

  // OpenGraph Tags
  setMetaTag("og:title", title, true);
  setMetaTag("og:description", description, true);
  setMetaTag("og:type", portfolioData.meta.openGraph.type, true);
  setMetaTag("og:url", defaultSEO.siteUrl, true);
  setMetaTag("og:image", defaultSEO.ogImage, true);
  setMetaTag("og:site_name", portfolioData.meta.openGraph.siteName, true);
  setMetaTag("og:locale", locale === "ar" ? "ar_EG" : "en_US", true);

  // Twitter Tags
  setMetaTag("twitter:card", "summary_large_image");
  setMetaTag("twitter:title", title);
  setMetaTag("twitter:description", description);
  setMetaTag("twitter:image", defaultSEO.ogImage);

  // Canonical Link Integration
  let canonicalElement = document.querySelector('link[rel="canonical"]');
  if (!canonicalElement) {
    canonicalElement = document.createElement("link");
    canonicalElement.setAttribute("rel", "canonical");
    document.head.appendChild(canonicalElement);
  }
  canonicalElement.setAttribute("href", defaultSEO.siteUrl + (window.location.hash || ""));
}

/**
 * Returns the structured JSON-LD data for the person Mahmoud Gamal Akl.
 * This is crucial for rich Google search result cards.
 */
export function getPersonSchema() {
  return {
    "@context": "https://schema.org",
    "@type": "Person",
    "name": portfolioData.personal.name,
    "jobTitle": portfolioData.personal.title,
    "url": portfolioData.meta.siteUrl,
    "sameAs": [
      portfolioData.personal.github,
      portfolioData.personal.linkedin,
      portfolioData.personal.twitter
    ],
    "email": portfolioData.personal.email,
    "address": {
      "@type": "PostalAddress",
      "addressLocality": "Cairo / Dubai",
      "addressCountry": "Egypt / UAE"
    },
    "description": portfolioData.personal.subtitle
  };
}

/**
 * Returns the structured JSON-LD data for Breadcrumbs based on active route.
 */
export function getBreadcrumbSchema(hash: string, locale: "en" | "ar") {
  const items = [
    {
      "@type": "ListItem",
      position: 1,
      name: locale === "ar" ? "الرئيسية" : "Home",
      item: "https://mahmoudakl.com/"
    }
  ];

  const cleanHash = hash.split("?")[0];

  if (cleanHash.startsWith("#/about")) {
    items.push({
      "@type": "ListItem",
      position: 2,
      name: locale === "ar" ? "من أنا" : "About",
      item: "https://mahmoudakl.com/#/about"
    });
  } else if (cleanHash.startsWith("#/services")) {
    items.push({
      "@type": "ListItem",
      position: 2,
      name: locale === "ar" ? "الخدمات" : "Services",
      item: "https://mahmoudakl.com/#/services"
    });
  } else if (cleanHash.startsWith("#/experience")) {
    items.push({
      "@type": "ListItem",
      position: 2,
      name: locale === "ar" ? "مسيرة الخبرة" : "Experience",
      item: "https://mahmoudakl.com/#/experience"
    });
  } else if (cleanHash.startsWith("#/projects")) {
    items.push({
      "@type": "ListItem",
      position: 2,
      name: locale === "ar" ? "المشاريع" : "Projects",
      item: "https://mahmoudakl.com/#/projects"
    });
  } else if (cleanHash.startsWith("#/skills")) {
    items.push({
      "@type": "ListItem",
      position: 2,
      name: locale === "ar" ? "المهارات" : "Skills",
      item: "https://mahmoudakl.com/#/skills"
    });
  } else if (cleanHash.startsWith("#/insights")) {
    items.push({
      "@type": "ListItem",
      position: 2,
      name: locale === "ar" ? "المرئيات" : "Insights",
      item: "https://mahmoudakl.com/#/insights"
    });
  } else if (cleanHash.startsWith("#/contact")) {
    items.push({
      "@type": "ListItem",
      position: 2,
      name: locale === "ar" ? "اتصل بنا" : "Contact",
      item: "https://mahmoudakl.com/#/contact"
    });
  }

  return {
    "@context": "https://schema.org",
    "@type": "BreadcrumbList",
    "itemListElement": items
  };
}

/**
 * Technical blueprint configuration for robots.txt
 */
export const robotsConfig = {
  userAgent: "*",
  allow: "/",
  disallow: ["/api/", "/private/"],
  sitemap: "https://mahmoudakl.com/sitemap.xml"
};

/**
 * Architectural sitemap definition
 */
export const sitemapConfig = [
  { url: "https://mahmoudakl.com/", lastModified: "2026-06-29", changeFrequency: "monthly", priority: 1.0 },
  { url: "https://mahmoudakl.com/#work", lastModified: "2026-06-29", changeFrequency: "weekly", priority: 0.8 },
  { url: "https://mahmoudakl.com/#about", lastModified: "2026-06-29", changeFrequency: "monthly", priority: 0.7 },
  { url: "https://mahmoudakl.com/#experience", lastModified: "2026-06-29", changeFrequency: "monthly", priority: 0.7 },
  { url: "https://mahmoudakl.com/#contact", lastModified: "2026-06-29", changeFrequency: "yearly", priority: 0.5 }
];
