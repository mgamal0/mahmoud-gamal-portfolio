import { initializeApp, getApps, getApp } from "firebase/app";
import { 
  getAuth, 
  GoogleAuthProvider, 
  signInWithPopup, 
  onAuthStateChanged, 
  signOut,
  User 
} from "firebase/auth";
import firebaseConfig from "../../firebase-applet-config.json";

// Initialize Firebase app if it doesn't already exist
const app = getApps().length === 0 ? initializeApp(firebaseConfig) : getApp();
export const auth = getAuth(app);

// Configure Google OAuth Provider
export const provider = new GoogleAuthProvider();
provider.addScope("https://www.googleapis.com/auth/spreadsheets");
provider.addScope("https://www.googleapis.com/auth/drive.file");

// In-memory token cache
let cachedAccessToken: string | null = null;
let isSigningIn = false;

// Initialize auth state and retrieve cached token logic
export const initAuth = (
  onAuthSuccess: (user: User, token: string) => void,
  onAuthFailure: () => void
) => {
  return onAuthStateChanged(auth, async (user) => {
    if (user) {
      // If we have a user but no in-memory token, we need them to click sign in again to refresh/re-fetch token
      if (cachedAccessToken) {
        onAuthSuccess(user, cachedAccessToken);
      } else {
        onAuthFailure();
      }
    } else {
      cachedAccessToken = null;
      onAuthFailure();
    }
  });
};

// Google Sign-In with Popup
export const googleSignIn = async (): Promise<{ user: User; accessToken: string } | null> => {
  try {
    isSigningIn = true;
    const result = await signInWithPopup(auth, provider);
    const credential = GoogleAuthProvider.credentialFromResult(result);
    if (!credential?.accessToken) {
      throw new Error("Failed to retrieve Google OAuth access token.");
    }
    cachedAccessToken = credential.accessToken;
    return { user: result.user, accessToken: cachedAccessToken };
  } catch (error) {
    console.error("Google Authentication failed:", error);
    throw error;
  } finally {
    isSigningIn = false;
  }
};

// Log Out
export const logout = async (): Promise<void> => {
  await signOut(auth);
  cachedAccessToken = null;
};

// Retrieve current cached access token
export const getAccessToken = (): string | null => {
  return cachedAccessToken;
};

// Spreadsheet Lead Row interface
export interface LeadRow {
  timestamp: string;
  name: string;
  email: string;
  phone: string;
  company: string;
  service: string;
  message: string;
  status: string;
}

/**
 * Creates a brand-new Google Spreadsheet with predefined headers for Lead Management.
 */
export const createPortfolioSpreadsheet = async (accessToken: string): Promise<string> => {
  const url = "https://sheets.googleapis.com/v4/spreadsheets";
  
  const response = await fetch(url, {
    method: "POST",
    headers: {
      "Authorization": `Bearer ${accessToken}`,
      "Content-Type": "application/json"
    },
    body: JSON.stringify({
      properties: {
        title: "Mahmoud Gamal Akl - Portfolio Lead Submissions"
      },
      sheets: [
        {
          properties: {
            title: "Leads",
            gridProperties: {
              frozenRowCount: 1
            }
          }
        }
      ]
    })
  });

  if (!response.ok) {
    const errText = await response.text();
    throw new Error(`Failed to create spreadsheet: ${errText}`);
  }

  const data = await response.json();
  const spreadsheetId = data.spreadsheetId;

  // Initialize Headers
  await updateSpreadsheetValues(accessToken, spreadsheetId, "Leads!A1:H1", [
    ["Timestamp", "Executive Name", "Corporate Email", "Direct Telephone", "Organization/Company", "Diagnostic Required", "Strategic Context / Message", "Status"]
  ]);

  return spreadsheetId;
};

/**
 * Helper to write specific cell values to a spreadsheet.
 */
export const updateSpreadsheetValues = async (
  accessToken: string,
  spreadsheetId: string,
  range: string,
  values: string[][]
): Promise<any> => {
  const url = `https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}/values/${encodeURIComponent(range)}?valueInputOption=USER_ENTERED`;
  
  const response = await fetch(url, {
    method: "PUT",
    headers: {
      "Authorization": `Bearer ${accessToken}`,
      "Content-Type": "application/json"
    },
    body: JSON.stringify({
      values
    })
  });

  if (!response.ok) {
    const errText = await response.text();
    throw new Error(`Failed to update spreadsheet cells: ${errText}`);
  }

  return response.json();
};

/**
 * Appends a lead row to the spreadsheet.
 */
export const appendLeadToSpreadsheet = async (
  accessToken: string,
  spreadsheetId: string,
  lead: Omit<LeadRow, "timestamp" | "status">
): Promise<any> => {
  const timestamp = new Date().toLocaleString();
  const range = "Leads!A:H";
  const url = `https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}/values/${encodeURIComponent(range)}:append?valueInputOption=USER_ENTERED`;

  const response = await fetch(url, {
    method: "POST",
    headers: {
      "Authorization": `Bearer ${accessToken}`,
      "Content-Type": "application/json"
    },
    body: JSON.stringify({
      values: [
        [
          timestamp,
          lead.name,
          lead.email,
          lead.phone || "N/A",
          lead.company || "N/A",
          lead.service,
          lead.message,
          "New Inquiry"
        ]
      ]
    })
  });

  if (!response.ok) {
    const errText = await response.text();
    throw new Error(`Failed to append lead to spreadsheet: ${errText}`);
  }

  return response.json();
};

/**
 * Reads all rows from the spreadsheet.
 */
export const fetchLeadsFromSpreadsheet = async (
  accessToken: string,
  spreadsheetId: string
): Promise<LeadRow[]> => {
  const range = "Leads!A2:H100";
  const url = `https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}/values/${encodeURIComponent(range)}`;

  const response = await fetch(url, {
    method: "GET",
    headers: {
      "Authorization": `Bearer ${accessToken}`
    }
  });

  if (!response.ok) {
    const errText = await response.text();
    throw new Error(`Failed to fetch leads from spreadsheet: ${errText}`);
  }

  const data = await response.json();
  const rows = data.values || [];

  return rows.map((row: any[]) => ({
    timestamp: row[0] || "",
    name: row[1] || "",
    email: row[2] || "",
    phone: row[3] || "",
    company: row[4] || "",
    service: row[5] || "",
    message: row[6] || "",
    status: row[7] || "New Inquiry"
  }));
};
